#!/bin/bash
#
# ============================================
# JeSync Pro Dashboard - SECURED Installer
# For Ubuntu 24.04 LTS Server
# PyArmor Protected Edition
# ============================================
#
# This installs the PyArmor-protected version of JeSync Pro Dashboard
# Source code is encrypted and cannot be read/modified
#
# Usage: sudo bash install_jesync_dashboard.sh [OPTIONS]
#
# Options:
#   --ip IP           Server IP address (auto-detect if not specified)
#   --port PORT       Dashboard port (default: 5000)
#   --help            Show this help message
#

set -e

# ==================== CONFIGURATION ====================
INSTALL_DIR="/opt/jesync_dashboard"
SERVICE_USER="jesync"
DB_NAME="jesync_users"
DB_USER="jesync_user"
DB_PASS="jsync2026\$"
DASHBOARD_PORT=5000

# ==================== COLORS ====================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

show_help() {
    head -20 "$0" | tail -12
    exit 0
}

detect_ip() {
    ip -4 addr show scope global | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1
}

# ==================== PARSE ARGUMENTS ====================
SERVER_IP=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --ip) SERVER_IP="$2"; shift 2 ;;
        --port) DASHBOARD_PORT="$2"; shift 2 ;;
        --help) show_help ;;
        *) log_error "Unknown option: $1. Use --help for usage." ;;
    esac
done

[[ -z "$SERVER_IP" ]] && SERVER_IP=$(detect_ip)
[[ -z "$SERVER_IP" ]] && log_error "Could not detect server IP. Please specify with --ip"

# ==================== MAIN INSTALLATION ====================
clear
echo -e "${CYAN}"
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║        JeSync Pro Dashboard - SECURED Installer                ║"
echo "║              PyArmor Protected Edition                         ║"
echo "║                  Ubuntu 24.04 LTS                              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""
echo "Configuration:"
echo "  Server IP:      $SERVER_IP"
echo "  Dashboard Port: $DASHBOARD_PORT"
echo "  Install Dir:    $INSTALL_DIR"
echo "  Protection:     PyArmor Encrypted"
echo ""

if [ "$EUID" -ne 0 ]; then
    log_error "Please run as root: sudo bash install_jesync_dashboard.sh"
fi

if ! grep -q "Ubuntu 24" /etc/os-release 2>/dev/null; then
    log_warn "This script is designed for Ubuntu 24.04. Continuing anyway..."
fi

read -p "Continue with installation? [Y/n] " -n 1 -r
echo
[[ $REPLY =~ ^[Nn]$ ]] && exit 0

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TOTAL_STEPS=10
CURRENT_STEP=0

step() {
    ((CURRENT_STEP++))
    echo ""
    echo -e "${BLUE}[$CURRENT_STEP/$TOTAL_STEPS]${NC} $1"
    echo "────────────────────────────────────────────"
}

# ==================== STEP 1: System Update ====================
step "Updating system packages..."
apt update -qq
apt upgrade -y -qq
log_success "System updated"

# ==================== STEP 2: Install Dependencies ====================
step "Installing system dependencies..."
apt install -y -qq \
    python3 python3-pip python3-venv python3-dev \
    postgresql postgresql-contrib \
    redis-server \
    nginx \
    curl wget git \
    build-essential libpq-dev \
    lsb-release ca-certificates apt-transport-https
log_success "Dependencies installed"

# ==================== STEP 3: Configure PostgreSQL ====================
step "Configuring PostgreSQL..."
systemctl enable postgresql
systemctl start postgresql

sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';"

sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"

sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
log_success "PostgreSQL database '$DB_NAME' ready"

# ==================== STEP 4: Configure Redis ====================
step "Configuring Redis..."
systemctl enable redis-server
systemctl start redis-server
log_success "Redis running"

# ==================== STEP 5: Create Service User ====================
step "Creating service user..."
if id -u "$SERVICE_USER" &>/dev/null; then
    log_success "User '$SERVICE_USER' already exists"
else
    useradd -r -m -s /bin/bash -d /home/$SERVICE_USER $SERVICE_USER
    log_success "User '$SERVICE_USER' created"
fi

# ==================== STEP 6: Install Application ====================
step "Installing JeSync Pro Dashboard (SECURED)..."
mkdir -p $INSTALL_DIR/data

# Check for required files
if [ ! -d "$SCRIPT_DIR/pyarmor_runtime_009739" ]; then
    log_error "PyArmor runtime not found. Please ensure you have the complete secured package."
fi

# Copy all files including PyArmor runtime
cp -r "$SCRIPT_DIR"/* $INSTALL_DIR/
rm -f $INSTALL_DIR/install_jesync_dashboard.sh

# Create Python virtual environment
log_info "Creating Python virtual environment..."
python3 -m venv $INSTALL_DIR/venv
$INSTALL_DIR/venv/bin/pip install --upgrade pip -q
$INSTALL_DIR/venv/bin/pip install -r $INSTALL_DIR/requirements.txt -q
log_success "Python environment ready"

# ==================== STEP 7: Configure Application ====================
step "Configuring application..."

# Create .env file
cat > $INSTALL_DIR/.env << EOF
# JeSync Pro Dashboard Configuration
# Generated by installer on $(date)

SECRET_KEY=$(openssl rand -hex 32)

# Database
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME

# Redis
REDIS_URL=redis://localhost:6379/0

# Server
SERVER_IP=$SERVER_IP
DASHBOARD_PORT=$DASHBOARD_PORT
EOF

chown -R $SERVICE_USER:$SERVICE_USER $INSTALL_DIR
chmod 600 $INSTALL_DIR/.env
log_success "Configuration saved"

# ==================== STEP 8: Initialize Database ====================
step "Initializing database..."
cd $INSTALL_DIR
sudo -u $SERVICE_USER $INSTALL_DIR/venv/bin/python seed_users.py 2>/dev/null || log_warn "Seed users skipped (may already exist)"
log_success "Database initialized"

# ==================== STEP 9: Configure Nginx ====================
step "Configuring Nginx..."

cat > /etc/nginx/sites-available/jesync-dashboard << EOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name $SERVER_IP _;

    location / {
        proxy_pass http://127.0.0.1:$DASHBOARD_PORT;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 300s;
        proxy_connect_timeout 10s;
        proxy_send_timeout 60s;
    }

    location /static/ {
        alias $INSTALL_DIR/static/;
        expires 1h;
        add_header Cache-Control "public, immutable";
    }
}
EOF

ln -sf /etc/nginx/sites-available/jesync-dashboard /etc/nginx/sites-enabled/jesync-dashboard
rm -f /etc/nginx/sites-enabled/default

nginx -t && systemctl reload nginx
systemctl enable nginx
log_success "Nginx configured"

# ==================== STEP 10: Configure Systemd Service ====================
step "Setting up systemd service..."

cat > /etc/systemd/system/jesync-dashboard.service << EOF
[Unit]
Description=JeSync Pro Dashboard Server (SECURED)
After=network.target postgresql.service redis-server.service

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
Environment=PATH=$INSTALL_DIR/venv/bin:/usr/local/bin:/usr/bin
EnvironmentFile=$INSTALL_DIR/.env
ExecStart=$INSTALL_DIR/venv/bin/gunicorn --workers 4 --bind 127.0.0.1:$DASHBOARD_PORT --timeout 300 "app:app"
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable jesync-dashboard
systemctl start jesync-dashboard
sleep 3
log_success "Service started"

# ==================== VERIFICATION ====================
echo ""
echo -e "${CYAN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║        INSTALLATION COMPLETE!                                  ║${NC}"
echo -e "${CYAN}║           JeSync Pro Dashboard                                 ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo "Server Information:"
echo "────────────────────────────────────────────"
echo "  Dashboard URL:    http://$SERVER_IP"
echo "  Default Login:    admin / jesyncadmin2026"
echo ""
echo "Services:"
echo "────────────────────────────────────────────"
echo "  systemctl status jesync-dashboard"
echo "  journalctl -u jesync-dashboard -f"
echo ""
echo "License:"
echo "────────────────────────────────────────────"
echo "  To activate your license, go to:"
echo "  Dashboard > Settings > License"
echo ""
echo "  Purchase a license at:"
echo -e "  ${CYAN}https://jesyncpro.com/pricing${NC}"
echo ""

# Check if service is running
sleep 2
if systemctl is-active --quiet jesync-dashboard; then
    echo -e "${GREEN}✓ JeSync Pro Dashboard is ONLINE!${NC}"
else
    echo -e "${YELLOW}⚠ Service may still be starting. Check: systemctl status jesync-dashboard${NC}"
fi
echo ""
