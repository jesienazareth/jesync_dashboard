import httpx
import socket
from uuid import uuid4
import base64
from flask import Blueprint, request, jsonify, render_template, abort
from flask import current_app as app
import mysql.connector
import sqlite3
import json
import random
import string
from datetime import datetime, timedelta
import os

dmaradius_bp = Blueprint("dmaradius", __name__)

@dmaradius_bp.route("/dmaradius", methods=["GET"])
def dmaradius_admin():
    return render_template("dmaradius.html")

# New route for voucher_store.html
@dmaradius_bp.route("/voucher-store", methods=["GET"])
def voucher_store_page():
    vconfig = load_vconfig()
    return render_template(
        "voucher_store.html",
        portal_name=vconfig.get("portal_name", "Jesync Voucher Portal"),
        portal_subtitle=vconfig.get(
            "portal_subtitle",
            "Redefining internet experience with blazing speed and unmatched reliability—powered by Jesync."
        )
    )


# Cleaned /voucher-success route: Only verifies invoice, looks up card, and renders result.
@dmaradius_bp.route("/voucher-success", methods=["GET"])
def voucher_success():
    code = request.args.get("card", "")
    invoice_id = request.args.get("invoice_id", "").strip()
    external_id = request.args.get("external_id", "").strip()
    legacy_id = request.args.get("id", "").strip()
    if not invoice_id and legacy_id:
        invoice_id = legacy_id
    if not invoice_id and external_id:
        invoice_id = external_id
    mapped_invoice_id = lookup_invoice_mapping(invoice_id or external_id)
    if mapped_invoice_id:
        external_id = external_id or invoice_id
        invoice_id = mapped_invoice_id
    print("🧾 Incoming request full args:", request.args)
    amount_raw = request.args.get("amount", "").strip()
    amount = amount_raw.lstrip("₱$").strip()
    try:
        amount = str(int(float(amount)))
    except:
        pass
    payer_email = request.args.get("email", "").strip()

    # Patch: If amount is not a digit, try to load from voucher_history
    if not amount.isdigit():
        try:
            # Lookup amount via voucher_history if missing
            sqlite_conn = sqlite3.connect(SQLITE_DB_PATH)
            sqlite_cursor = sqlite_conn.cursor()
            sqlite_cursor.execute("SELECT amount FROM voucher_history WHERE invoice_id = ?", (invoice_id,))
            row = sqlite_cursor.fetchone()
            sqlite_conn.close()
            if row:
                amount = str(row[0])
                print(f"ℹ️ Loaded amount {amount} from voucher_history for {invoice_id}")
        except Exception as e:
            print("❌ Failed to fetch amount from voucher_history:", e)

    print("🔁 Voucher success triggered with invoice_id:", invoice_id)

    config = load_config()
    vconfig = load_vconfig()

    # 1. If invoice_id is missing, show "No voucher found".
    if not invoice_id:
        print("❌ Missing invoice_id in URL. Cannot verify payment.")
        amount_value = int(amount) if amount.isdigit() else None
        log_voucher_attempt(
            invoice_id=None,
            external_id=external_id,
            amount=amount_value,
            email=payer_email,
            status="MISSING",
            reason="missing_invoice_id"
        )
        return render_template(
            "voucher_success.html",
            cardnum=None,
            success_title=vconfig.get("success_title", "Payment Success!!!"),
            success_message="No voucher found.",
            voucher_body_message=vconfig.get("voucher_body_message", "Copy or Screenshot your voucher for reference, no refund if voucher is lost."),
            footer_note=vconfig.get("footer_note", "Thank you."),
            redirect_url=vconfig.get("redirect_url", "http://10.0.0.1/login"),
            store_name=vconfig.get("portal_name", "Jesync Voucher Portal"),
            store_logo_url=vconfig.get("store_logo_url", "/static/vendo/v-logo.png"),
            service_name="Unknown",
            online_limit="N/A"
        )

    xendit_secret = config.get("xendit_secret_key")
    verified = False
    status = None
    invoice_data = None
    canonical_invoice_id = invoice_id
    if invoice_id and xendit_secret:
        external_lookup = external_id or invoice_id
        invoice_data, fetch_err = fetch_xendit_invoice(
            xendit_secret,
            invoice_id=invoice_id,
            external_id=external_lookup
        )
        if invoice_data:
            # --- Prefer Xendit API data for amount and payer_email if missing ---
            amount = amount or str(invoice_data.get("amount", "")).strip()
            payer_email = payer_email or invoice_data.get("payer_email", "").strip()
            status = invoice_data.get("status")
            if invoice_data.get("id"):
                canonical_invoice_id = invoice_data["id"]
            amount = str(amount).lstrip("₱$").strip()
            try:
                amount = str(int(float(amount)))
            except Exception:
                pass
            print("invoice_id:", canonical_invoice_id, "status:", status)
            if status == "PAID":
                verified = True
        else:
            print("❌ Error verifying invoice from Xendit:", fetch_err)

    # --- Auto-generate voucher if invoice is paid and not yet in voucher_history ---
    if verified:
        invoice_lookup_id = canonical_invoice_id or invoice_id
        print("🔍 PAID invoice confirmed. Checking voucher_history for invoice_id:", invoice_lookup_id)
        try:
            sqlite_conn = sqlite3.connect(SQLITE_DB_PATH)
            sqlite_cursor = sqlite_conn.cursor()
            sqlite_cursor.execute("SELECT cardnum FROM voucher_history WHERE invoice_id = ?", (invoice_lookup_id,))
            row = sqlite_cursor.fetchone()
            sqlite_conn.close()
            # Fetch amount and srvid from Xendit invoice metadata if available
            if not row:
                print(f"🆕 No existing voucher found for {invoice_id}, generating now...")
                config = load_config()
                # Refetch invoice to get metadata for srvid/amount
                xendit_secret = config.get("xendit_secret_key")
                metadata = {}
                if invoice_data:
                    metadata = invoice_data.get("metadata", {})
                elif xendit_secret:
                    invoice_data_meta, fetch_err = fetch_xendit_invoice(
                        xendit_secret,
                        invoice_id=invoice_lookup_id,
                        external_id=external_id or invoice_lookup_id
                    )
                    if invoice_data_meta:
                        metadata = invoice_data_meta.get("metadata", {})
                    else:
                        print("❌ Error fetching invoice for metadata:", fetch_err)
                # Use metadata for amount and srvid if available
                amount_meta = metadata.get("amount", amount)
                if isinstance(amount_meta, (int, float)):
                    amount = str(int(amount_meta))
                else:
                    amount = str(amount_meta).lstrip("₱$").strip()
                    try:
                        amount = str(int(float(amount)))
                    except Exception:
                        pass
                srvid = metadata.get("srvid", None)
                # --- PATCH: Clean plan resolution logic ---
                plan = config.get("plans", {}).get(str(amount))
                if not plan:
                    print(f"❌ Plan for amount {amount} not found. Available plans: {list(config.get('plans', {}).keys())}")
                    return render_template(
                        "voucher_success.html",
                        cardnum=None,
                        success_title=vconfig.get("success_title", "Payment Success!!!"),
                        success_message="Voucher plan not found.",
                        voucher_body_message=vconfig.get("voucher_body_message", "Copy or Screenshot your voucher for reference, no refund if voucher is lost."),
                        footer_note=vconfig.get("footer_note", "Thank you."),
                        redirect_url=vconfig.get("redirect_url", "http://10.0.0.1/login"),
                        store_name=vconfig.get("portal_name", "Jesync Voucher Portal"),
                        store_logo_url=vconfig.get("store_logo_url", "/static/vendo/v-logo.png"),
                        service_name="Unknown",
                        online_limit="N/A"
                    )
                # --- PATCH: srvid resolution ---
                srvid = metadata.get("srvid", None)
                if not srvid:
                    srvid = plan.get("srvid")
                prefix = plan.get("prefix", config.get("prefix", "GCASH"))
                print(f"🛠 Attempting card generation with srvid={srvid} and plan={plan}")
                # Only generate if srvid is present and not already in voucher_history
                if not row and srvid:
                    cardnum = generate_dma_card(config, plan, srvid, prefix)
                    if cardnum:
                        log_to_sqlite(invoice_lookup_id, cardnum, int(amount), srvid)
                        print(f"✅ Generated card {cardnum} for invoice {invoice_lookup_id}")
                        # --- Send voucher receipt email if payer_email is valid and present ---
                        if payer_email and "@" in payer_email:
                            try:
                                import smtplib
                                from email.mime.text import MIMEText
                                smtp_host = config.get("smtp_host")
                                smtp_port = int(config.get("smtp_port", 587))
                                smtp_user = config.get("smtp_user")
                                smtp_pass = config.get("smtp_pass")
                                email_template = config.get("email_template", "").strip()
                                if not email_template:
                                    email_template = (
                                        "Thank you for your payment.\n\n"
                                        "Your voucher is ready:\n\n"
                                        "Code: {cardnum}\n"
                                        "Service: {associated_service}\n"
                                        "Time Limit: {online_limit} mins\n\n"
                                        "Jesync Voucher System"
                                    )
                                body = email_template.format(
                                    cardnum=cardnum,
                                    associated_service=plan.get("associated_service", ""),
                                    online_limit=plan.get("online_limit", "N/A")
                                )
                                print("📧 Preparing to send email:")
                                print("SMTP Host:", smtp_host)
                                print("SMTP Port:", smtp_port)
                                print("SMTP User:", smtp_user)
                                print("To Email:", payer_email)
                                print("Email body:\n", body)
                                msg = MIMEText(body)
                                msg['Subject'] = 'Your Jesync Voucher'
                                msg['From'] = smtp_user
                                msg['To'] = payer_email
                                with smtplib.SMTP(smtp_host, smtp_port) as server:
                                    server.starttls()
                                    server.login(smtp_user, smtp_pass)
                                    server.send_message(msg)
                                print(f"📧 Email sent to {payer_email}")
                            except Exception as e:
                                import traceback
                                traceback.print_exc()
                                print("❌ Email send failed with traceback above.")
        except Exception as e:
            print("❌ Auto-generation error in voucher_success:", e)

    # 2. If invoice is not "PAID", show "No voucher found".
    if not verified:
        print("❌ Invoice not marked as PAID or not found.")
        amount_value = int(amount) if amount.isdigit() else None
        log_voucher_attempt(
            invoice_id=canonical_invoice_id,
            external_id=external_id,
            amount=amount_value,
            email=payer_email,
            status=status or "UNPAID",
            reason="invoice_not_paid"
        )
        return render_template(
            "voucher_success.html",
            cardnum=None,
            success_title=vconfig.get("success_title", "Payment Success!!!"),
            success_message="No voucher found.",
            voucher_body_message=vconfig.get("voucher_body_message", "Copy or Screenshot your voucher for reference, no refund if voucher is lost."),
            footer_note=vconfig.get("footer_note", "Thank you."),
            redirect_url=vconfig.get("redirect_url", "http://10.0.0.1/login"),
            store_name=vconfig.get("portal_name", "Jesync Voucher Portal"),
            store_logo_url=vconfig.get("store_logo_url", "/static/vendo/v-logo.png"),
            service_name="Unknown",
            online_limit="N/A"
        )

    # 3. If invoice is PAID and cardnum exists in voucher_history, show card info.
    cardnum = code  # may be replaced below if empty
    # If cardnum is not present, try to fetch from voucher_history using invoice_id
    if not code and invoice_id:
        invoice_lookup_id = canonical_invoice_id or invoice_id
        try:
            sqlite_conn = sqlite3.connect(SQLITE_DB_PATH)
            sqlite_cursor = sqlite_conn.cursor()
            sqlite_cursor.execute("SELECT cardnum FROM voucher_history WHERE invoice_id = ?", (invoice_lookup_id,))
            row = sqlite_cursor.fetchone()
            sqlite_conn.close()
            if row:
                cardnum = row[0]
                print(f"✅ Fetched cardnum '{cardnum}' from voucher_history for invoice_id '{invoice_lookup_id}'")
        except Exception as e:
            print("❌ Failed to load cardnum from voucher_history:", e)
    service_name = "Unknown"
    online_limit = "N/A"
    # Only look up card info if cardnum is present.
    if cardnum:
        try:
            sqlite_conn = sqlite3.connect(SQLITE_DB_PATH)
            sqlite_cursor = sqlite_conn.cursor()
            sqlite_cursor.execute("SELECT associated_service, online_limit FROM voucher_cards WHERE cardnum = ?", (cardnum,))
            row = sqlite_cursor.fetchone()
            sqlite_conn.close()
            if row:
                service_name, online_limit = row
        except Exception as e:
            print("❌ Failed to load voucher info from sqlite:", e)

    return render_template(
        "voucher_success.html",
        cardnum=cardnum,
        success_title=vconfig.get("success_title", "Payment Success!!!"),
        success_message=vconfig.get("success_message", "Voucher generated successfully!"),
        voucher_body_message=vconfig.get("voucher_body_message", "Copy or Screenshot your voucher for reference, no refund if voucher is lost."),
        footer_note=vconfig.get("footer_note", "Thank you."),
        redirect_url=vconfig.get("redirect_url", "http://10.0.0.1/login"),
        store_name=vconfig.get("portal_name", "Jesync Voucher Portal"),
        store_logo_url=vconfig.get("store_logo_url", "/static/vendo/v-logo.png"),
        service_name=service_name,
        online_limit=online_limit
    )

# --- Configurable paths ---
CONFIG_PATH = "/opt/libreqos/src/jesync_dashboard/modules/dmaradius_config.json"
SQLITE_DB_PATH = "/opt/libreqos/src/jesync_dashboard/db/dma_card.db"
# VCONFIG_PATH = "/opt/libreqos/src/jesync_dashboard/modules/vconfig.json"


# --- Utility functions ---
def load_config():
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)

def load_vconfig():
    path = "/opt/libreqos/src/jesync_dashboard/modules/dmaradius_config.json"
    if not os.path.exists(path):
        return {
            "portal_name": "Jesync Voucher Portal",
            "portal_subtitle": "Redefining internet experience with blazing speed and unmatched reliability—powered by Jesync."
        }
    with open(path, "r") as f:
        return json.load(f)

def save_vconfig(data):
    with open("/opt/libreqos/src/jesync_dashboard/modules/dmaradius_config.json", "w") as f:
        json.dump(data, f, indent=2)

# --- Xendit helpers ---
def fetch_xendit_invoice(xendit_secret, invoice_id=None, external_id=None):
    if not xendit_secret:
        return None, "missing_secret"
    import base64, requests
    headers = {
        "Authorization": "Basic " + base64.b64encode(f"{xendit_secret}:".encode()).decode()
    }
    if invoice_id:
        try:
            resp = requests.get(f"https://api.xendit.co/v2/invoices/{invoice_id}", headers=headers, timeout=5)
            if resp.status_code == 200:
                return resp.json(), None
        except Exception as e:
            return None, f"invoice_lookup_error: {e}"
    if external_id:
        try:
            resp = requests.get(
                "https://api.xendit.co/v2/invoices",
                headers=headers,
                params={"external_id": external_id},
                timeout=5
            )
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, list) and data:
                    return data[0], None
                if isinstance(data, dict):
                    if data.get("id"):
                        return data, None
                    for key in ("data", "invoices"):
                        records = data.get(key)
                        if isinstance(records, list) and records:
                            return records[0], None
        except Exception as e:
            return None, f"external_lookup_error: {e}"
    return None, "not_found"

def log_voucher_attempt(invoice_id=None, external_id=None, amount=None, email=None, status=None, reason=None):
    conn = None
    try:
        conn = sqlite3.connect(SQLITE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS voucher_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invoice_id TEXT,
                external_id TEXT,
                amount INTEGER,
                email TEXT,
                status TEXT,
                reason TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("""
            INSERT INTO voucher_attempts (invoice_id, external_id, amount, email, status, reason)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (invoice_id, external_id, amount, email, status, reason))
        conn.commit()
    except Exception as e:
        print("❌ Failed to log voucher attempt:", e)
    finally:
        if conn:
            conn.close()

def save_invoice_mapping(external_id, invoice_id, amount=None, email=None):
    if not external_id or not invoice_id:
        return
    conn = None
    try:
        conn = sqlite3.connect(SQLITE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS voucher_invoices (
                external_id TEXT PRIMARY KEY,
                invoice_id TEXT,
                amount INTEGER,
                email TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("""
            INSERT OR REPLACE INTO voucher_invoices (external_id, invoice_id, amount, email)
            VALUES (?, ?, ?, ?)
        """, (external_id, invoice_id, amount, email))
        conn.commit()
    except Exception as e:
        print("❌ Failed to save invoice mapping:", e)
    finally:
        if conn:
            conn.close()

def lookup_invoice_mapping(external_id):
    if not external_id:
        return None
    conn = None
    try:
        conn = sqlite3.connect(SQLITE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS voucher_invoices (
                external_id TEXT PRIMARY KEY,
                invoice_id TEXT,
                amount INTEGER,
                email TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cursor.execute("SELECT invoice_id FROM voucher_invoices WHERE external_id = ?", (external_id,))
        row = cursor.fetchone()
        return row[0] if row else None
    except Exception as e:
        print("❌ Failed to lookup invoice mapping:", e)
        return None
    finally:
        if conn:
            conn.close()

# --- Live DMA Radius utility functions ---
def fetch_user_groups_from_mysql(config):
    try:
        conn = mysql.connector.connect(
            host=config["dma_host"],
            user=config["dma_user"],
            password=config["dma_pass"],
            database=config["dma_db"]
        )
        cursor = conn.cursor()
        cursor.execute("SELECT groupid, groupname FROM rm_usergroups ORDER BY groupname ASC")
        groups = [{"groupid": row[0], "groupname": row[1]} for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return groups
    except Exception as e:
        print("⚠️ Failed to fetch user groups:", e)
        return []

def fetch_services_from_mysql(config):
    try:
        conn = mysql.connector.connect(
            host=config["dma_host"],
            user=config["dma_user"],
            password=config["dma_pass"],
            database=config["dma_db"]
        )
        cursor = conn.cursor()
        cursor.execute("SELECT srvname FROM rm_services")
        services = [row[0] for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return services
    except Exception as e:
        print("⚠️ Failed to fetch services:", e)
        return []

def generate_card_code(prefix="GCASH", length=6):
    return prefix + ''.join(random.choices(string.digits, k=length))

def insert_to_dma_radius(config, cardnum, password, value, srvid, plan, owner="admin"):
    try:
        conn = mysql.connector.connect(
            host=config["dma_host"],
            user=config["dma_user"],
            password=config["dma_pass"],
            database=config["dma_db"]
        )
        cursor = conn.cursor()

        # --- Validation for srvid and associated_service ---
        if "srvid" not in plan or plan.get("srvid") is None:
            print("❌ Plan missing 'srvid'.")
            return False
        if "associated_service" not in plan or not plan.get("associated_service"):
            # Fallback to config["available_services"][0] if present
            available_services = config.get("available_services", [""])
            if not available_services or not available_services[0]:
                print("❌ Plan missing 'associated_service', and no available_services in config.")
                return False

        # Extract per-plan fields with fallback to config defaults
        gross_value = plan.get("gross_value", value)
        prefix = plan.get("prefix", config.get("prefix", "GCASH"))
        pin_length = plan.get("pin_length", 6)
        password_length = plan.get("password_length", 0)
        simultaneous_use = plan.get("simultaneous_use", 1)
        user_group = plan.get("user_group", "")
        # expiretime: available_from (minutes, possibly 0)
        expiretime = int(plan.get("available_from", 0) or 0)
        # uptimelimit: online_limit (minutes), fallback to config time_limit
        uptimelimit = int(plan.get("online_limit", config.get("time_limit", 180)) or 0)
        # expiration_date: plan_valid_till (YYYY-MM-DD), fallback to (now + N days)
        expiration_date = plan.get("valid_till")
        try:
            valid_till_days = int(plan.get("valid_till", 30)) if not expiration_date else 30
        except ValueError:
            valid_till_days = 30
        if not expiration_date:
            expiration_date = (datetime.now() + timedelta(days=valid_till_days)).strftime("%Y-%m-%d")
        # Generate password if password_length > 0
        if password_length > 0:
            password = ''.join(random.choices(string.ascii_letters + string.digits, k=password_length))
        else:
            password = ""

        # Ensure srvid comes from plan, fallback to argument srvid
        srvid_for_insert = plan.get("srvid")
        if srvid_for_insert is None:
            srvid_for_insert = srvid
        # Always fetch the correct associated service name based on srvid (even if fallback would be available)
        associated_service_for_insert = ""
        # Early and safe resolution of associated_service using srvid
        if srvid_for_insert is not None:
            cursor.execute("SELECT srvname FROM rm_services WHERE srvid = %s", (srvid_for_insert,))
            result = cursor.fetchone()
            if result:
                associated_service_for_insert = result[0]
        # Only fallback to plan if still missing
        if not associated_service_for_insert:
            associated_service_for_insert = plan.get("associated_service") or ""
        # Safety check: associated_service must not be empty
        if not associated_service_for_insert:
            print(f"❌ associated_service is empty for plan: {plan}")
            return False
        # Ensure uptimelimit from plan["online_limit"]
        uptimelimit_for_insert = int(plan.get("online_limit", config.get("time_limit", 180)) or 0)

        # Ensure expiration_date fallback is set immediately before insert
        if not expiration_date:
            expiration_date = (datetime.now() + timedelta(days=valid_till_days)).strftime("%Y-%m-%d")
        # Ensure voucher is calculated from activation
        timebaseexp = 1  # Ensure voucher is calculated from activation
        query = f"""
            INSERT INTO rm_cards (
                cardnum, password, value, expiration, series, date, owner,
                used, cardtype, revoked, downlimit, uplimit, comblimit, uptimelimit,
                srvid, transid, active, expiretime, timebaseexp, timebaseonline, simultaneous_use, associated_service, gross_value
            ) VALUES (
                %s, %s, %s, %s, %s, NOW(), %s,
                %s, %s, %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
        """
        series = config.get("series")
        if not series or not isinstance(series, str) or not series.strip():
            series = prefix if prefix else "GCASH"
        try:
            cursor.execute(query, (
                cardnum,             # cardnum
                password,            # password
                value,               # value
                expiration_date,     # expiration
                series,              # series
                owner,               # owner
                0,                   # used
                0,                   # cardtype
                0,                   # revoked
                0,                   # downlimit
                0,                   # uplimit
                0,                   # comblimit
                uptimelimit_for_insert,         # uptimelimit (plan_online_limit)
                srvid_for_insert,               # srvid (plan_srvid)
                f"xendit_{cardnum}", # transid
                1,                   # active
                expiretime,          # expiretime (plan_available_from)
                timebaseexp,         # timebaseexp (always 1)
                1,                   # timebaseonline
                simultaneous_use,    # simultaneous_use
                associated_service_for_insert,  # associated_service
                gross_value          # gross_value
            ))
        except mysql.connector.Error as err:
            print("❌ DMA Radius Insert Error:", err)
            return False

        # --- Insert user into rm_users and related radius tables if not exists ---
        # Insert user into rm_users if not exists
        cursor.execute("SELECT username FROM rm_users WHERE username = %s", (cardnum,))
        if cursor.fetchone() is None:
            cursor.execute("""
                INSERT INTO rm_users (
                    username, password, macpswmode, groupid, enableuser, uplimit, downlimit,
                    comblimit, firstname, lastname, company, phone, mobile, address, city, zip,
                    country, state, comment, gpslat, gpslong, mac, usemacauth, expiration,
                    uptimelimit, srvid, staticipcm, staticipcpe, ipmodecm, ipmodecpe, poolidcm,
                    poolidcpe, createdon, acctype, credits, cardfails, createdby, owner, taxid,
                    cnic, email, maccm, custattr, warningsent, verifycode, verified, selfreg,
                    verifyfails, verifysentnum, verifymobile, contractid, contractvalid, actcode,
                    pswactsmsnum, alertsms, lang, lastlogoff, cnicfile1, cnicfile2,
                    billing_month, user_city_id, user_area_id, autorenew
                ) VALUES (
                    %s, '', 0, %s, 1, 0, 0,
                    0, '', '', '', '', '', '', '', '',
                    '', '', '', 0, 0, '', 0,
                    0, %s, '', '', 0, 0, 0,
                    0, CURDATE(), 1, 0, 0, %s, %s,
                    '', '', '', '', 0, '', 0, 0,
                    0, 0, '', '', '', '', 0, 0,
                    0, 'English', NULL, NULL, NULL,
                    0, 0, 0, 0, 0
                )
            """, (cardnum, user_group, srvid_for_insert, owner, owner))

        # Insert into radcheck for Cleartext-Password (empty string)
        cursor.execute("SELECT * FROM radcheck WHERE username=%s AND attribute='Cleartext-Password'", (cardnum,))
        if cursor.fetchone() is None:
            cursor.execute("""
                INSERT INTO radcheck (username, attribute, op, value)
                VALUES (%s, 'Cleartext-Password', ':=', '')
            """, (cardnum,))

        # Insert into radcheck for Simultaneous-Use
        cursor.execute("SELECT * FROM radcheck WHERE username=%s AND attribute='Simultaneous-Use'", (cardnum,))
        if cursor.fetchone() is None and simultaneous_use > 0:
            cursor.execute("""
                INSERT INTO radcheck (username, attribute, op, value)
                VALUES (%s, 'Simultaneous-Use', ':=', %s)
            """, (cardnum, str(simultaneous_use)))

        # Insert into radusergroup for group assignment
        cursor.execute("SELECT groupname FROM rm_usergroups WHERE groupid = %s", (user_group,))
        result = cursor.fetchone()
        groupname_str = result[0] if result else user_group  # fallback to raw user_group if no match
        cursor.execute("SELECT * FROM radusergroup WHERE username=%s AND groupname=%s", (cardnum, groupname_str))
        if cursor.fetchone() is None:
            cursor.execute("""
                INSERT INTO radusergroup (username, groupname, priority)
                VALUES (%s, %s, 1)
            """, (cardnum, groupname_str))

        conn.commit()
        print(f"✅ Inserted card {cardnum} with service '{associated_service_for_insert}', group '{user_group}', simultaneous_use={simultaneous_use}, expiretime={expiretime}, uptimelimit={uptimelimit_for_insert}")
        cursor.close()
        conn.close()
        # Log to local sqlite voucher_cards
        try:
            sqlite_conn = sqlite3.connect(SQLITE_DB_PATH)
            sqlite_cursor = sqlite_conn.cursor()
            sqlite_cursor.execute("""
                CREATE TABLE IF NOT EXISTS voucher_cards (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    cardnum TEXT,
                    srvid INTEGER,
                    associated_service TEXT,
                    user_group TEXT,
                    simultaneous_use INTEGER,
                    expiretime INTEGER,
                    online_limit INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            sqlite_cursor.execute("""
                INSERT INTO voucher_cards (cardnum, srvid, associated_service, user_group, simultaneous_use, expiretime, online_limit)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                cardnum, srvid_for_insert, associated_service_for_insert, user_group, simultaneous_use, expiretime, uptimelimit_for_insert
            ))
            sqlite_conn.commit()
            sqlite_conn.close()
        except Exception as e:
            print("❌ Failed to log to local voucher_cards:", e)
        return True
    except Exception as e:
        print("❌ MySQL Error:", e)
        return False

def log_to_sqlite(invoice_id, cardnum, amount, srvid):
    conn = sqlite3.connect(SQLITE_DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS voucher_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            invoice_id TEXT UNIQUE,
            amount INTEGER,
            cardnum TEXT,
            srvid INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    try:
        cursor.execute("""
            INSERT INTO voucher_history (invoice_id, amount, cardnum, srvid)
            VALUES (?, ?, ?, ?)
        """, (invoice_id, amount, cardnum, srvid))
        conn.commit()
    except sqlite3.IntegrityError:
        print(f"⚠️ invoice_id {invoice_id} already exists in voucher_history — skipping insert.")
    finally:
        conn.close()

# --- Webhook Endpoint ---
@dmaradius_bp.route("/xendit/webhook", methods=["POST"])
def xendit_webhook():
    from flask import redirect, url_for
    payload = request.get_json()
    print("📩 Webhook received:", payload)
    try:
        amount_value = int(payload.get("amount", 0))
    except Exception:
        amount_value = None
    save_invoice_mapping(
        external_id=payload.get("external_id"),
        invoice_id=payload.get("id"),
        amount=amount_value,
        email=payload.get("payer_email", "")
    )

    if payload.get("status") != "PAID":
        print("ℹ️ Ignored: status is not PAID.")
        log_voucher_attempt(
            invoice_id=payload.get("id"),
            external_id=payload.get("external_id"),
            amount=amount_value,
            email=payload.get("payer_email", ""),
            status=payload.get("status"),
            reason="webhook_non_paid"
        )
        return jsonify({"message": "Ignored non-paid invoice"}), 200

    invoice_id = payload.get("id")
    try:
        amount = int(payload.get("amount", 0))
    except Exception:
        print("❌ Invalid or missing amount in payload:", payload)
        abort(400, description="Invalid or missing amount")
    payer_email = payload.get("payer_email", "").strip()
    config = load_config()

    # Check if invoice_id already exists in SQLite to prevent duplicate generation
    try:
        conn = sqlite3.connect(SQLITE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT cardnum FROM voucher_history WHERE invoice_id = ?", (invoice_id,))
        row = cursor.fetchone()
        cursor.close()
        conn.close()
        if row:
            existing_card = row[0]
            print(f"⚠️ Duplicate webhook: invoice_id {invoice_id} already used. Reusing card: {existing_card}")
            return redirect(url_for("dmaradius.voucher_success", card=existing_card, amount=amount, email=payer_email, invoice_id=invoice_id))
    except Exception as e:
        print("❌ Failed to check for duplicate invoice_id in webhook:", e)

    plan = config["plans"].get(str(amount))
    if not plan:
        print("❌ Unmapped plan for amount:", amount)
        abort(400, description="Unmapped plan for amount")

    srvid = plan.get("srvid")
    if not srvid:
        service_name = plan.get("associated_service")
        if not service_name:
            print("❌ Plan missing srvid and associated_service.")
            abort(400, description="Plan missing srvid and associated_service")
        try:
            conn = mysql.connector.connect(
                host=config["dma_host"],
                user=config["dma_user"],
                password=config["dma_pass"],
                database=config["dma_db"]
            )
            cursor = conn.cursor()
            cursor.execute("SELECT srvid FROM rm_services WHERE srvname = %s", (service_name,))
            result = cursor.fetchone()
            if result:
                srvid = result[0]
                plan["srvid"] = srvid
                print(f"✅ Resolved srvid={srvid} for service '{service_name}'")
            else:
                print(f"❌ No srvid found for service '{service_name}'")
                abort(400, description="Service not found in rm_services")
            cursor.close()
            conn.close()
        except Exception as e:
            print("❌ Exception during srvid resolution:", e)
            abort(500, description="Error resolving srvid")
    if not plan.get("associated_service"):
        print("❌ Plan missing associated_service.")
        abort(400, description="Plan missing associated_service")

    prefix = plan.get("prefix", config.get("prefix", "GCASH"))
    print(f"🔑 Generating voucher for amount {amount}, srvid {srvid}, prefix {prefix}")
    # --- Debug lines before card generation ---
    print("🔍 Invoice ID:", invoice_id)
    print("📨 Plan loaded:", plan)
    print("📌 SRVID:", srvid)
    print("📛 Prefix:", prefix)
    # Additional debug after checking for card: plan and srvid/prefix
    print("📊 Plan being used for card generation:", plan)
    print("🧪 Generating card using srvid:", srvid, "and prefix:", prefix)
    # --- Generate cardnum using the same logic as manual_generate ---
    cardnum = generate_dma_card(config, plan, srvid, prefix)
    # Debug print after card generation
    print("✅ generate_dma_card returned:", cardnum)
    # --- Debug after card generation ---
    print("🆕 Generated cardnum:", cardnum)

    # Check cardnum is not None, log result, and send email if needed
    if not cardnum:
        print("❌ Card generation returned None. Plan:", plan, "SRVID:", srvid)
        print("❌ generate_dma_card returned None in webhook.")
        return jsonify({"error": "Card generation failed"}), 500

    # Reinforce log_to_sqlite with debug print and ensure correct logging
    log_to_sqlite(invoice_id, cardnum, amount, srvid)
    print(f"📦 Logged to voucher_history: {cardnum}, amount={amount}, srvid={srvid}")

    # Send voucher receipt email if payer_email is valid and present
    if payer_email and "@" in payer_email:
        try:
            import smtplib
            from email.mime.text import MIMEText
            smtp_host = config.get("smtp_host")
            smtp_port = config.get("smtp_port", 587)
            smtp_user = config.get("smtp_user")
            smtp_pass = config.get("smtp_pass")
            email_template = config.get("email_template", "").strip()
            if not email_template:
                email_template = (
                    "Thank you for your payment.\n\n"
                    "Your voucher is ready:\n\n"
                    "Code: {cardnum}\n"
                    "Service: {associated_service}\n"
                    "Time Limit: {online_limit} mins\n\n"
                    "Jesync Voucher System"
                )
            body = email_template.format(
                cardnum=cardnum,
                associated_service=plan.get("associated_service", ""),
                online_limit=plan.get("online_limit", "N/A")
            )
            msg = MIMEText(body)
            msg['Subject'] = 'Your Jesync Voucher'
            msg['From'] = smtp_user
            msg['To'] = payer_email
            with smtplib.SMTP(smtp_host, smtp_port) as server:
                server.starttls()
                server.login(smtp_user, smtp_pass)
                server.send_message(msg)
            print(f"📧 Email sent to {payer_email}")
        except Exception as e:
            print("❌ Email send failed:", e)

    print(f"➡️ Redirecting to voucher success page for card: {cardnum}")
    # Ensure redirect appends card number properly with full context
    return redirect(url_for("dmaradius.voucher_success", card=cardnum, amount=amount, email=payer_email, invoice_id=invoice_id))

# Load config file or default
def save_config(data):
    with open(CONFIG_PATH, "w") as f:
        json.dump(data, f, indent=2)

@dmaradius_bp.route("/dmaradius/config", methods=["GET"])
def get_config():
    if not os.path.exists(CONFIG_PATH):
        return jsonify({
            "dma_host": "localhost",
            "dma_user": "radius",
            "dma_pass": "",
            "dma_db": "radius",
            "owner": "admin",
            "prefix": "GCASH",
            "series": "GCASH",
            "time_limit": 180,
            "plans": {
                "5": {
                    "srvid": 3,
                    "plan_name": "Voucher 5PHP",
                    "comment": "Valid for 30 minutes, single device"
                },
                "10": {
                    "srvid": 5,
                    "plan_name": "Voucher 10PHP",
                    "comment": "Valid for 1 hour, single device"
                }
            },
            "xendit_secret_key": "",
            "webhook_token": "",
            "available_user_groups": [],
            "available_services": [],
            "admin_user": ""
        })
    with open(CONFIG_PATH) as f:
        config = json.load(f)
        config.setdefault("available_user_groups", [])
        config.setdefault("available_services", [])
        # Ensure admin_user is present in config
        config.setdefault("admin_user", "")
        try:
            live_groups = fetch_user_groups_from_mysql(config)
            print("📡 Live Groups from DMA Radius:", live_groups)
            # live_groups is now a list of dicts [{"groupid":..., "groupname":...}]
            config["available_user_groups"] = live_groups if isinstance(live_groups, list) else []
        except Exception as e:
            print("❌ Error loading groups:", e)
            config["available_user_groups"] = []
        print("✅ Final user groups being sent to config:", config["available_user_groups"])
        live_services = fetch_services_from_mysql(config)
        print("📡 Live Services from DMA Radius:", live_services)
        config["available_services"] = sorted(set(live_services))
        # Debug print before returning config
        return jsonify(config)


@dmaradius_bp.route("/dmaradius/config", methods=["POST"])
def update_config():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data received"}), 400

        # Start with current config and update only provided fields
        current_config = load_config()
        current_config["dma_host"] = data.get("dma_host", current_config.get("dma_host"))
        current_config["dma_user"] = data.get("dma_user", current_config.get("dma_user"))
        current_config["dma_pass"] = data.get("dma_pass", current_config.get("dma_pass"))
        current_config["dma_db"] = data.get("dma_db", current_config.get("dma_db"))
        current_config["owner"] = data.get("owner", current_config.get("owner"))
        current_config["prefix"] = data.get("prefix", current_config.get("prefix"))
        current_config["series"] = data.get("series", current_config.get("series"))
        current_config["time_limit"] = data.get("time_limit", current_config.get("time_limit"))
        current_config["xendit_secret_key"] = data.get("xendit_secret_key", current_config.get("xendit_secret_key"))
        current_config["webhook_token"] = data.get("webhook_token", current_config.get("webhook_token"))

        # Accept plans with plan_name and comment fields (no backend validation required)
        current_config["plans"] = data.get("plans", current_config.get("plans", {}))

        # Patch: Add srvid lookup per plan if associated_service is present
        for amount, plan in current_config["plans"].items():
            service_name = plan.get("associated_service")
            if service_name:
                try:
                    conn = mysql.connector.connect(
                        host=current_config["dma_host"],
                        user=current_config["dma_user"],
                        password=current_config["dma_pass"],
                        database=current_config["dma_db"]
                    )
                    cursor = conn.cursor()
                    cursor.execute("SELECT srvid FROM rm_services WHERE srvname = %s", (service_name,))
                    result = cursor.fetchone()
                    if result:
                        plan["srvid"] = result[0]
                        print(f"✅ Injected srvid={result[0]} for service='{service_name}' in plan ₱{amount}")
                    cursor.close()
                    conn.close()
                except Exception as e:
                    print(f"❌ Failed to resolve srvid for service '{service_name}':", e)
            # Convert online_limit and available_from to minutes if units are set to "hours"
            unit1 = plan.get("online_limit_unit", "minutes")
            unit2 = plan.get("available_from_unit", "minutes")
            try:
                plan["online_limit"] = int(plan.get("online_limit", 180)) * (60 if unit1 == "hours" else 1)
            except Exception:
                plan["online_limit"] = 180
            try:
                plan["available_from"] = int(plan.get("available_from", 0)) * (60 if unit2 == "hours" else 1)
            except Exception:
                plan["available_from"] = 0
            # Remove the unit fields after conversion
            plan.pop("online_limit_unit", None)
            plan.pop("available_from_unit", None)

        # Also update SMTP-related fields
        current_config["smtp_host"] = data.get("smtp_host", current_config.get("smtp_host", ""))
        current_config["smtp_port"] = data.get("smtp_port", current_config.get("smtp_port", 587))
        current_config["smtp_user"] = data.get("smtp_user", current_config.get("smtp_user", ""))
        current_config["smtp_pass"] = data.get("smtp_pass", current_config.get("smtp_pass", ""))
        current_config["email_template"] = data.get("email_template", current_config.get("email_template", ""))

        # Update admin_user field
        current_config["admin_user"] = data.get("admin_user", current_config.get("admin_user", ""))

        # Update available_user_groups from data if provided, else set default
        if "available_user_groups" in data:
            current_config["available_user_groups"] = data["available_user_groups"]
        else:
            current_config.setdefault("available_user_groups", [])

        if "available_services" in data:
            current_config["available_services"] = data["available_services"]
        else:
            current_config.setdefault("available_services", [])

        save_config(current_config)
        return jsonify({"message": "Config updated"}), 200
    except Exception as e:
        print("❌ Failed to save config:", e)
        return jsonify({"error": "Failed to save config"}), 500

# --- Logo Upload Endpoint ---
@dmaradius_bp.route("/dmaradius/upload-logo", methods=["POST"])
def upload_voucher_logo():
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded"}), 400
        file = request.files["file"]
        if file.filename == "":
            return jsonify({"error": "Empty filename"}), 400
        # Ensure it's a PNG for consistency
        if not file.filename.lower().endswith(".png"):
            return jsonify({"error": "Only PNG format allowed"}), 400

        # Save the uploaded file as v-logo.png
        save_path = "/opt/libreqos/src/jesync_dashboard/static/vendo/v-logo.png"
        file.save(save_path)
        return jsonify({"message": "Logo uploaded successfully"}), 200
    except Exception as e:
        print("❌ Logo upload error:", e)
        return jsonify({"error": "Failed to upload logo"}), 500

# --- Xendit Invoice Creation Endpoint ---
@dmaradius_bp.route("/xendit/create-invoice", methods=["POST"])
def create_invoice():
    data = request.get_json()
    config = load_config()
    amount = int(data.get("amount", 0))
    payer_email = data.get("payer_email", "voucher@jesync.com")
    redirect_url = data.get("redirect_url")
    srvid = data.get("srvid")
    secret_key = config.get("xendit_secret_key")

    if not amount or not secret_key:
        abort(400, description="Missing amount or Xendit key")

    def base64_auth(secret):
        return base64.b64encode(f"{secret}:".encode()).decode()

    # Generate external_id for use only in invoice body, not for lookups
    external_id = f"voucher_{uuid4().hex[:12]}"
    headers = {
        "Authorization": f"Basic {base64_auth(secret_key)}",
        "Content-Type": "application/json"
    }
    body = {
        "external_id": external_id,
        "payer_email": payer_email,
        "description": f"Voucher ₱{amount}",
        "amount": amount,
        "metadata": {
            "srvid": srvid,
            "amount": amount
        }
    }
    # Only include success_redirect_url if redirect_url is provided (append invoice_id param)
    if redirect_url:
        body["success_redirect_url"] = f"{redirect_url}?invoice_id={external_id}"

    async def post_invoice():
        async with httpx.AsyncClient() as client:
            resp = await client.post("https://api.xendit.co/v2/invoices", headers=headers, json=body)
            if resp.status_code != 200:
                abort(resp.status_code, description=resp.text)
            return resp.json()

    import asyncio
    result = asyncio.run(post_invoice())

    save_invoice_mapping(
        external_id=external_id,
        invoice_id=result.get("id"),
        amount=amount,
        email=payer_email
    )

    print("📄 Xendit Invoice URL:", result.get("invoice_url"))
    # Return the patched success_redirect_url
    return jsonify({
        "invoice_url": result.get("invoice_url"),
        "qr_string": result.get("qr_string", result.get("invoice_url")),
        "invoice_id": external_id,
        "success_redirect_url": body["success_redirect_url"]
    })

@dmaradius_bp.route("/dmaradius/manual-generate", methods=["POST"])
def manual_generate():
    try:
        data = request.get_json()
        email = data.get("email", "").strip()
        amount_raw = str(data.get("amount", "")).strip()
        # Strip currency symbols ₱ and $ if present
        amount = amount_raw.lstrip("₱$").strip()
        if not amount or not amount.isdigit():
            return jsonify({"status": "error", "message": "Invalid or missing amount"}), 400

        config = load_config()
        print("🧪 Amount received:", amount)
        print("📦 Available plans:", list(config.get("plans", {}).keys()))
        plan = config.get("plans", {}).get(amount)
        if not plan:
            return jsonify({"status": "error", "message": "Plan not found for selected amount"}), 400

        # Ensure srvid is present in plan and checked, or resolve by associated_service if missing
        srvid = plan.get("srvid")
        if not srvid:
            # Try resolving srvid by associated_service
            service_name = plan.get("associated_service")
            if not service_name:
                return jsonify({"status": "error", "message": "Missing srvid and associated_service in selected plan"}), 400
            try:
                conn = mysql.connector.connect(
                    host=config["dma_host"],
                    user=config["dma_user"],
                    password=config["dma_pass"],
                    database=config["dma_db"]
                )
                cursor = conn.cursor()
                cursor.execute("SELECT srvid FROM rm_services WHERE srvname = %s", (service_name,))
                result = cursor.fetchone()
                if result:
                    srvid = result[0]
                    plan["srvid"] = srvid  # Save it back to plan
                else:
                    return jsonify({"status": "error", "message": f"Service '{service_name}' not found in DMA"}), 400
                cursor.close()
                conn.close()
            except Exception as e:
                return jsonify({"status": "error", "message": f"Database error while resolving srvid: {e}"}), 500

        prefix = plan.get("prefix", config.get("prefix", "GCASH"))
        # Only generate cardnum, use the new helper function for all DB logic
        cardnum = generate_dma_card(config, plan, srvid, prefix)
        if not cardnum:
            return jsonify({"status": "error", "message": "Failed to insert voucher"}), 500

        # Log using a dummy invoice ID for manual
        log_to_sqlite(f"manual_{cardnum}", cardnum, int(amount), srvid)

        # Send voucher receipt email if email is valid and present
        if email and "@" in email:
            try:
                import smtplib
                from email.mime.text import MIMEText
                smtp_host = config.get("smtp_host")
                smtp_port = config.get("smtp_port", 587)
                smtp_user = config.get("smtp_user")
                smtp_pass = config.get("smtp_pass")
                email_template = config.get("email_template", "").strip()
                if not email_template:
                    email_template = (
                        "Thank you for your payment.\n\n"
                        "Your voucher is ready:\n\n"
                        "Code: {cardnum}\n"
                        "Service: {associated_service}\n"
                        "Time Limit: {online_limit} mins\n\n"
                        "Jesync Voucher System"
                    )
                body = email_template.format(
                    cardnum=cardnum,
                    associated_service=plan.get("associated_service", ""),
                    online_limit=plan.get("online_limit", "N/A")
                )
                print("📧 Preparing to send email:")
                print("SMTP Host:", smtp_host)
                print("SMTP Port:", smtp_port)
                print("SMTP User:", smtp_user)
                print("To Email:", email)
                print("Email body:\n", body)
                msg = MIMEText(body)
                msg['Subject'] = 'Your Jesync Voucher'
                msg['From'] = smtp_user
                msg['To'] = email
                with smtplib.SMTP(smtp_host, smtp_port) as server:
                    server.starttls()
                    server.login(smtp_user, smtp_pass)
                    server.send_message(msg)
                print(f"📧 Email sent to {email}")
            except Exception as e:
                import traceback
                traceback.print_exc()
                print("❌ Email send failed with traceback above.")

        return jsonify({
            "status": "success",
            "message": f"✅ Voucher {cardnum} has been created.",
            "cardnum": cardnum
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        print("❌ Manual Generator Error:", e)
        return jsonify({
            "status": "error",
            "message": f"Exception: {str(e)}"
        }), 500

# --- DMA Card Generator Logic (from dma_card_test.py, fully integrated) ---
def generate_dma_card(config, plan, srvid, prefix="GCASH"):
    # use the passed-in config directly
    import mysql.connector
    import random
    import string
    from datetime import datetime

    # --- Enforce strict valid_till requirement and fixed-date expiration ---
    if "valid_till" not in plan:
        raise ValueError("Plan must include 'valid_till' for strict expiration")
    expiration_date = plan["valid_till"]
    expiremode = 0
    # Always treat available_from and online_limit as minutes
    online_limit = int(plan.get("online_limit", 180))  # Always in minutes
    expiretime_sql = int(plan.get("available_from", 0))  # Always in minutes
    timebaseexp_sql = 1

    cardnum = prefix + ''.join(random.choices(string.digits, k=6))
    password = ""
    password_md5 = "d41d8cd98f00b204e9800998ecf8427e"
    groupid = plan.get("user_group", 1)
    simultaneous_use = int(plan.get("simultaneous_use", 1))
    associated_service = plan.get("associated_service", "CARD PREPAID")
    gross_value = int(plan.get("gross_value", 5))
    try:
        conn = mysql.connector.connect(
            host=config["dma_host"],
            user=config["dma_user"],
            password=config["dma_pass"],
            database=config["dma_db"]
        )
        cursor = conn.cursor()

        # Insert into rm_cards, using expiretime_sql and timebaseexp_sql
        cursor.execute(
            "INSERT INTO rm_cards (cardnum, password, value, expiration, series, date, owner, used, cardtype, revoked, downlimit, uplimit, comblimit, uptimelimit, srvid, transid, active, expiretime, timebaseexp, timebaseonline, simultaneous_use, associated_service, gross_value) VALUES (%s, %s, %s, %s, %s, NOW(), %s, 0, 0, 0, 0, 0, 0, %s, %s, %s, 1, %s, %s, 1, %s, %s, %s)",
            (
                cardnum,
                password,
                gross_value,
                expiration_date,
                prefix,
                config.get("owner", "admin"),
                online_limit,
                srvid,
                f"xendit_{cardnum}",
                expiretime_sql,
                timebaseexp_sql,
                simultaneous_use,
                associated_service,
                gross_value,
            )
        )

        cursor.execute("SELECT username FROM rm_users WHERE username = %s", (cardnum,))
        if cursor.fetchone() is None:
            cursor.execute(
                "INSERT INTO rm_users (username, password, groupid, enableuser, verified, expiration, createdon, acctype, createdby, owner, srvid) VALUES (%s, %s, %s, 1, 1, %s, CURDATE(), 2, %s, %s, %s)",
                (
                    cardnum,
                    password_md5,
                    groupid,
                    expiration_date,
                    config.get("owner", "admin"),
                    config.get("owner", "admin"),
                    srvid,
                ),
            )

        cursor.execute("SELECT * FROM radcheck WHERE username=%s AND attribute='Cleartext-Password'", (cardnum,))
        if cursor.fetchone() is None:
            cursor.execute("INSERT INTO radcheck (username, attribute, op, value) VALUES (%s, 'Cleartext-Password', ':=', '')", (cardnum,))

        cursor.execute("SELECT * FROM radcheck WHERE username=%s AND attribute='Simultaneous-Use'", (cardnum,))
        if cursor.fetchone() is None:
            cursor.execute("INSERT INTO radcheck (username, attribute, op, value) VALUES (%s, 'Simultaneous-Use', ':=', %s)", (cardnum, str(simultaneous_use)))

        # Patch: Insert Session-Timeout into radreply after radcheck inserts
        cursor.execute("INSERT INTO radreply (username, attribute, op, value) VALUES (%s, 'Session-Timeout', ':=', %s)", (cardnum, str(online_limit * 60)))

        cursor.execute("SELECT groupname FROM rm_usergroups WHERE groupid = %s", (groupid,))
        result = cursor.fetchone()
        groupname_str = result[0] if result else groupid
        cursor.execute("SELECT * FROM radusergroup WHERE username=%s AND groupname=%s", (cardnum, groupname_str))
        if cursor.fetchone() is None:
            cursor.execute("INSERT INTO radusergroup (username, groupname, priority) VALUES (%s, %s, 1)", (cardnum, groupname_str))

        conn.commit()
        cursor.close()
        conn.close()
        return cardnum
    except Exception as e:
        print("❌ DMA Card Generation Error:", e)
        return None

@dmaradius_bp.route("/dmaradius/stats", methods=["GET"])
def voucher_stats():
    try:
        conn = sqlite3.connect(SQLITE_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN used = 0 THEN 1 ELSE 0 END) as active,
                SUM(CASE WHEN used = 1 THEN 1 ELSE 0 END) as used,
                SUM(CASE WHEN revoked = 1 THEN 1 ELSE 0 END) as expired
            FROM rm_cards
        """)
        row = cursor.fetchone()
        conn.close()
        return jsonify({
            "total": row[0] or 0,
            "active": row[1] or 0,
            "used": row[2] or 0,
            "expired": row[3] or 0
        })
    except Exception as e:
        print("❌ Stats Error:", e)
        return jsonify({"error": "Failed to retrieve stats"}), 500




# --- Save voucher portal customization (admin UI) ---
@dmaradius_bp.route("/dmaradius/save-vconfig", methods=["POST"])
def save_voucher_customization():
    try:
        if not request.is_json:
            return jsonify({"error": "Invalid JSON format"}), 400
        data = request.get_json()
        print("📥 Received customization data:", data)

        # Load the existing config
        vconfig_path = "/opt/libreqos/src/jesync_dashboard/modules/dmaradius_config.json"
        try:
            with open(vconfig_path, 'r') as f:
                existing = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            existing = {}

        # Update only branding/success-related keys
        branding_fields = [
            "portal_name", "portal_subtitle",
            "success_title",
            "footer_note", "redirect_url",
            "store_logo_url", "voucher_body_message"
        ]
        for key in branding_fields:
            if key in data:
                existing[key] = data[key].strip()

        # Save back the updated config
        with open(vconfig_path, 'w') as f:
            json.dump(existing, f, indent=2)
        print("✅ Saved merged vconfig:", existing)
        return jsonify({"message": "Customization saved"}), 200
    except Exception as e:
        print("❌ Failed to save vconfig:", e)
        return jsonify({"error": "Failed to save customization"}), 500


# --- Serve vconfig.json statically from static/vendo directory ---
from flask import send_from_directory

@dmaradius_bp.route("/dmaradius/vconfig.json", methods=["GET"])
def serve_vconfig_json():
    return send_from_directory(
        directory="/opt/libreqos/src/jesync_dashboard/static/vendo",
        path="vconfig.json",
        mimetype="application/json"
    )


@dmaradius_bp.route("/dmaradius/admin-users", methods=["GET"])
def get_admin_users():
    try:
        config = load_config()
        conn = mysql.connector.connect(
            host=config["dma_host"],
            user=config["dma_user"],
            password=config["dma_pass"],
            database=config["dma_db"]
        )
        cursor = conn.cursor()
        cursor.execute("SELECT managername FROM rm_managers WHERE enablemanager=1 AND status=1 ORDER BY managername ASC")
        admins = [{"id": row[0], "name": row[0]} for row in cursor.fetchall()]
        cursor.close()
        conn.close()
        return jsonify(admins)
    except Exception as e:
        print("❌ Failed to fetch admin users:", e)
        return jsonify([])


# --- Auto-generate voucher from paid POST endpoint ---
@dmaradius_bp.route("/dmaradius/auto-generate-from-paid", methods=["POST"])
def auto_generate_from_paid():
    try:
        data = request.get_json() or {}
        external_id = str(data.get("external_id") or "").strip()
        invoice_id = str(data.get("invoice_id") or data.get("id") or external_id or "").strip()
        email = str(data.get("email", "")).strip()
        if not invoice_id:
            log_voucher_attempt(
                invoice_id=None,
                external_id=external_id,
                amount=None,
                email=email,
                status="MISSING",
                reason="missing_invoice_id"
            )
            return jsonify({"status": "error", "message": "Missing invoice_id"}), 400

        mapped_invoice_id = lookup_invoice_mapping(invoice_id)
        if mapped_invoice_id:
            external_id = external_id or invoice_id
            invoice_id = mapped_invoice_id

        config = load_config()
        xendit_secret = config.get("xendit_secret_key")
        invoice_data, fetch_err = fetch_xendit_invoice(
            xendit_secret,
            invoice_id=invoice_id,
            external_id=external_id or invoice_id
        )
        if not invoice_data:
            log_voucher_attempt(
                invoice_id=invoice_id,
                external_id=external_id,
                amount=None,
                email=email,
                status="UNKNOWN",
                reason=f"xendit_lookup_failed:{fetch_err}"
            )
            return jsonify({"status": "error", "message": "Unable to verify payment"}), 400

        status = invoice_data.get("status")
        canonical_invoice_id = invoice_data.get("id") or invoice_id
        payer_email = invoice_data.get("payer_email", "").strip() or email
        metadata = invoice_data.get("metadata", {}) or {}
        amount_raw = metadata.get("amount", invoice_data.get("amount", ""))
        amount_clean = str(amount_raw).lstrip("₱$").strip()
        try:
            amount_value = int(float(amount_clean))
        except Exception:
            amount_value = None

        if status != "PAID":
            log_voucher_attempt(
                invoice_id=canonical_invoice_id,
                external_id=invoice_data.get("external_id"),
                amount=amount_value,
                email=payer_email,
                status=status,
                reason="invoice_not_paid"
            )
            return jsonify({"status": "cancelled", "message": "Invoice not paid"}), 200

        if amount_value is None:
            log_voucher_attempt(
                invoice_id=canonical_invoice_id,
                external_id=invoice_data.get("external_id"),
                amount=None,
                email=payer_email,
                status=status,
                reason="invalid_amount"
            )
            return jsonify({"status": "error", "message": "Invalid amount"}), 400

        # Prevent duplicate voucher generation for the same invoice
        try:
            conn = sqlite3.connect(SQLITE_DB_PATH)
            cursor = conn.cursor()
            cursor.execute("SELECT cardnum FROM voucher_history WHERE invoice_id = ?", (canonical_invoice_id,))
            row = cursor.fetchone()
            cursor.close()
            conn.close()
            if row:
                existing_card = row[0]
                plan = config.get("plans", {}).get(str(amount_value), {})
                return jsonify({
                    "status": "success",
                    "cardnum": existing_card,
                    "service_name": plan.get("associated_service", "Unknown"),
                    "online_limit": plan.get("online_limit", "N/A")
                })
        except Exception as e:
            print("❌ Failed to check duplicate invoice in auto-generate:", e)

        plan = config.get("plans", {}).get(str(amount_value))
        if not plan:
            log_voucher_attempt(
                invoice_id=canonical_invoice_id,
                external_id=invoice_data.get("external_id"),
                amount=amount_value,
                email=payer_email,
                status=status,
                reason="plan_not_found"
            )
            return jsonify({"status": "error", "message": f"Plan not found for amount ₱{amount_value}"}), 400

        srvid = metadata.get("srvid") or plan.get("srvid")
        if not srvid:
            service_name = plan.get("associated_service")
            if not service_name:
                log_voucher_attempt(
                    invoice_id=canonical_invoice_id,
                    external_id=invoice_data.get("external_id"),
                    amount=amount_value,
                    email=payer_email,
                    status=status,
                    reason="missing_srvid"
                )
                return jsonify({"status": "error", "message": "Missing srvid and associated_service"}), 400
            try:
                conn = mysql.connector.connect(
                    host=config["dma_host"],
                    user=config["dma_user"],
                    password=config["dma_pass"],
                    database=config["dma_db"]
                )
                cursor = conn.cursor()
                cursor.execute("SELECT srvid FROM rm_services WHERE srvname = %s", (service_name,))
                result = cursor.fetchone()
                if result:
                    srvid = result[0]
                    plan["srvid"] = srvid
                else:
                    log_voucher_attempt(
                        invoice_id=canonical_invoice_id,
                        external_id=invoice_data.get("external_id"),
                        amount=amount_value,
                        email=payer_email,
                        status=status,
                        reason="service_not_found"
                    )
                    return jsonify({"status": "error", "message": f"Service '{service_name}' not found"}), 400
                cursor.close()
                conn.close()
            except Exception as e:
                return jsonify({"status": "error", "message": f"DB error: {str(e)}"}), 500

        prefix = plan.get("prefix", config.get("prefix", "GCASH"))
        cardnum = generate_dma_card(config, plan, srvid, prefix)
        if not cardnum:
            return jsonify({"status": "error", "message": "Voucher creation failed"}), 500

        log_to_sqlite(canonical_invoice_id, cardnum, int(amount_value), srvid)

        # Send voucher receipt email if email is valid and present
        if payer_email and "@" in payer_email:
            try:
                import smtplib
                from email.mime.text import MIMEText
                smtp_host = config.get("smtp_host")
                smtp_port = int(config.get("smtp_port", 587))
                smtp_user = config.get("smtp_user")
                smtp_pass = config.get("smtp_pass")
                email_template = config.get("email_template", "").strip()
                if not email_template:
                    email_template = (
                        "Thank you for your payment.\n\n"
                        "Your voucher is ready:\n\n"
                        "Code: {cardnum}\n"
                        "Service: {associated_service}\n"
                        "Time Limit: {online_limit} mins\n\n"
                        "Jesync Voucher System"
                    )
                body = email_template.format(
                    cardnum=cardnum,
                    associated_service=plan.get("associated_service", ""),
                    online_limit=plan.get("online_limit", "N/A")
                )
                print("📧 Preparing to send email:")
                print("SMTP Host:", smtp_host)
                print("SMTP Port:", smtp_port)
                print("SMTP User:", smtp_user)
                print("To Email:", payer_email)
                print("Email body:\n", body)
                msg = MIMEText(body)
                msg['Subject'] = 'Your Jesync Voucher'
                msg['From'] = smtp_user
                msg['To'] = payer_email
                with smtplib.SMTP(smtp_host, smtp_port) as server:
                    server.starttls()
                    server.login(smtp_user, smtp_pass)
                    server.send_message(msg)
                print(f"📧 Email sent to {payer_email}")
            except Exception as e:
                import traceback
                traceback.print_exc()
                print("❌ Email send failed with traceback above.")

        return jsonify({
            "status": "success",
            "cardnum": cardnum,
            "service_name": plan.get("associated_service", "Unknown"),
            "online_limit": plan.get("online_limit", "N/A")
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({
            "status": "error",
            "message": f"Unexpected error: {str(e)}"
        }), 500

# Remove any references to uptime_unit or expiretime_unit if present (none found in this function)
