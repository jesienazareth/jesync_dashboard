(function(){
  // Local DOM helper (shadows any global $ like jQuery)
  const $ = (sel) => document.querySelector(sel);
  // ==== Local client config (no token in browser) ====
  function apiBase(){ return '/tunnel'; }

  async function postJSON(url, body){
    const r = await fetch(url, {
      method: 'POST',
      headers: {'Content-Type':'application/json','Accept':'application/json'},
      credentials: 'same-origin',
      body: JSON.stringify(body||{})
    });
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  }

  async function getJSON(url){
    const r = await fetch(url, {headers:{'Accept':'application/json'}, credentials:'same-origin'});
    if(!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  }

  function setText(id, v){ const el = $(id); if(el) el.textContent = v; }
  function nowStr(){ return new Date().toLocaleString(); }

  function saveClientId(id){
    try { localStorage.setItem('jt_client_id', id || ''); } catch(_) {}
  }
  function loadClientId(){
    try { return localStorage.getItem('jt_client_id') || ''; } catch(_) { return ''; }
  }
  function makeClientId(company){
    const base = (company || location.hostname || 'CLIENT').toUpperCase().replace(/[^A-Z0-9]+/g,'-');
    return base.replace(/^-+|-+$/g,'') || 'CLIENT';
  }
  function getOrMakeClientId(company){
    const saved = loadClientId();
    if (saved) return saved;
    return makeClientId(company);
  }

  async function handleRegister(){
    const btn = $('#jt-register-btn');
    const input = $('#jt-company');
    const error = $('#jt-error');
    if(!btn || !input) return;
    error && (error.style.display='none', error.textContent='');

    const company = (input.value || '').trim();
    if(!company){
      error && (error.style.display='block', error.textContent='Please enter your company name.');
      return;
    }

    btn.disabled = true;
    const orig = btn.textContent;
    btn.textContent = 'Registering…';

    try{
      const cid = getOrMakeClientId(company);
      const payload = {
        client_id: cid,
        company_name: company,
        hostname: location.hostname || '',
        os_info: navigator.userAgent || '',
        jesync_version: (window.JESYNC_APP_VERSION || '')
      };
      const resp = await postJSON(`${apiBase()}/register`, payload);
      // Expect { status:'ok', client_id:'...', ... }
      saveClientId(cid);
      setText('#jt-client-id', cid);
      setText('#jt-status', 'Registered');
      setText('#jt-last', nowStr());
      try {
        await postJSON(`${apiBase()}/heartbeat`, {
          client_id: cid,
          reverse_ssh_port: (window.JESYNC_TUNNEL_PORT || 0),
          public_ip: '',
          local_ip: ''
        });
      } catch (_) { /* optional */ }
    }catch(err){
      if(error){
        error.style.display = 'block';
        error.textContent = `Failed to register: ${err.message}`;
      }
    }finally{
      btn.disabled = false;
      btn.textContent = orig;
    }
  }

  async function pollStatus(){
    const cid = loadClientId();
    if(!cid){ return; }
    setText('#jt-client-id', cid);
    try{
      // Query server for single-client status
      const s = await getJSON(`${apiBase()}/status/${encodeURIComponent(cid)}`);
      const item = (s && s.item) || {};
      const ok = !!item.online && !item.blocked;
      setText('#jt-status', ok ? 'Connected' : (item.blocked ? 'Blocked' : 'Not connected'));
    }catch(_){
      setText('#jt-status', 'Unknown');
    }finally{
      setText('#jt-last', nowStr());
    }
  }

  document.addEventListener('DOMContentLoaded', function(){
    const btn = $('#jt-register-btn');
    if(btn) btn.addEventListener('click', handleRegister);

    // If we previously registered, show saved ID and begin polling
    const cid = loadClientId();
    if(cid){
      setText('#jt-client-id', cid);
      setText('#jt-status', 'Checking…');
      pollStatus();
    }
    // Poll every 10s
    setInterval(pollStatus, 10000);
  });
})();
