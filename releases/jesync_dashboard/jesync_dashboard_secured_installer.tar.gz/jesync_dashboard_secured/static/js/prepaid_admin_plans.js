// Jesync Prepaid Admin Plans (v10, Global) — full CRUD with price/description/burst (no router_index)
const API_BASE = '/prepaid/api/plans';
const CREDIT_PACKAGES_API = '/prepaid/api/credit-packages';

function escapeHtml(s){ return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

function jp_toast(msg, isError=false){
  try{
    const el = document.getElementById('liveToast');
    const body = document.getElementById('toastBody');
    if(!el || !body){ alert(msg); return; }
    el.classList.remove('text-bg-success','text-bg-danger');
    el.classList.add(isError ? 'text-bg-danger' : 'text-bg-success');
    body.textContent = msg;
    bootstrap.Toast.getOrCreateInstance(el, { delay: 2500 }).show();
  }catch{ alert(msg); }
}

async function fetchJSON(url, opts){
  const res = await fetch(url, opts);
  const txt = await res.text();
  let data = null;
  try{ data = JSON.parse(txt); }catch{}
  return { res, data, txt };
}

function normalizePlan(p){
  return {
    id: p.id,
    name: p.name || '',
    router_name: 'All Routers',
    price: Number(p.price || 0),
    days: (p.days ?? p.duration_days ?? 0),
    hours: (p.hours ?? p.duration_hours ?? 0),
    rate_down: (p.rate_down ?? p.down ?? ''),
    rate_up: (p.rate_up ?? p.up ?? ''),
    queue_download: p.queue_download ?? '',
    queue_upload: p.queue_upload ?? '',
    description: p.description ?? '',
    burst: p.burst || {},
    portal_hidden: !!p.portal_hidden,
    billing_mode: p.billing_mode || 'prepaid',
    redeem_enabled: !!p.redeem_enabled,
    redeem_points_cost: Number(p.redeem_points_cost || 0)
  };
}

function fmtValidity(p){
  const d = parseInt((p.days ?? p.duration_days ?? 0),10) || 0;
  const h = parseInt((p.hours ?? p.duration_hours ?? 0),10) || 0;
  if(!d && !h) return '—';
  const parts=[];
  if(d){ parts.push(`${d}d`); }
  if(h){ parts.push(`${h}h`); }
  return parts.join(' ');
}
function fmtRate(v){ return (v && String(v).trim()) ? String(v).trim() : '—'; }
function fmtPrice(v){
  const n = Number(v);
  if (Number.isFinite(n)) return `₱${n.toFixed(2)}`;
  return v ? String(v) : '—';
}

const PLAN_PAGE_SIZE = 25;
let plansPage = 1;

let routers = [];
let rewardSettings = { allow_negative: false, allow_set: false };
let creditSettings = { bonus_type: 'fixed', bonus_enabled: false, points_per_credit: 0, package_rate_per_php: 0, package_bonus_points: 0 };
let creditPackages = [];
let rewardMatches = [];
let selectedRewardAccount = null;
let redeemCalc = {};
let creditCalc = {};

async function fetchRouters(){
  // Global plan mode: no router selection required.
  const warn = document.getElementById('routerWarn') || document.getElementById('router_warn');
  const saveBtn = document.getElementById('btnSavePlan');
  if (warn) warn.classList.add('d-none');
  if (saveBtn) saveBtn.disabled = false;
  routers = [];
  return;
}

function routerNameFromPlan(p){
  return 'All Routers';
}

async function loadRegularFeeSettings(){
  const graceAdvanceEnabled = document.getElementById('regGraceAdvanceEnabled');
  const gracePostpaidEnabled = document.getElementById('regGracePostpaidEnabled');
  const graceDefaultDays = document.getElementById('regGraceDefaultDays');
  const reconnectEnabled = document.getElementById('regReconnectEnabled');
  const reconnectAmount = document.getElementById('regReconnectAmount');
  if (!graceAdvanceEnabled || !gracePostpaidEnabled || !graceDefaultDays || !reconnectEnabled || !reconnectAmount) return;
  try{
    const {data} = await fetchJSON('/prepaid/api/regular-fees', { headers: { 'Accept':'application/json','X-Requested-With':'XMLHttpRequest' }});
    const s = data?.settings || {};
    const graceFallback = (s.grace_fee_enabled ?? true);
    graceAdvanceEnabled.checked = !!(s.grace_fee_enabled_advance ?? graceFallback);
    gracePostpaidEnabled.checked = !!(s.grace_fee_enabled_postpaid ?? graceFallback);
    graceDefaultDays.value = String(s.default_grace_period_days ?? 6);
    reconnectEnabled.checked = !!s.reconnect_fee_enabled;
    reconnectAmount.value = String(s.reconnect_fee_amount ?? 500);
  }catch(e){
    console.warn('Failed to load regular fee settings', e);
  }
}

async function saveRegularFeeSettings(){
  const graceAdvanceEnabled = document.getElementById('regGraceAdvanceEnabled');
  const gracePostpaidEnabled = document.getElementById('regGracePostpaidEnabled');
  const graceDefaultDays = document.getElementById('regGraceDefaultDays');
  const reconnectEnabled = document.getElementById('regReconnectEnabled');
  const reconnectAmount = document.getElementById('regReconnectAmount');
  if (!graceAdvanceEnabled || !gracePostpaidEnabled || !graceDefaultDays || !reconnectEnabled || !reconnectAmount) return;
  const payload = {
    grace_fee_enabled: !!graceAdvanceEnabled.checked,
    grace_fee_enabled_advance: !!graceAdvanceEnabled.checked,
    grace_fee_enabled_postpaid: !!gracePostpaidEnabled.checked,
    default_grace_period_days: parseInt(graceDefaultDays.value || '6', 10) || 0,
    reconnect_fee_enabled: !!reconnectEnabled.checked,
    reconnect_fee_amount: parseFloat(reconnectAmount.value || '0') || 0
  };
  try{
    const {res, data, txt} = await fetchJSON('/prepaid/api/regular-fees', {
      method: 'POST',
      headers:{
        'Accept':'application/json',
        'Content-Type':'application/json',
        'X-Requested-With':'XMLHttpRequest'
      },
      body: JSON.stringify(payload)
    });
    if(!res.ok || !data || data.ok !== true){
      const msg = (data && (data.error || data.message)) || (txt || `HTTP ${res.status}`);
      throw new Error(msg);
    }
    jp_toast('Regular plan fees saved');
    // Refresh defaults from server (sanity)
    loadRegularFeeSettings();
  }catch(e){
    console.error('saveRegularFeeSettings failed', e);
    jp_toast(`Save failed: ${e?.message || e}`, true);
  }
}

function serializePlanFromModal(){
  const id = document.getElementById('plan_id')?.value?.trim();
  const name = document.getElementById('name')?.value?.trim() || '';
  // router_index removed in global mode
  const days = parseInt(document.getElementById('days')?.value || '0', 10) || 0;
  const hours = parseInt(document.getElementById('hours')?.value || '0', 10) || 0;
  const rate_down = document.getElementById('rate_down')?.value?.trim() || '';
  const rate_up = document.getElementById('rate_up')?.value?.trim() || '';
  const queue_download = document.getElementById('queue_download')?.value?.trim() || '';
  const queue_upload = document.getElementById('queue_upload')?.value?.trim() || '';
  const price = parseFloat(document.getElementById('price')?.value || '0') || 0;
  const grace_fee_per_day = parseFloat(document.getElementById('grace_fee_per_day')?.value || '0') || 0;
  const description = document.getElementById('description')?.value?.trim() || '';
  const portal_hidden = !!document.getElementById('portal_hidden')?.checked;
  const redeem_enabled = !!document.getElementById('redeem_enabled')?.checked;
  const redeem_points_cost = parseInt(document.getElementById('redeem_points_cost')?.value || '0', 10) || 0;

  // Get billing mode from radio buttons
  const billingModeEl = document.querySelector('input[name="billing_mode"]:checked');
  const billing_mode = billingModeEl ? billingModeEl.value : 'prepaid';

  const burst_enabled = !!document.getElementById('burst_enabled')?.checked;
  const burst_up_limit = document.getElementById('burst_up_limit')?.value?.trim() || '';
  const burst_down_limit = document.getElementById('burst_down_limit')?.value?.trim() || '';
  const burst_up_threshold = document.getElementById('burst_up_threshold')?.value?.trim() || '';
  const burst_down_threshold = document.getElementById('burst_down_threshold')?.value?.trim() || '';
  const burst_time = document.getElementById('burst_time')?.value?.trim() || '10s';

  return {
    ...(id ? { id: Number(id) } : {}),
    name, days, hours,
    rate_down, rate_up,
    queue_download, queue_upload,
    price, description,
    grace_fee_per_day,
    billing_mode,
    limit_at_down: document.getElementById('limit_at_down')?.value?.trim() || '',
    limit_at_up: document.getElementById('limit_at_up')?.value?.trim() || '',
    portal_hidden,
    redeem_enabled,
    redeem_points_cost: redeem_enabled ? redeem_points_cost : 0,
    burst: {
      enabled: burst_enabled,
      up_limit: burst_up_limit,
      down_limit: burst_down_limit,
      up_threshold: burst_up_threshold,
      down_threshold: burst_down_threshold,
      time: burst_time || '10s'
    }
  };
}

function fillForm(p){
  var el;
  el = document.getElementById('plan_id'); if (el) el.value = (p.id ?? '');
  el = document.getElementById('name'); if (el) el.value = (p.name ?? '');
  // router_index removed in global mode
  el = document.getElementById('days'); if (el) el.value = (p.days ?? 0);
  el = document.getElementById('hours'); if (el) el.value = (p.hours ?? 0);
  el = document.getElementById('rate_down'); if (el) el.value = (p.rate_down ?? '');
  el = document.getElementById('rate_up'); if (el) el.value = (p.rate_up ?? '');
  el = document.getElementById('queue_download'); if (el) el.value = (p.queue_download ?? '');
  el = document.getElementById('queue_upload'); if (el) el.value = (p.queue_upload ?? '');
  el = document.getElementById('price'); if (el) el.value = (p.price ?? 0);
  el = document.getElementById('grace_fee_per_day'); if (el) el.value = (p.grace_fee_per_day ?? 0);
  el = document.getElementById('description'); if (el) el.value = (p.description ?? '');
  el = document.getElementById('limit_at_down'); if (el) el.value = (p.limit_at_down ?? '');
  el = document.getElementById('limit_at_up'); if (el) el.value = (p.limit_at_up ?? '');
  el = document.getElementById('portal_hidden'); if (el) el.checked = !!p.portal_hidden;
  el = document.getElementById('redeem_enabled'); if (el) el.checked = !!p.redeem_enabled;
  el = document.getElementById('redeem_points_cost'); if (el) el.value = (p.redeem_points_cost ?? 0);

  // Set billing mode radio buttons
  const billingMode = p.billing_mode || 'prepaid';
  el = document.getElementById('billing_mode_prepaid');
  if (el) el.checked = (billingMode === 'prepaid');
  el = document.getElementById('billing_mode_regular');
  if (el) el.checked = (billingMode === 'regular');

  var b = p.burst || {};
  // setAttribute checked for compatibility then set .checked if element exists
  el = document.getElementById('burst_enabled');
  if (el) {
    if (b.enabled) { try{ el.setAttribute('checked','checked'); }catch(_){} }
    else { try{ el.removeAttribute('checked'); }catch(_){} }
    el.checked = !!b.enabled;
  }
  el = document.getElementById('burst_up_limit'); if (el) el.value = (b.up_limit ?? '');
  el = document.getElementById('burst_down_limit'); if (el) el.value = (b.down_limit ?? '');
  el = document.getElementById('burst_up_threshold'); if (el) el.value = (b.up_threshold ?? '');
  el = document.getElementById('burst_down_threshold'); if (el) el.value = (b.down_threshold ?? '');
  el = document.getElementById('burst_time'); if (el) el.value = (b.time ?? '10s');
  // Control burst fields visibility based on burst enabled
  const bf = document.getElementById('burst_fields');
  const be2 = document.getElementById('burst_enabled');
  if (bf && be2) {
    if (be2.checked) {
      bf.classList.remove('d-none');
    } else {
      bf.classList.add('d-none');
    }
  }
  applyRedeemToggle();
  syncRedeemCalcPrice();
}

function applyRedeemToggle(){
  const redeemToggle = document.getElementById('redeem_enabled');
  const redeemCost = document.getElementById('redeem_points_cost');
  if (!redeemToggle || !redeemCost) return;
  redeemCost.disabled = !redeemToggle.checked;
}

function initRedeemCalculator(){
  redeemCalc = {
    priceEl: document.getElementById('redeemCalcPrice'),
    percentEl: document.getElementById('redeemCalcPercent'),
    pointsPerCreditEl: document.getElementById('redeemCalcPointsPerCredit'),
    creditsPerPhpEl: document.getElementById('redeemCalcCreditsPerPhp'),
    packageEl: document.getElementById('redeemCalcPackage'),
    resultEl: document.getElementById('redeemCalcResult'),
    formulaEl: document.getElementById('redeemCalcFormula'),
    applyBtn: document.getElementById('redeemCalcApply')
  };
  if (!redeemCalc.priceEl || !redeemCalc.percentEl || !redeemCalc.pointsPerCreditEl || !redeemCalc.creditsPerPhpEl) return;

  const priceInput = document.getElementById('price');
  if (priceInput) {
    redeemCalc.priceEl.value = priceInput.value || '0';
    priceInput.addEventListener('input', syncRedeemCalcPrice);
  }

  redeemCalc.percentEl.addEventListener('input', computeRedeemCalc);
  redeemCalc.pointsPerCreditEl.addEventListener('input', computeRedeemCalc);
  redeemCalc.creditsPerPhpEl.addEventListener('input', () => {
    if (redeemCalc.packageEl) redeemCalc.packageEl.value = 'custom';
    redeemCalc.creditsPerPhpEl.readOnly = false;
    computeRedeemCalc();
  });
  redeemCalc.packageEl?.addEventListener('change', handleRedeemCalcPackageChange);
  redeemCalc.applyBtn?.addEventListener('click', applyRedeemCalcToField);

  syncRedeemCalcDefaults();
  updateRedeemCalcPackages();
  computeRedeemCalc();
}

function syncRedeemCalcDefaults(){
  if (!redeemCalc.pointsPerCreditEl) return;
  if (!Number(redeemCalc.pointsPerCreditEl.value || 0) && creditSettings.points_per_credit > 0) {
    redeemCalc.pointsPerCreditEl.value = String(creditSettings.points_per_credit);
  }
}

function syncRedeemCalcPrice(){
  const priceInput = document.getElementById('price');
  if (!priceInput || !redeemCalc.priceEl) return;
  redeemCalc.priceEl.value = priceInput.value || '0';
  computeRedeemCalc();
}

function updateRedeemCalcPackages(){
  if (!redeemCalc.packageEl) return;
  const options = ['<option value="custom">Custom ratio</option>'];
  const activePackages = (creditPackages || []).filter(pkg => pkg.active && pkg.price > 0 && pkg.credit > 0);
  activePackages.forEach(pkg => {
    const ratio = pkg.price > 0 ? (pkg.credit / pkg.price) : 0;
    const label = `${pkg.name || 'Package'} (₱${pkg.price.toFixed(2)} → ${formatNumber(pkg.credit)} pts)`;
    options.push(`<option value="${escapeHtml(pkg.id)}" data-ratio="${ratio}">${escapeHtml(label)}</option>`);
  });
  const current = redeemCalc.packageEl.value;
  redeemCalc.packageEl.innerHTML = options.join('');
  if (activePackages.length) {
    const validIds = new Set(activePackages.map(pkg => String(pkg.id)));
    const target = validIds.has(String(current)) ? current : String(activePackages[0].id);
    redeemCalc.packageEl.value = target;
    handleRedeemCalcPackageChange();
  } else {
    redeemCalc.packageEl.value = 'custom';
    redeemCalc.creditsPerPhpEl.readOnly = false;
  }
}

function handleRedeemCalcPackageChange(){
  if (!redeemCalc.packageEl || !redeemCalc.creditsPerPhpEl) return;
  const selected = redeemCalc.packageEl.value || 'custom';
  if (selected === 'custom') {
    redeemCalc.creditsPerPhpEl.readOnly = false;
  } else {
    const opt = Array.from(redeemCalc.packageEl.options).find(option => option.value === selected);
    const ratio = opt ? Number(opt.getAttribute('data-ratio') || '0') : 0;
    redeemCalc.creditsPerPhpEl.value = ratio > 0 ? ratio.toFixed(4) : '';
    redeemCalc.creditsPerPhpEl.readOnly = true;
  }
  computeRedeemCalc();
}

function computeRedeemCalc(){
  if (!redeemCalc.resultEl || !redeemCalc.formulaEl) return;
  const price = parseFloat(redeemCalc.priceEl?.value || '0') || 0;
  const percent = parseFloat(redeemCalc.percentEl?.value || '0') || 0;
  const pointsPerCredit = parseFloat(redeemCalc.pointsPerCreditEl?.value || '0') || 0;
  const creditsPerPhp = parseFloat(redeemCalc.creditsPerPhpEl?.value || '0') || 0;
  if (!price || !percent || !pointsPerCredit || !creditsPerPhp) {
    redeemCalc.resultEl.value = '';
    redeemCalc.resultEl.dataset.value = '';
    redeemCalc.formulaEl.textContent = 'Redeem Points = Plan Price x Credit % x Credits/PHP x Points/Credit.';
    return;
  }
  const creditPhp = price * (percent / 100);
  const creditsNeeded = creditPhp * creditsPerPhp;
  const pointsNeeded = creditsNeeded * pointsPerCredit;
  const rounded = Math.ceil(pointsNeeded);
  redeemCalc.resultEl.value = `${formatNumber(rounded)} pts`;
  redeemCalc.resultEl.dataset.value = String(rounded);
  redeemCalc.formulaEl.textContent = `₱${price.toFixed(2)} x ${percent}% x ${creditsPerPhp.toFixed(4)} x ${formatNumber(pointsPerCredit)} = ${formatNumber(rounded)} pts`;
}

function applyRedeemCalcToField(){
  const redeemCost = document.getElementById('redeem_points_cost');
  const redeemToggle = document.getElementById('redeem_enabled');
  if (!redeemCost || !redeemCalc.resultEl) return;
  const value = parseInt(redeemCalc.resultEl.dataset.value || '0', 10) || 0;
  if (value <= 0) {
    jp_toast('Set calculator values first', true);
    return;
  }
  redeemCost.value = String(value);
  if (redeemToggle) redeemToggle.checked = true;
  applyRedeemToggle();
}

function initCreditCalculator(){
  creditCalc = {
    rateEl: document.getElementById('creditCalcRate'),
    amountEl: document.getElementById('creditCalcAmount'),
    resultEl: document.getElementById('creditCalcResult'),
    formulaEl: document.getElementById('creditCalcFormula'),
    creditInputEl: document.getElementById('creditCalcCreditInput'),
    phpResultEl: document.getElementById('creditCalcPhpResult'),
    phpFormulaEl: document.getElementById('creditCalcPhpFormula'),
    bonusEl: document.getElementById('creditCalcBonus'),
    applyBtn: document.getElementById('creditCalcApplyRate'),
    lastBottomInput: 'credit',
    isSyncing: false
  };
  if (!creditCalc.rateEl || !creditCalc.amountEl || !creditCalc.resultEl) return;
  creditCalc.rateEl.addEventListener('input', () => {
    if (creditCalc.isSyncing) return;
    updateTopCreditCalc();
    updateBottomCreditCalc(creditCalc.lastBottomInput || 'credit');
  });
  creditCalc.amountEl.addEventListener('input', () => {
    if (creditCalc.isSyncing) return;
    updateTopCreditCalc();
  });
  creditCalc.creditInputEl?.addEventListener('input', () => {
    if (creditCalc.isSyncing) return;
    creditCalc.lastBottomInput = 'credit';
    updateBottomCreditCalc('credit');
  });
  creditCalc.phpResultEl?.addEventListener('input', () => {
    if (creditCalc.isSyncing) return;
    creditCalc.lastBottomInput = 'php';
    updateBottomCreditCalc('php');
  });
  creditCalc.bonusEl?.addEventListener('input', () => {
    if (creditCalc.isSyncing) return;
  });
  creditCalc.applyBtn?.addEventListener('click', applyCreditRateToSettings);
  updateTopCreditCalc();
  updateBottomCreditCalc(creditCalc.lastBottomInput || 'credit');
}

function parseCalcNumber(val){
  const cleaned = String(val ?? '').replace(/[^0-9.\-]/g, '');
  const num = parseFloat(cleaned);
  return Number.isFinite(num) ? num : 0;
}

function updateTopCreditCalc(){
  if (!creditCalc.resultEl) return;
  const rate = parseCalcNumber(creditCalc.rateEl?.value);
  let amount = parseCalcNumber(creditCalc.amountEl?.value);
  if (creditCalc.amountEl && amount === 0) {
    amount = 1;
    creditCalc.amountEl.value = '1';
  }
  if (!rate || !amount) {
    creditCalc.resultEl.value = '';
    if (creditCalc.formulaEl) creditCalc.formulaEl.textContent = 'Credit Points = PHP x Rate.';
    return;
  }
  const points = amount * rate;
  creditCalc.resultEl.value = `${formatNumber(points)} pts`;
  if (creditCalc.formulaEl) {
    creditCalc.formulaEl.textContent = `₱${amount.toFixed(2)} x ${formatNumber(rate)} = ${formatNumber(points)} pts`;
  }
}

function updateBottomCreditCalc(source){
  if (!creditCalc.creditInputEl || !creditCalc.phpResultEl) return;
  const rate = parseCalcNumber(creditCalc.rateEl?.value);
  creditCalc.isSyncing = true;

  if (!rate) {
    creditCalc.creditInputEl.value = '';
    creditCalc.phpResultEl.value = '';
    if (creditCalc.phpFormulaEl) creditCalc.phpFormulaEl.textContent = 'PHP = Credit Points ÷ Rate.';
    creditCalc.isSyncing = false;
    return;
  }

  if (source === 'php') {
    const php = parseCalcNumber(creditCalc.phpResultEl.value);
    if (!php) {
      creditCalc.creditInputEl.value = '';
      if (creditCalc.phpFormulaEl) creditCalc.phpFormulaEl.textContent = 'PHP = Credit Points ÷ Rate.';
      creditCalc.isSyncing = false;
      return;
    }
    const points = php * rate;
    creditCalc.creditInputEl.value = formatNumber(points);
    if (creditCalc.phpFormulaEl) {
      creditCalc.phpFormulaEl.textContent = `₱${php.toFixed(2)} x ${formatNumber(rate)} = ${formatNumber(points)} pts`;
    }
    creditCalc.isSyncing = false;
    return;
  }

  const credit = parseCalcNumber(creditCalc.creditInputEl.value);
  if (!credit) {
    creditCalc.phpResultEl.value = '';
    if (creditCalc.phpFormulaEl) creditCalc.phpFormulaEl.textContent = 'PHP = Credit Points ÷ Rate.';
    creditCalc.isSyncing = false;
    return;
  }
  const php = credit / rate;
  creditCalc.phpResultEl.value = php.toFixed(2);
  if (creditCalc.phpFormulaEl) {
    creditCalc.phpFormulaEl.textContent = `${formatNumber(credit)} ÷ ${formatNumber(rate)} = ₱${php.toFixed(2)}`;
  }
  creditCalc.isSyncing = false;
}

async function applyCreditRateToSettings(){
  const rate = parseCalcNumber(creditCalc.rateEl?.value);
  const bonus = parseCalcNumber(creditCalc.bonusEl?.value);
  if (!rate || rate <= 0) {
    jp_toast('Set a valid rate first', true);
    return;
  }
  try{
    const {res, data, txt} = await fetchJSON('/prepaid/api/credit-packages/apply-rate', {
      method:'POST',
      headers:{
        'Accept':'application/json',
        'Content-Type':'application/json',
        'X-Requested-With':'XMLHttpRequest'
      },
      body: JSON.stringify({ rate_per_php: rate, bonus_points: bonus })
    });
    if (!res.ok || !data || data.ok !== true) {
      const msg = (data && (data.error || data.message)) || (txt || `HTTP ${res.status}`);
      throw new Error(msg);
    }
    jp_toast('Credit rate applied to settings and packages');
    await loadCreditPackages();
  }catch(e){
    console.error('applyCreditRateToSettings failed', e);
    jp_toast(e?.message || 'Failed to apply credit rate', true);
  }
}

function buildPager(el, current, total){
  if(!el) return;
  if(total <= 1){
    el.innerHTML = '';
    return;
  }
  const windowSize = 5;
  const startPage = Math.max(1, current - Math.floor(windowSize / 2));
  const endPage = Math.min(total, startPage + windowSize - 1);
  const realStart = Math.max(1, endPage - windowSize + 1);
  const items = [];
  items.push(`
    <li class="page-item ${current<=1?'disabled':''}">
      <a class="page-link" href="#" aria-label="Previous" data-page="${Math.max(1, current-1)}">&laquo;</a>
    </li>`);
  if(realStart > 1){
    items.push(`<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>`);
    if(realStart > 2){
      items.push(`<li class="page-item disabled"><span class="page-link">...</span></li>`);
    }
  }
  for(let p=realStart; p<=endPage; p++){
    items.push(`
      <li class="page-item ${p===current?'active':''}">
        <a class="page-link" href="#" data-page="${p}">${p}</a>
      </li>`);
  }
  if(endPage < total){
    if(endPage < total - 1){
      items.push(`<li class="page-item disabled"><span class="page-link">...</span></li>`);
    }
    items.push(`<li class="page-item"><a class="page-link" href="#" data-page="${total}">${total}</a></li>`);
  }
  items.push(`
    <li class="page-item ${current>=total?'disabled':''}">
      <a class="page-link" href="#" aria-label="Next" data-page="${Math.min(total, current+1)}">&raquo;</a>
    </li>`);
  el.innerHTML = items.join('');
}

function applyPlanPagination(){
  const tbody = document.querySelector('#tbl_plans tbody');
  if(!tbody) return;
  const rows = Array.from(tbody.querySelectorAll('tr.plan-row'));
  const totalPages = Math.max(1, Math.ceil(rows.length / PLAN_PAGE_SIZE));
  if(plansPage > totalPages) plansPage = totalPages;
  if(plansPage < 1) plansPage = 1;

  rows.forEach((row, idx) => {
    const page = Math.floor(idx / PLAN_PAGE_SIZE) + 1;
    row.style.display = (page === plansPage) ? '' : 'none';
  });

  const info = document.getElementById('plansPageInfo');
  if(info) info.textContent = `Page ${plansPage} of ${totalPages}`;
  buildPager(document.getElementById('plansPager'), plansPage, totalPages);
}

// Store Sortable instance globally
let sortableInstance = null;

function initializeSortable() {
  const plansTbody = document.querySelector('#tbl_plans tbody');
  if (!plansTbody) return;

  // Destroy existing instance if it exists
  if (sortableInstance) {
    sortableInstance.destroy();
  }

  // Create new Sortable instance
  sortableInstance = new Sortable(plansTbody, {
    handle: '.drag-handle',
    animation: 150,
    ghostClass: 'sortable-ghost',
    dragClass: 'sortable-drag',
    onEnd: function (evt) {
      // Get the new order of plan IDs
      const rows = plansTbody.querySelectorAll('tr.plan-row');
      const planOrder = Array.from(rows).map(row => row.getAttribute('data-plan-id'));

      // Save the new order
      savePlanOrder(planOrder);
      applyPlanPagination();
    }
  });
}

async function savePlanOrder(planOrder) {
  try {
    const res = await fetch('/prepaid/api/admin/plans/reorder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ plan_order: planOrder })
    });

    const j = await res.json();
    if (res.ok && j && j.ok) {
      console.log('Plan order saved successfully');
    } else {
      console.error('Failed to save plan order:', j?.error || 'Unknown error');
      alert('Failed to save plan order. Please refresh the page.');
    }
  } catch (e) {
    console.error('Error saving plan order:', e);
    alert('Error saving plan order. Please refresh the page.');
  }
}

async function togglePortalVisibility(id, shouldHide) {
  try {
    const {res, data, txt} = await fetchJSON(`${API_BASE}/${id}`, {
      method: 'PUT',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: JSON.stringify({ portal_hidden: shouldHide })
    });
    if (!res.ok || !data || data.ok !== true) {
      const msg = (data && (data.error || data.message)) || (txt || `HTTP ${res.status}`);
      throw new Error(msg);
    }
    jp_toast(shouldHide ? 'Plan hidden from portal' : 'Plan is now visible on portal');
    await loadPlans();
  } catch (e) {
    console.error('togglePortalVisibility failed', e);
    jp_toast(`Failed to update portal visibility: ${e?.message || e}`, true);
  }
}

async function loadRewardSettings(){
  try{
    const {data} = await fetchJSON('/prepaid/api/settings', { headers: { 'Accept':'application/json','X-Requested-With':'XMLHttpRequest' }});
    const rewards = data?.settings?.rewards || {};
    rewardSettings = {
      allow_negative: !!rewards.allow_negative,
      allow_set: !!rewards.allow_set
    };
    const credit = data?.settings?.credit || {};
    const bonusType = String(credit.first_time_bonus_type || 'fixed').toLowerCase();
    creditSettings = {
      bonus_type: (bonusType === 'percent') ? 'percent' : 'fixed',
      bonus_enabled: !!credit.first_time_bonus_enabled,
      points_per_credit: Number(credit.points_per_credit ?? credit.credit_points_per_credit ?? 0) || 0,
      package_rate_per_php: Number(credit.package_rate_per_php ?? 0) || 0,
      package_bonus_points: Number(credit.package_bonus_points ?? 0) || 0
    };
    const rateEl = document.getElementById('creditCalcRate');
    if (rateEl && creditSettings.package_rate_per_php > 0) {
      rateEl.value = String(creditSettings.package_rate_per_php);
    }
    const bonusEl = document.getElementById('creditCalcBonus');
    if (bonusEl) {
      bonusEl.value = String(creditSettings.package_bonus_points || 0);
    }
    applyRewardSettingsUI();
    updateCreditBonusLabel();
    syncRedeemCalcDefaults();
  }catch(e){
    console.warn('Failed to load reward settings', e);
  }
}

function applyRewardSettingsUI(){
  const setOpts = [
    document.getElementById('pointsAdjustModeSet'),
    document.getElementById('creditAdjustModeSet')
  ];
  const deductOpts = [
    document.getElementById('pointsAdjustModeDeduct'),
    document.getElementById('creditAdjustModeDeduct')
  ];
  setOpts.forEach(opt => { if (opt) opt.hidden = !rewardSettings.allow_set; });
  deductOpts.forEach(opt => { if (opt) opt.hidden = !rewardSettings.allow_negative; });

  const pointsMode = document.getElementById('pointsAdjustMode');
  const creditMode = document.getElementById('creditAdjustMode');
  if (pointsMode && pointsMode.selectedOptions[0]?.hidden) pointsMode.value = 'add';
  if (creditMode && creditMode.selectedOptions[0]?.hidden) creditMode.value = 'add';
}

function setRewardsAdjustEnabled(enabled){
  const ids = [
    'pointsAdjustMode','pointsAdjustAmount','pointsAdjustReason','pointsAdjustSubmit',
    'creditAdjustMode','creditAdjustAmount','creditAdjustReason','creditAdjustSubmit'
  ];
  ids.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.disabled = !enabled;
  });
}

function formatCredit(amount){
  const n = Number(amount);
  if (!Number.isFinite(n)) return '0.00';
  return n.toFixed(2);
}

function updateRewardsSelectedUI(account){
  const panel = document.getElementById('rewardsSelectedPanel');
  if (!panel || !account) {
    panel?.classList.add('d-none');
    setRewardsAdjustEnabled(false);
    return;
  }
  panel.classList.remove('d-none');
  const acct = account.account_no || '—';
  const name = account.name || '';
  const status = account.status || '—';
  const ref = account.referral_code || '—';
  const billing = account.billing_mode || '—';
  const points = Number(account.points_balance || 0);
  const pending = Number(account.points_pending || 0);
  const credit = formatCredit(account.credit_balance || 0);

  const setText = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
  setText('rewardsSelectedAccount', acct);
  setText('rewardsSelectedName', name || '—');
  setText('rewardsSelectedStatus', status);
  setText('rewardsSelectedReferral', ref);
  setText('rewardsSelectedBilling', billing);
  setText('rewardsSelectedPoints', points);
  setText('rewardsSelectedPending', pending);
  setText('rewardsSelectedCredit', credit);

  const pointsCurrent = document.getElementById('pointsAdjustCurrent');
  if (pointsCurrent) pointsCurrent.textContent = `Balance: ${points} pts`;
  const creditCurrent = document.getElementById('creditAdjustCurrent');
  if (creditCurrent) creditCurrent.textContent = `Balance: ${credit}`;

  setRewardsAdjustEnabled(true);
}

function renderRewardMatches(matches){
  const list = document.getElementById('rewardsSearchResults');
  const status = document.getElementById('rewardsSearchStatus');
  if (!list) return;
  rewardMatches = Array.isArray(matches) ? matches : [];
  if (!rewardMatches.length) {
    list.innerHTML = '<div class="text-muted">No matches found.</div>';
    if (status) status.textContent = '';
    return;
  }
  if (status) status.textContent = `${rewardMatches.length} match(es)`;
  list.innerHTML = rewardMatches.map((m, i) => {
    const acct = escapeHtml(m.account_no || '');
    const name = escapeHtml(m.name || '');
    const ref = escapeHtml(m.referral_code || '');
    const phone = escapeHtml(m.mobile || m.phone || '');
    const points = Number(m.points_balance || 0);
    const credit = formatCredit(m.credit_balance || 0);
    const subtitle = [name, phone, ref].filter(Boolean).join(' • ');
    return `
      <button type="button" class="list-group-item list-group-item-action d-flex justify-content-between align-items-start" data-index="${i}">
        <div>
          <div class="fw-semibold">${acct}</div>
          <div class="small text-muted">${subtitle || '—'}</div>
        </div>
        <div class="text-end small text-muted">
          <div>${points} pts</div>
          <div>${credit}</div>
        </div>
      </button>
    `;
  }).join('');
}

function selectRewardAccount(index){
  const acct = rewardMatches[index];
  if (!acct) return;
  selectedRewardAccount = acct;
  updateRewardsSelectedUI(selectedRewardAccount);
}

async function searchRewards(){
  const input = document.getElementById('rewardsSearchInput');
  const status = document.getElementById('rewardsSearchStatus');
  if (!input) return;
  const q = input.value.trim();
  if (!q) {
    renderRewardMatches([]);
    if (status) status.textContent = 'Enter a search term.';
    return;
  }
  if (status) status.textContent = 'Searching...';
  try{
    const {res, data} = await fetchJSON(`/prepaid/api/rewards/search?q=${encodeURIComponent(q)}`, {
      headers: { 'Accept':'application/json','X-Requested-With':'XMLHttpRequest' }
    });
    if (!res.ok || !data || data.ok !== true) {
      throw new Error(data?.error || `HTTP ${res.status}`);
    }
    renderRewardMatches(data.matches || []);
  }catch(e){
    console.error('searchRewards failed', e);
    renderRewardMatches([]);
    if (status) status.textContent = 'Search failed.';
  }
}

async function submitRewardAdjustment(kind){
  if (!selectedRewardAccount || !selectedRewardAccount.account_no) {
    jp_toast('Select an account first', true);
    return;
  }
  const isPoints = kind === 'points';
  const modeEl = document.getElementById(isPoints ? 'pointsAdjustMode' : 'creditAdjustMode');
  const amountEl = document.getElementById(isPoints ? 'pointsAdjustAmount' : 'creditAdjustAmount');
  const reasonEl = document.getElementById(isPoints ? 'pointsAdjustReason' : 'creditAdjustReason');
  if (!modeEl || !amountEl) return;
  const mode = modeEl.value || 'add';
  const rawAmount = amountEl.value;
  const amount = isPoints ? parseInt(rawAmount || '0', 10) : parseFloat(rawAmount || '0');
  if (mode !== 'set' && (!amount || amount <= 0)) {
    jp_toast('Amount must be greater than 0', true);
    return;
  }
  const payload = {
    account_no: selectedRewardAccount.account_no,
    kind,
    mode,
    amount: Number.isFinite(amount) ? amount : 0,
    reason: (reasonEl?.value || '').trim() || 'Admin adjustment'
  };
  try{
    const {res, data, txt} = await fetchJSON('/prepaid/api/rewards/adjust', {
      method: 'POST',
      headers: {
        'Accept':'application/json',
        'Content-Type':'application/json',
        'X-Requested-With':'XMLHttpRequest'
      },
      body: JSON.stringify(payload)
    });
    if (!res.ok || !data || data.ok !== true) {
      const msg = (data && (data.error || data.message)) || (txt || `HTTP ${res.status}`);
      throw new Error(msg);
    }
    selectedRewardAccount.points_balance = data.points_balance;
    selectedRewardAccount.points_pending = data.points_pending;
    selectedRewardAccount.credit_balance = data.credit_balance;
    updateRewardsSelectedUI(selectedRewardAccount);
    if (amountEl) amountEl.value = '';
    if (reasonEl) reasonEl.value = '';
    jp_toast(`${kind === 'points' ? 'Points' : 'Credit'} updated`);
  }catch(e){
    console.error('submitRewardAdjustment failed', e);
    jp_toast(e?.message || 'Adjustment failed', true);
  }
}

function updateCreditBonusLabel(){
  const label = document.getElementById('credit_package_bonus_label');
  if (!label) return;
  if (creditSettings.bonus_type === 'percent') {
    label.textContent = 'First-time Bonus (%)';
  } else {
    label.textContent = 'First-time Bonus (points)';
  }
}

function normalizeCreditPackage(p){
  return {
    id: String(p?.id || ''),
    name: String(p?.name || ''),
    price: Number(p?.price || 0),
    credit: Number(p?.credit ?? p?.credit_points ?? 0),
    first_time_bonus: Number(p?.first_time_bonus ?? p?.first_time_bonus_value ?? 0),
    active: !!p?.active,
    start_date: String(p?.start_date || p?.start_at || ''),
    end_date: String(p?.end_date || p?.end_at || '')
  };
}

function formatNumber(val){
  const n = Number(val);
  if (!Number.isFinite(n)) return '0';
  if (Number.isInteger(n)) return String(n);
  return n.toFixed(2);
}

function formatBonus(val){
  const n = Number(val);
  if (!Number.isFinite(n) || n <= 0) return '-';
  if (creditSettings.bonus_type === 'percent') return `${formatNumber(n)}%`;
  return `${formatNumber(n)} pts`;
}

function formatSchedule(pkg){
  const s = (pkg.start_date || '').trim();
  const e = (pkg.end_date || '').trim();
  if (!s && !e) return 'Always';
  if (s && e) return `${s} to ${e}`;
  if (s) return `From ${s}`;
  return `Until ${e}`;
}

function creditPackageStatus(pkg){
  if (!pkg.active) return { text: 'Disabled', cls: 'bg-secondary' };
  const now = new Date();
  let start = null;
  let end = null;
  if (pkg.start_date) {
    const parsed = new Date(`${pkg.start_date}T00:00:00`);
    if (!isNaN(parsed)) start = parsed;
  }
  if (pkg.end_date) {
    const parsed = new Date(`${pkg.end_date}T23:59:59`);
    if (!isNaN(parsed)) end = parsed;
  }
  if (start && now < start) return { text: 'Scheduled', cls: 'bg-warning text-dark' };
  if (end && now > end) return { text: 'Expired', cls: 'bg-secondary' };
  return { text: 'Active', cls: 'bg-success' };
}

function renderCreditPackages(list){
  const tbody = document.querySelector('#tbl_credit_packages tbody');
  if (!tbody) return;
  creditPackages = Array.isArray(list) ? list.map(normalizeCreditPackage) : [];
  if (!creditPackages.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-muted text-center">No packages yet.</td></tr>';
    return;
  }
  tbody.innerHTML = creditPackages.map(pkg => {
    const status = creditPackageStatus(pkg);
    return `
      <tr data-id="${escapeHtml(pkg.id)}">
        <td>${escapeHtml(pkg.name || 'Credit Package')}</td>
        <td class="text-end">${fmtPrice(pkg.price)}</td>
        <td class="text-end">${formatNumber(pkg.credit)} pts</td>
        <td class="text-end">${formatBonus(pkg.first_time_bonus)}</td>
        <td>${escapeHtml(formatSchedule(pkg))}</td>
        <td class="text-center"><span class="badge ${status.cls}">${status.text}</span></td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-primary me-1" data-action="edit-credit" data-id="${escapeHtml(pkg.id)}"><i class="bi bi-pencil"></i></button>
          <button class="btn btn-sm btn-outline-danger" data-action="del-credit" data-id="${escapeHtml(pkg.id)}"><i class="bi bi-trash"></i></button>
        </td>
      </tr>
    `;
  }).join('');
}

async function loadCreditPackages(){
  try{
    const {res, data, txt} = await fetchJSON(CREDIT_PACKAGES_API, { headers: { 'Accept':'application/json','X-Requested-With':'XMLHttpRequest' }});
    if (!res.ok || !data || data.ok !== true) {
      const msg = (data && (data.error || data.message)) || (txt || `HTTP ${res.status}`);
      throw new Error(msg);
    }
    renderCreditPackages(data.packages || []);
    updateRedeemCalcPackages();
  }catch(e){
    console.error('loadCreditPackages failed', e);
    const tbody = document.querySelector('#tbl_credit_packages tbody');
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-danger text-center">Failed to load packages: ${escapeHtml(e?.message || e)}</td></tr>`;
    }
  }
}

function openCreditPackageModal(pkg){
  const isEdit = !!(pkg && pkg.id);
  const modalTitle = document.getElementById('creditPackageModalTitle');
  if (modalTitle) modalTitle.textContent = isEdit ? 'Edit Credit Package' : 'Add Credit Package';
  const idEl = document.getElementById('credit_package_id');
  const nameEl = document.getElementById('credit_package_name');
  const priceEl = document.getElementById('credit_package_price');
  const pointsEl = document.getElementById('credit_package_points');
  const bonusEl = document.getElementById('credit_package_bonus');
  const startEl = document.getElementById('credit_package_start');
  const endEl = document.getElementById('credit_package_end');
  const activeEl = document.getElementById('credit_package_active');

  if (idEl) idEl.value = isEdit ? String(pkg.id || '') : '';
  if (nameEl) nameEl.value = isEdit ? String(pkg.name || '') : '';
  if (priceEl) priceEl.value = isEdit ? String(pkg.price ?? 0) : '0';
  if (pointsEl) pointsEl.value = isEdit ? String(pkg.credit ?? 0) : '0';
  if (bonusEl) bonusEl.value = isEdit ? String(pkg.first_time_bonus ?? 0) : '0';
  if (startEl) startEl.value = isEdit ? String(pkg.start_date || '') : '';
  if (endEl) endEl.value = isEdit ? String(pkg.end_date || '') : '';
  if (activeEl) activeEl.checked = isEdit ? !!pkg.active : true;

  updateCreditBonusLabel();
  const modalEl = document.getElementById('modalCreditPackage');
  if (window.bootstrap && modalEl) {
    bootstrap.Modal.getOrCreateInstance(modalEl).show();
  }
}

function collectCreditPackagePayload(){
  const name = document.getElementById('credit_package_name')?.value?.trim() || '';
  const price = parseFloat(document.getElementById('credit_package_price')?.value || '0') || 0;
  const credit = parseFloat(document.getElementById('credit_package_points')?.value || '0') || 0;
  const bonus = parseFloat(document.getElementById('credit_package_bonus')?.value || '0') || 0;
  const start_date = document.getElementById('credit_package_start')?.value || '';
  const end_date = document.getElementById('credit_package_end')?.value || '';
  const active = !!document.getElementById('credit_package_active')?.checked;
  return { name, price, credit, first_time_bonus: bonus, start_date, end_date, active };
}

async function saveCreditPackage(){
  const id = document.getElementById('credit_package_id')?.value?.trim() || '';
  const payload = collectCreditPackagePayload();
  if (payload.price <= 0) { jp_toast('Price must be greater than 0', true); return; }
  if (payload.credit <= 0) { jp_toast('Credit points must be greater than 0', true); return; }

  const isUpdate = !!id;
  const url = isUpdate ? `${CREDIT_PACKAGES_API}/${encodeURIComponent(id)}` : CREDIT_PACKAGES_API;
  const method = isUpdate ? 'PUT' : 'POST';
  try{
    const {res, data, txt} = await fetchJSON(url, {
      method,
      headers:{
        'Accept':'application/json',
        'Content-Type':'application/json',
        'X-Requested-With':'XMLHttpRequest'
      },
      body: JSON.stringify(payload)
    });
    if(!res.ok || !data || data.ok !== true){
      const msg = (data && (data.error || data.message)) || (txt || `HTTP ${res.status}`);
      throw new Error(msg);
    }
    jp_toast(isUpdate ? 'Credit package updated' : 'Credit package created');
    const modalEl = document.getElementById('modalCreditPackage');
    if (window.bootstrap && modalEl) {
      bootstrap.Modal.getOrCreateInstance(modalEl).hide();
    }
    await loadCreditPackages();
  }catch(e){
    console.error('saveCreditPackage failed', e);
    jp_toast(`Save failed: ${e?.message || e}`, true);
  }
}

async function deleteCreditPackage(id){
  if (!confirm('Delete this credit package?')) return;
  try{
    const {res, data, txt} = await fetchJSON(`${CREDIT_PACKAGES_API}/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: { 'Accept':'application/json', 'X-Requested-With':'XMLHttpRequest' },
      body: '{}'
    });
    if(!res.ok || !data || data.ok !== true){
      const msg = (data && (data.error || data.message)) || (txt || `HTTP ${res.status}`);
      throw new Error(msg);
    }
    jp_toast('Credit package deleted');
    await loadCreditPackages();
  }catch(e){
    console.error('deleteCreditPackage failed', e);
    jp_toast(`Delete failed: ${e?.message || e}`, true);
  }
}

function renderRows(plans){
  const $tbody = document.querySelector('#tbl_plans tbody');
  if(!$tbody) return;
  const rows = (plans||[]).map(normalizePlan);
  $tbody.innerHTML = rows.map(p => {
    const billingBadge = p.billing_mode === 'regular'
      ? '<span class="badge bg-primary ms-1" title="Regular Plan (Monthly Billing)">Regular</span>'
      : '<span class="badge bg-success ms-1" title="Prepaid Plan (Time-based)">Prepaid</span>';
    return `
    <tr class="plan-row" data-plan-id="${p.id ?? ''}">
      <td class="drag-handle" style="width:60px; min-width:60px; max-width:60px; cursor: grab; color: #0d6efd; padding: 0.5rem; text-align: center; font-size: 1.5rem;" title="Drag to reorder">⋮⋮</td>
      <td style="width:80px; min-width:80px; max-width:80px;">#${p.id ?? ''}</td>
      <td style="width:200px; min-width:200px; max-width:200px;" title="${escapeHtml(p.name ?? '')}">${escapeHtml(p.name ?? '')}${billingBadge}</td>
      <td class="text-end" style="width:110px; min-width:110px;">${fmtPrice(p.price)}</td>
      <td class="text-center" style="width:120px; min-width:120px;"><span class="badge bg-secondary">${escapeHtml(routerNameFromPlan(p))}</span></td>
      <td class="text-center" style="width:100px; min-width:100px;">${fmtValidity(p)}</td>
      <td class="text-center" style="width:110px; min-width:110px;">${fmtRate(p.rate_down)}</td>
      <td class="text-center" style="width:110px; min-width:110px;">${fmtRate(p.rate_up)}</td>
      <td class="text-center" style="width:110px; min-width:110px;">${(p.burst?.down_limit || p.burst_limit_down) ? escapeHtml(p.burst?.down_limit || p.burst_limit_down) : '—'}</td>
      <td class="text-center" style="width:110px; min-width:110px;">${(p.burst?.up_limit || p.burst_limit_up) ? escapeHtml(p.burst?.up_limit || p.burst_limit_up) : '—'}</td>
      <td class="text-center" style="width:110px; min-width:110px;">${p.queue_download ? escapeHtml(p.queue_download) : '—'}</td>
      <td class="text-center" style="width:110px; min-width:110px;">${p.queue_upload ? escapeHtml(p.queue_upload) : '—'}</td>
      <td class="text-center" style="width:120px; min-width:120px;">${(p.redeem_enabled && Number(p.redeem_points_cost) > 0) ? `<span class="badge bg-primary">${escapeHtml(p.redeem_points_cost)} pts</span>` : '<span class="text-muted">—</span>'}</td>
      <td class="text-center" style="width:130px; min-width:130px;">
        <span class="badge ${p.portal_hidden ? 'bg-secondary text-light' : 'bg-success'}">${p.portal_hidden ? 'Hidden' : 'Visible'}</span>
        <button class="btn btn-sm btn-outline-secondary ms-1" data-action="toggle-portal" data-id="${p.id}" data-hidden="${p.portal_hidden ? '1' : '0'}" title="${p.portal_hidden ? 'Show on portal' : 'Hide from portal'}" aria-label="${p.portal_hidden ? `Show Plan #${p.id} on portal` : `Hide Plan #${p.id} from portal`}">
          <i class="bi ${p.portal_hidden ? 'bi-eye' : 'bi-eye-slash'}"></i>
        </button>
      </td>
      <td class="text-end" style="width:150px; min-width:150px;">
        <button class="btn btn-sm btn-outline-primary me-1" data-action="edit" data-id="${p.id}" aria-label="Edit Plan #${p.id}"><i class="bi bi-pencil"></i></button>
        <button class="btn btn-sm btn-outline-danger" data-action="del" data-id="${p.id}" aria-label="Delete Plan #${p.id}"><i class="bi bi-trash"></i></button>
      </td>
    </tr>
  `}).join('');

  // Reinitialize Sortable after rendering
  initializeSortable();
  applyPlanPagination();
}

async function loadPlans(){
  try{
    const {data} = await fetchJSON(API_BASE, { headers: { 'Accept':'application/json','X-Requested-With':'XMLHttpRequest' }});
    const raw = Array.isArray(data?.plans) ? data.plans : [];
    const rows = raw.map(normalizePlan);
    renderRows(rows);
  }catch(e){
    console.error('loadPlans failed', e);
    jp_toast('Failed to load plans', true);
  }
}

async function savePlan(){
  const payload = serializePlanFromModal();
  if(!payload.name){ jp_toast('Name is required', true); return; }
  if(payload.redeem_enabled && (!payload.redeem_points_cost || payload.redeem_points_cost <= 0)){
    jp_toast('Redeem points cost must be greater than 0', true);
    return;
  }
  // router_index validation removed in global mode

  const isUpdate = !!payload.id;
  const url = isUpdate ? `${API_BASE}/${payload.id}` : API_BASE;
  const method = isUpdate ? 'PUT' : 'POST';

  try{
    const {res, data, txt} = await fetchJSON(url, {
      method,
      headers:{
        'Accept':'application/json',
        'Content-Type':'application/json',
        'X-Requested-With':'XMLHttpRequest'
      },
      body: JSON.stringify(payload)
    });
    if(!res.ok || !data || data.ok !== true){
      const msg = (data && (data.error || data.message)) || (txt || `HTTP ${res.status}`);
      throw new Error(msg);
    }
    jp_toast(isUpdate ? 'Plan updated' : 'Plan created');
    bootstrap.Modal.getOrCreateInstance(document.getElementById('modalPlan')).hide();
    await loadPlans();
  }catch(e){
    console.error('savePlan failed', e);
    jp_toast(`Save failed: ${e?.message || e}`, true);
  }
}

async function deletePlan(id){
  if(!confirm('Delete this plan?')) return;
  try{
    // Preferred REST delete
    let {res, data, txt} = await fetchJSON(`${API_BASE}/${id}`, {
      method:'DELETE',
      headers:{
        'Accept':'application/json',
        'Content-Type':'application/json',
        'X-Requested-With':'XMLHttpRequest'
      },
      body: '{}' // some servers require a JSON body for guard
    });

    // Legacy fallback
    if(!res.ok || !data || data.ok !== true){
      ({res, data, txt} = await fetchJSON(`${API_BASE}/${id}/delete`, {
        method:'POST',
        headers:{
          'Accept':'application/json',
          'Content-Type':'application/json',
          'X-Requested-With':'XMLHttpRequest'
        },
        body:'{}'
      }));
    }

    if(!res.ok || !data || data.ok !== true){
      const msg = (data && (data.error || data.message)) || (txt || `HTTP ${res.status}`);
      throw new Error(msg);
    }
    jp_toast('Plan deleted');
    await loadPlans();
  }catch(e){
    console.error('Delete plan failed', e);
    jp_toast('Delete failed: ' + (e?.message || e), true);
  }
}

document.addEventListener('DOMContentLoaded', ()=>{
  document.getElementById('plansPager')?.addEventListener('click', (e)=>{
    const a = e.target.closest('a[data-page]');
    if(!a) return;
    e.preventDefault();
    const page = parseInt(a.getAttribute('data-page'), 10);
    if(!Number.isNaN(page)){
      plansPage = page;
      applyPlanPagination();
    }
  });
  applyPlanPagination();

  // Open modal (Add)
  document.getElementById('btnAdd')?.addEventListener('click', async ()=>{
    document.getElementById('modalTitle').textContent = 'Add Plan';
    await fetchRouters();
    // clear fields
    ['plan_id','name','rate_down','rate_up','queue_download','queue_upload','description'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
    const lad = document.getElementById('limit_at_down'); if (lad) lad.value = '';
    const lau = document.getElementById('limit_at_up'); if (lau) lau.value = '';
    ['days','hours','price','grace_fee_per_day'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value='0'; });
    const be = document.getElementById('burst_enabled'); if(be) be.checked=false;
    ['burst_up_limit','burst_down_limit','burst_up_threshold','burst_down_threshold'].forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
    const bt = document.getElementById('burst_time'); if(bt) bt.value='10s';
    const ph = document.getElementById('portal_hidden'); if (ph) ph.checked = false;
    const re = document.getElementById('redeem_enabled'); if (re) re.checked = false;
    const rpc = document.getElementById('redeem_points_cost'); if (rpc) rpc.value = '0';
    applyRedeemToggle();
    syncRedeemCalcPrice();
    // Reset burst field visibility
    const bf = document.getElementById('burst_fields');
    if (bf) bf.classList.add('d-none');
  });

  // Ensure routers are loaded when modal becomes visible
  document.getElementById('modalPlan')?.addEventListener('show.bs.modal', fetchRouters);

  // Save bindings
  document.getElementById('btnSavePlan')?.addEventListener('click', (e)=>{ e.preventDefault(); savePlan(); });
  document.getElementById('frmPlan')?.addEventListener('submit', (e)=>{ e.preventDefault(); savePlan(); });
  document.getElementById('btnSaveRegularFees')?.addEventListener('click', (e)=>{ e.preventDefault(); saveRegularFeeSettings(); });

  // Rewards search + adjustments
  document.getElementById('rewardsSearchBtn')?.addEventListener('click', searchRewards);
  document.getElementById('rewardsSearchInput')?.addEventListener('keydown', (e)=>{
    if (e.key === 'Enter') {
      e.preventDefault();
      searchRewards();
    }
  });
  document.getElementById('rewardsSearchResults')?.addEventListener('click', (e)=>{
    const btn = e.target.closest('[data-index]');
    if (!btn) return;
    const idx = parseInt(btn.getAttribute('data-index'), 10);
    if (!isNaN(idx)) selectRewardAccount(idx);
  });
  document.getElementById('pointsAdjustForm')?.addEventListener('submit', (e)=>{
    e.preventDefault();
    submitRewardAdjustment('points');
  });
  document.getElementById('creditAdjustForm')?.addEventListener('submit', (e)=>{
    e.preventDefault();
    submitRewardAdjustment('credit');
  });

  // Credit packages
  document.getElementById('btnAddCreditPackage')?.addEventListener('click', ()=>openCreditPackageModal(null));
  document.getElementById('btnSaveCreditPackage')?.addEventListener('click', (e)=>{
    e.preventDefault();
    saveCreditPackage();
  });
  document.getElementById('frmCreditPackage')?.addEventListener('submit', (e)=>{
    e.preventDefault();
    saveCreditPackage();
  });
  document.getElementById('tbl_credit_packages')?.addEventListener('click', (e)=>{
    const btn = e.target.closest('button[data-action]');
    if (!btn) return;
    const action = btn.getAttribute('data-action');
    const id = btn.getAttribute('data-id') || '';
    if (!id) return;
    if (action === 'edit-credit') {
      const pkg = creditPackages.find(p => String(p.id) === String(id));
      if (pkg) openCreditPackageModal(pkg);
      return;
    }
    if (action === 'del-credit') {
      deleteCreditPackage(id);
    }
  });

  // Table action delegation
  document.getElementById('tbl_plans')?.addEventListener('click', async (e)=>{
    const btn = e.target.closest('button[data-action]');
    if(!btn) return;
    let id = btn.getAttribute('data-id') || '';
    id = String(id).replace(/[^0-9]/g,'');  // strip any leading '#'
    if(!id){ jp_toast('Invalid plan id', true); return; }
    const action = btn.getAttribute('data-action');

    if(action === 'toggle-portal'){
      const currentlyHidden = btn.getAttribute('data-hidden') === '1';
      togglePortalVisibility(id, !currentlyHidden);
      return;
    }

    if(action === 'edit'){
      try{
        const {data} = await fetchJSON(`${API_BASE}/${id}`, { headers: { 'Accept':'application/json','X-Requested-With':'XMLHttpRequest' }});
        const p = data?.plan;
        if(!p){ jp_toast('Plan not found', true); return; }
        document.getElementById('modalTitle').textContent = 'Edit Plan';
        await fetchRouters();
        fillForm(p);
        bootstrap.Modal.getOrCreateInstance(document.getElementById('modalPlan')).show();
      }catch(e){
        console.error('editPlan failed', e);
        jp_toast('Failed to load plan', true);
      }
      return;
    }

    if(action === 'del'){
      deletePlan(id);
      return;
    }
  });

  // Global burst toggle wiring: one-time
  const burstToggleGlobal = document.getElementById('burst_enabled');
  const burstFieldsGlobal = document.getElementById('burst_fields');
  if (burstToggleGlobal && burstFieldsGlobal) {
    const applyBurstVisibility = () => {
      if (burstToggleGlobal.checked) {
        burstFieldsGlobal.classList.remove('d-none');
      } else {
        burstFieldsGlobal.classList.add('d-none');
      }
    };
    burstToggleGlobal.addEventListener('change', applyBurstVisibility);
    // Apply once on load so state matches current checkbox
    applyBurstVisibility();
  }

  const redeemToggle = document.getElementById('redeem_enabled');
  if (redeemToggle) {
    redeemToggle.addEventListener('change', applyRedeemToggle);
    applyRedeemToggle();
  }

  // Initial loads
  (async function init(){
    await fetchRouters();
    await loadRegularFeeSettings();
    await loadPlans();
    await loadRewardSettings();
    await loadCreditPackages();
    initRedeemCalculator();
    initCreditCalculator();
    setRewardsAdjustEnabled(false);
    // Initialize Sortable after initial load
    initializeSortable();
  })();
});
