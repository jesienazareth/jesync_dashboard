from flask import Blueprint, jsonify, request

bp = Blueprint("tenants_api", __name__)

@bp.get("")
@bp.get("/")
def list_tenants():
    items = _load_state()
    return jsonify({"ok": True, "tenants": items, "root_domain": ROOT_DOMAIN})

@bp.get("/check")
def check_tenant():
    slug = (request.args.get("slug") or "").strip().lower()
    err = _validate_slug(slug)
    if err:
        return jsonify({"ok": False, "error": err}), 400
    items = _load_state()
    exists = any(i.get("subdomain") == slug for i in items)
    return jsonify({"ok": True, "available": (not exists)})

@bp.post("")
def create_tenant():
    data = request.get_json(silent=True) or {}
    # accept both {slug, target_url} and {subdomain, target}
    slug = (data.get("subdomain") or data.get("slug") or "").strip().lower()
    target = (data.get("target") or data.get("target_url") or "").strip()

    # ... rest of the function unchanged ...

    cf = _create_tenant(slug, target)
    items = _load_state()
    return jsonify({"ok": True, "result": cf, "tenants": items})

@bp.patch("/<slug>")
def patch_tenant(slug: str):
    data = request.get_json(silent=True) or {}
    new_slug = (data.get("subdomain") or data.get("slug") or slug).strip().lower()
    new_target = (data.get("target") or data.get("target_url") or "").strip() or None

    # ... rest of the function unchanged ...
