(() => {
  const SEGMENT_SIZE = 160;

  function updateCounter(el) {
    const id = el.getAttribute('data-sms-counter');
    if (!id) return;
    const target = document.getElementById(id);
    if (!target) return;
    const len = (el.value || '').length;
    const segments = len === 0 ? 0 : Math.ceil(len / SEGMENT_SIZE);
    target.textContent = `${len} chars · ${segments} SMS`;
  }

  function init() {
    const fields = document.querySelectorAll('textarea[data-sms-counter]');
    fields.forEach((el) => {
      updateCounter(el);
      el.addEventListener('input', () => updateCounter(el));
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
