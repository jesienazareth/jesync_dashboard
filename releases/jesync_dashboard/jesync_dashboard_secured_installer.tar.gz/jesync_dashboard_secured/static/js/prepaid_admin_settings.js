/**
 * Prepaid Admin Plans – CRUD + serialization (Price, Description, Burst)
 * Uses /prepaid/admin/api/plans endpoints.
 * Assumes the modal has fields with ids:
 *  name, router_index, rate_down, rate_up, days, hours, queue_download, queue_upload,
 *  price, description, burst_enabled, burst_up_limit, burst_down_limit,
 *  burst_up_threshold, burst_down_threshold, burst_time.
 *
 * Also assumes there are:
 *  - <tbody id="plansTableBody"></tbody>
 *  - #btnAddPlan (opens empty modal)
 *  - #btnSavePlan (saves)
 *  - Modal id: #modalPlan
 */
(function(){
  const $ = (sel, root=document)=> root.querySelector(sel);
  const $$ = (sel, root=document)=> Array.from(root.querySelectorAll(sel));
  function showToast(msg){
    try {
      const el = document.getElementById('globalToastBody');
      if (el) { el.textContent = String(msg); }
      const t = (window.bootstrap && document.getElementById('globalToast')) ? bootstrap.Toast.getOrCreateInstance(document.getElementById('globalToast')) : null;
      if (t) t.show();
      else alert(String(msg));
    } catch(_){ alert(String(msg)); }
  }

  const TBody = $('#plansTableBody');
  const BtnAdd = $('#btnAddPlan');
  const BtnSave = $('#btnSavePlan');
  const ModalEl = $('#modalPlan');

  const LIST_URL = '/prepaid/admin/api/plans';   // returns full objects (incl. burst)
  const API_BASE = '/prepaid/api/plans';         // create/update/delete
  async function parseMaybeJSON(res){
    const txt = await res.text();
    try { return [true, JSON.parse(txt)]; }
    catch { return [false, txt]; }
  }

  // Modal fields
  const fld = {
    id: $('#plan_id'),
    name: $('#name'),
    router_index: $('#router_index'),
    rate_down: $('#rate_down'),
    rate_up: $('#rate_up'),
    days: $('#days'),
    hours: $('#hours'),
    queue_download: $('#queue_download'),
    queue_upload: $('#queue_upload'),
    price: $('#price'),
    description: $('#description'),
    burst_enabled: $('#burst_enabled'),
    burst_up_limit: $('#burst_up_limit'),
    burst_down_limit: $('#burst_down_limit'),
    burst_up_threshold: $('#burst_up_threshold'),
    burst_down_threshold: $('#burst_down_threshold'),
    burst_time: $('#burst_time'),
    burst_fields: $('#burst_fields'),
    livePreview: $('#livePreview')
  };

  let plansCache = [];
  let editingId = null;

  function currency(n){
    const v = Number.isFinite(Number(n)) ? Number(n) : 0;
    return '₱' + v.toFixed(2);
  }

  function planRowHTML(p){
    const validity = []
    if ((p.days|0) > 0) validity.push((p.days|0)===1?'1 Day':`${p.days|0} Days`);
    if ((p.hours|0) > 0) validity.push((p.hours|0)===1?'1 Hour':`${p.hours|0} Hours`);
    const validStr = validity.length? validity.join(' ') : 'No Expiry';
    const priceStr = (p.price && Number(p.price)>0)? currency(p.price) : '—';
    const burstBadge = (p.burst && p.burst.enabled) ? `<span class="badge bg-info">Burst</span>` : '';
    const desc = (p.description && String(p.description).trim()) ? String(p.description).trim() : '';
    return `
      <tr data-id="${p.id}">
        <td class="text-nowrap fw-semibold">${p.name || '-'}</td>
        <td class="text-nowrap">${(p.rate_down||'-')}/${(p.rate_up||'-')}</td>
        <td class="text-nowrap">${validStr}</td>
        <td class="text-nowrap">${priceStr}</td>
        <td>${desc}</td>
        <td class="text-nowrap">${burstBadge}</td>
        <td class="text-end">
          <button type="button" class="btn btn-sm btn-outline-primary me-2 btnEditPlan">Edit</button>
          <button type="button" class="btn btn-sm btn-outline-danger btnDeletePlan">Delete</button>
        </td>
      </tr>`;
  }

  async function loadPlans(){
    try{
      const res = await fetch(LIST_URL, { headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } });
      const [isJSON, dataOrText] = await parseMaybeJSON(res);
      if(!isJSON) throw new Error(String(dataOrText).slice(0, 300));
      const data = dataOrText;
      if(!data || data.ok!==true) throw new Error(data && data.error || 'Failed to load plans');
      plansCache = data.plans || [];
      window.prepaidPlans = plansCache;
      if(TBody){
        TBody.innerHTML = plansCache.map(planRowHTML).join('');
      }
    }catch(e){
      console.error(e);
      if(TBody) TBody.innerHTML = `<tr><td colspan="7" class="text-danger">Failed to load plans: ${e.message||e}</td></tr>`;
    }
  }

  function openModalFor(plan){
    editingId = plan && plan.id != null ? Number(plan.id) : null;
    if(fld.id) fld.id.value = editingId != null ? String(editingId) : '';
    fld.name && (fld.name.value = plan?.name || '');
    fld.router_index && (fld.router_index.value = plan?.router_index ?? 0);
    fld.rate_down && (fld.rate_down.value = plan?.rate_down || '');
    fld.rate_up && (fld.rate_up.value = plan?.rate_up || '');
    fld.days && (fld.days.value = plan?.days ?? 0);
    fld.hours && (fld.hours.value = plan?.hours ?? 0);
    fld.queue_download && (fld.queue_download.value = plan?.queue_download || '');
    fld.queue_upload && (fld.queue_upload.value = plan?.queue_upload || '');
    fld.price && (fld.price.value = (plan?.price != null ? plan.price : 0));
    fld.description && (fld.description.value = plan?.description || '');
    // burst
    const b = (plan && plan.burst) || {};
    if(fld.burst_enabled) fld.burst_enabled.checked = !!b.enabled;
    if(fld.burst_up_limit) fld.burst_up_limit.value = b.up_limit || '';
    if(fld.burst_down_limit) fld.burst_down_limit.value = b.down_limit || '';
    if(fld.burst_up_threshold) fld.burst_up_threshold.value = b.up_threshold || '';
    if(fld.burst_down_threshold) fld.burst_down_threshold.value = b.down_threshold || '';
    if(fld.burst_time) fld.burst_time.value = b.time || '10s';
    if (fld.burst_fields) {
      fld.burst_fields.classList.toggle('d-none', !fld.burst_enabled.checked);
    }
    if (fld.burst_enabled) {
      // remove previous listener if any
      fld.burst_enabled.onchange = null;
      fld.burst_enabled.addEventListener('change', function(){
        if (fld.burst_fields) {
          fld.burst_fields.classList.toggle('d-none', !fld.burst_enabled.checked);
        }
      }, { once:false });
    }
    // update preview if function exists
    if(typeof window.updatePreview === 'function'){
      try { window.updatePreview(); } catch(_){}
    } else if (fld.livePreview){
      // basic inline preview fallback
      const rd = fld.rate_down?.value.trim() || '—';
      const ru = fld.rate_up?.value.trim() || '—';
      const d = parseInt(fld.days?.value||'0',10)||0;
      const h = parseInt(fld.hours?.value||'0',10)||0;
      const val = [];
      if(d>0) val.push(d===1?'1 Day':`${d} Days`);
      if(h>0) val.push(h===1?'1 Hour':`${h} Hours`);
      const vstr = val.length? val.join(' ') : 'No Expiry';
      const price = parseFloat(fld.price?.value||'0')||0;
      fld.livePreview.textContent = `${rd}/${ru} • ${vstr}${price>0?(' • '+currency(price)) : ''} • IPoE`;
    }
    // show modal
    if(window.bootstrap && ModalEl){
      const m = bootstrap.Modal.getOrCreateInstance(ModalEl);
      m.show();
    }
  }

  function collectPayload(){
    const price = parseFloat(fld.price?.value||'0')||0;
    const payload = {
      name: fld.name?.value.trim() || '',
      router_index: parseInt(fld.router_index?.value||'0',10) || 0,
      rate_down: fld.rate_down?.value.trim() || '',
      rate_up: fld.rate_up?.value.trim() || '',
      days: parseInt(fld.days?.value||'0',10) || 0,
      hours: parseInt(fld.hours?.value||'0',10) || 0,
      queue_download: fld.queue_download?.value.trim() || '',
      queue_upload: fld.queue_upload?.value.trim() || '',
      price: price < 0 ? 0 : price,
      description: fld.description?.value || '',
      burst: {
        enabled: !!fld.burst_enabled?.checked,
        up_limit: fld.burst_up_limit?.value.trim() || '',
        down_limit: fld.burst_down_limit?.value.trim() || '',
        up_threshold: fld.burst_up_threshold?.value.trim() || '',
        down_threshold: fld.burst_down_threshold?.value.trim() || '',
        time: fld.burst_time?.value.trim() || '10s'
      }
    };
    return payload;
  }

  async function savePlan(){
    const payload = collectPayload();
    try{
      const isEdit = editingId != null;
      const url = isEdit ? `${API_BASE}/${editingId}` : API_BASE;
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(payload)
      });
      const [isJSON, dataOrText] = await parseMaybeJSON(res);
      const data = isJSON ? dataOrText : null;
      if(!res.ok || !isJSON || !data || data.ok !== true){
        const msg = (data && (data.error || data.message)) || String(dataOrText).slice(0, 300) || `HTTP ${res.status}`;
        throw new Error(msg);
      }
      if(window.bootstrap && ModalEl){
        bootstrap.Modal.getOrCreateInstance(ModalEl).hide();
      }
      await loadPlans();
    }catch(e){
      console.error('Save plan failed', e);
      showToast('Save failed: ' + (e && e.message ? e.message : e));
    }
  }

  async function deletePlan(id){
    if(!confirm('Delete this plan?')) return;
    try{
      // Prefer proper REST endpoint
      let res = await fetch(`/prepaid/api/plans/${id}`, {
        method: 'DELETE',
        headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
      });
      let txt = await res.text();
      let data; try { data = JSON.parse(txt); } catch { data = null; }

      // Fallback for older servers
      if(!res.ok || !data || data.ok !== true){
        res = await fetch(`/prepaid/api/plans/${id}/delete`, {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: '{}' // keep the API guard happy if it’s still strict
        });
        txt = await res.text();
        try { data = JSON.parse(txt); } catch { data = null; }
      }

      if(!res.ok || !data || data.ok !== true){
        const msg = (data && (data.error || data.message)) || (txt || `HTTP ${res.status}`);
        throw new Error(msg);
      }
      await loadPlans();
    }catch(e){
      console.error('Delete plan failed', e);
      showToast('Delete failed: ' + (e && e.message ? e.message : e));
    }
  }

  // Bind table click handlers (edit/delete)
  document.addEventListener('click', function(e){
    const btnEdit = e.target.closest('.btnEditPlan');
    if(btnEdit){
      const tr = btnEdit.closest('tr');
      const id = tr && tr.getAttribute('data-id');
      const plan = plansCache.find(p=> String(p.id) === String(id));
      openModalFor(plan || null);
      return;
    }
    const btnDel = e.target.closest('.btnDeletePlan');
    if(btnDel){
      const tr = btnDel.closest('tr');
      const id = tr && tr.getAttribute('data-id');
      if(id) deletePlan(id);
    }
  });

  // Bind add/save
  if(BtnAdd){
    BtnAdd.addEventListener('click', function(){
      openModalFor({
        name:'', router_index:0, rate_down:'', rate_up:'', days:0, hours:0,
        queue_download:'', queue_upload:'', price:0, description:'',
        burst: { enabled:false, up_limit:'', down_limit:'', up_threshold:'', down_threshold:'', time:'10s' }
      });
    });
  }
  if(BtnSave){ BtnSave.addEventListener('click', savePlan); }

  // On modal shown, ensure burst visibility sync and preview refresh
  if(ModalEl){
    ModalEl.addEventListener('shown.bs.modal', function(){
      if(fld.burst_fields && fld.burst_enabled){
        fld.burst_fields.classList.toggle('d-none', !fld.burst_enabled.checked);
      }
      if(typeof window.updatePreview === 'function'){
        try { window.updatePreview(); } catch(_){}
      }
    });
  }

  // Initial load
  loadPlans();

  // --- Admin Settings (Routers/Test, PW toggle, Copy, Preview) ---
  // Router API Test (event delegation)
  document.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('.btnTestApi');
    if (!btn) return;

    const idx = Number(btn.getAttribute('data-index') || 0);
    const card = btn.closest('.router-item');
    const row = card ? card.querySelector('.testRow') : null;
    const spin = row ? row.querySelector('.spinner-border') : null;
    const msg = row ? row.querySelector('.msg') : null;

    if (row) row.classList.remove('d-none');
    if (msg) {
      msg.textContent = '';
      msg.classList.remove('text-danger', 'text-success');
    }
    if (spin) spin.classList.remove('d-none');

    try {
      const res = await fetch('/prepaid/admin/test_api', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ router_index: idx })
      });
      const j = await res.json().catch(() => ({}));
      if (msg) {
        if (j && j.ok) {
          msg.textContent = j.message || 'OK';
          msg.classList.add('text-success');
        } else {
          msg.textContent = (j && (j.message || j.error)) || ('HTTP ' + res.status);
          msg.classList.add('text-danger');
        }
      }
    } catch (e) {
      if (msg) {
        msg.textContent = 'Request error: ' + e;
        msg.classList.add('text-danger');
      }
    } finally {
      if (spin) spin.classList.add('d-none');
    }
  });

  // Toggle password visibility
  document.addEventListener('click', (ev) => {
    const btn = ev.target.closest('.btnTogglePw');
    if (!btn) return;
    const name = btn.getAttribute('data-target');
    if (!name) return;
    const input = document.querySelector(`input[name="${CSS.escape(name)}"]`);
    if (!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
  });

  // Copy to clipboard
  document.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('.btnCopy');
    if (!btn) return;
    const name = btn.getAttribute('data-target');
    if (!name) return;
    const input = document.querySelector(`input[name="${CSS.escape(name)}"]`);
    if (!input) return;
    try {
      await navigator.clipboard.writeText(input.value || '');
      btn.classList.add('btn-success');
      setTimeout(() => btn.classList.remove('btn-success'), 600);
    } catch (e) {
      console.warn('Clipboard error:', e);
    }
  });

  // Reload preview
  const reload = $('#btnReloadPreview');
  if (reload) {
    reload.addEventListener('click', (e) => {
      e.preventDefault();
      const ifr = $('#portalLivePreview');
      if (ifr) {
        const src = ifr.getAttribute('src') || '/prepaid/buy';
        // Force reload with cache-buster
        const hasQuery = src.includes('?');
        const newSrc = src + (hasQuery ? '&' : '?') + 't=' + Date.now();
        ifr.setAttribute('src', newSrc);
      }
    });
  }
  // ---- Routers repeater (Add / Remove / Reindex) ----
  (function(){
    const Repeater = document.getElementById('routersRepeater');
    const BtnAddRouter = document.getElementById('btnAddRouter');
    const Cnt = document.getElementById('routers_count');
    const Tpl = document.getElementById('routerItemTpl');

    if (!Repeater || !Tpl) return;

    function setRoutersCount(n){
      if (Cnt) Cnt.value = String(n);
    }

    function makeNodeFromTemplate(index){
      // Use the template's innerHTML with placeholders
      const html = Tpl.innerHTML
        .replace(/__INDEX__/g, String(index))
        .replace(/__NUM__/g, String(index + 1))
        .replace(/router___INDEX___/g, 'router_' + index + '_');
      const wrap = document.createElement('div');
      wrap.innerHTML = html.trim();
      return wrap.firstElementChild;
    }

    function reindexRouters(){
      const items = Array.from(Repeater.querySelectorAll('.router-item'));
      items.forEach((el, i) => {
        el.setAttribute('data-index', i);
        // Header label
        const hdr = el.querySelector('.fw-semibold');
        if (hdr) hdr.textContent = 'Router #' + (i + 1);
        // Update name=router_N_* and data-index on Test button / data-target on password toggle
        el.querySelectorAll('[name]').forEach(inp => {
          inp.name = inp.name.replace(/router_\d+_/,'router_' + i + '_');
        });
        const btnTest = el.querySelector('.btnTestApi');
        if (btnTest) btnTest.setAttribute('data-index', i);
        const btnPw = el.querySelector('.btnTogglePw');
        if (btnPw) {
          const tgt = btnPw.getAttribute('data-target') || '';
          btnPw.setAttribute('data-target', tgt.replace(/router_\d+_password/, 'router_' + i + '_password'));
        }
        // Also fix any data-target attributes that include router indices
        el.querySelectorAll('[data-target]').forEach(elem => {
          const v = elem.getAttribute('data-target') || '';
          elem.setAttribute('data-target', v.replace(/router_\d+_/,'router_' + i + '_'));
        });
      });
      setRoutersCount(items.length);
    }

    function addRouter(){
      const idx = Repeater.querySelectorAll('.router-item').length;
      const node = makeNodeFromTemplate(idx);
      Repeater.appendChild(node);
      reindexRouters();
      // Scroll to the new item for convenience
      node.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    // Add router
    if (BtnAddRouter) {
      BtnAddRouter.addEventListener('click', addRouter);
    }

    // Remove router (delegation)
    document.addEventListener('click', function(ev){
      const btn = ev.target.closest('.btnRemoveRouter');
      if (!btn) return;
      const item = btn.closest('.router-item');
      if (!item) return;
      item.remove();
      reindexRouters();
    });

    // Initial normalize (ensure indices are sequential starting at 0)
    reindexRouters();
  })();
})();

// ---- Auto-Account UI helpers (preview + groups) ----
(function () {
  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $all(sel, ctx) { return Array.from((ctx || document).querySelectorAll(sel)); }

  const strategySel = $('#auto_account_strategy');
  const previewBox = $('#auto_account_preview');

  function currentPrefix() {
    return (document.querySelector('input[name="auto_account_prefix"]')?.value || 'PREPAID').toUpperCase();
  }
  function valNum(name, def) {
    const v = document.querySelector(`input[name="${name}"]`)?.value;
    const n = parseInt(v, 10);
    return Number.isFinite(n) ? n : def;
  }
  function strategy() { return strategySel?.value || 'serial'; }

  function showGroups() {
    const isSerial = strategy() === 'serial';
    $all('.serial-group').forEach(el => el.classList.toggle('d-none', !isSerial));
    $all('.random-group').forEach(el => el.classList.toggle('d-none', isSerial));
  }

  function buildPreview() {
    if (!previewBox) return;
    try {
      const pref = currentPrefix();
      if (strategy() === 'serial') {
        const width = valNum('auto_account_serial_width', 7);
        previewBox.textContent = `${pref}${'0'.repeat(Math.max(1, width))}`;
      } else {
        const rlen = valNum('auto_account_random_length', valNum('auto_account_length', 8));
        previewBox.textContent = `${pref}${'X'.repeat(Math.max(1, rlen))}`;
      }
    } catch {
      previewBox.textContent = '—';
    }
  }

  function wire() {
    if (!strategySel) return;
    // Initial render
    showGroups();
    buildPreview();

    document.addEventListener('change', (ev) => {
      const t = ev.target;
      if (!t) return;
      if (
        t.id === 'auto_account_strategy' ||
        t.name === 'auto_account_prefix' ||
        t.name === 'auto_account_serial_width' ||
        t.name === 'auto_account_random_length' ||
        t.name === 'auto_account_length'
      ) {
        showGroups();
        buildPreview();
      }
    });

    document.addEventListener('input', (ev) => {
      const t = ev.target;
      if (!t) return;
      if (
        t.name === 'auto_account_prefix' ||
        t.name === 'auto_account_serial_width' ||
        t.name === 'auto_account_random_length' ||
        t.name === 'auto_account_length'
      ) {
        buildPreview();
      }
    });
  }

  window.addEventListener('DOMContentLoaded', wire);
})();