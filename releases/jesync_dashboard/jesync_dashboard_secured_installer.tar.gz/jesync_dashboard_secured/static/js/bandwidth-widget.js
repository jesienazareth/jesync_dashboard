/**
 * Jesync Bandwidth Monitor Widget
 * Real-time bandwidth monitoring with interactive ApexCharts graphs
 *
 * Features:
 * - Real-time streaming chart with auto-update
 * - Historical data views (1m, 5m, 10m, 30m, 1h, 1d, 1w, 1M)
 * - Speed gauge display
 * - Usage summary (today, week, month)
 * - Mobile responsive
 * - Dark/Light mode support
 */

class BandwidthWidget {
    constructor(options) {
        this.containerId = options.containerId;
        this.accountNo = options.accountNo;
        this.planSpeed = options.planSpeed || { download: 100000000, upload: 100000000 }; // Default 100Mbps
        this.updateInterval = options.updateInterval || 2000; // 2 seconds for live updates
        this.maxDataPoints = options.maxDataPoints || 60; // Keep 60 data points in view
        this.showGauge = options.showGauge !== false;
        this.showSummary = options.showSummary !== false;
        this.compact = options.compact || false;

        this.chart = null;
        this.gaugeChart = null;
        this.updateTimer = null;
        this.socketConnected = false;
        this.currentPeriod = '5m';
        this.currentStyle = options.chartStyle || 'libreqos'; // Default chart style
        this.chartData = {
            download: [],
            upload: [],
            timestamps: []
        };

        // Available chart styles - using 'smooth' for fluid flowing water effect
        this.chartStyles = {
            'smooth-area': { label: 'Smooth Flow', curve: 'smooth', fillOpacity: 0.5, strokeWidth: 1.5 },
            'gradient-area': { label: 'Gradient Fill', curve: 'smooth', fillOpacity: 0.7, strokeWidth: 1 },
            'stacked-area': { label: 'Stacked Area', curve: 'smooth', fillOpacity: 0.6, strokeWidth: 1, stacked: true },
            'line-chart': { label: 'Line Only', curve: 'smooth', fillOpacity: 0, strokeWidth: 2 },
            'step-area': { label: 'Step Area', curve: 'stepline', fillOpacity: 0.4, strokeWidth: 1.5 },
            'libreqos': { label: 'LibreQoS Style', curve: 'smooth', fillOpacity: 0.45, strokeWidth: 1.2 }
        };

        this.init();
    }

    init() {
        this.createContainer();
        this.initChart();
        if (this.showGauge && !this.compact) {
            this.initGauge();
        }
        this.loadData();
        this.startLiveUpdates();
        this.initSocketIO();
    }

    createContainer() {
        const container = document.getElementById(this.containerId);
        if (!container) return;

        const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';

        // Build style selector options
        const styleOptions = Object.entries(this.chartStyles)
            .map(([key, val]) => `<option value="${key}" ${key === this.currentStyle ? 'selected' : ''}>${val.label}</option>`)
            .join('');

        container.innerHTML = `
            <div class="bw-widget ${this.compact ? 'bw-widget-compact' : ''}" data-theme="${isDark ? 'dark' : 'light'}">
                ${!this.compact ? `
                <div class="bw-header">
                    <div class="bw-title">
                        <i class="bi bi-speedometer2"></i>
                        <span>Bandwidth Monitor</span>
                    </div>
                    <div class="bw-header-controls">
                        <div class="bw-period-selector">
                            <button class="bw-period-btn" data-period="1m">1m</button>
                            <button class="bw-period-btn active" data-period="5m">5m</button>
                            <button class="bw-period-btn" data-period="10m">10m</button>
                            <button class="bw-period-btn" data-period="30m">30m</button>
                            <button class="bw-period-btn" data-period="1h">1h</button>
                            <button class="bw-period-btn" data-period="1d">1d</button>
                            <button class="bw-period-btn" data-period="1w">1w</button>
                            <button class="bw-period-btn" data-period="1M">1M</button>
                        </div>
                        <div class="bw-style-selector">
                            <label>Style:</label>
                            <select class="bw-style-select" id="${this.containerId}-style">
                                ${styleOptions}
                            </select>
                        </div>
                    </div>
                </div>
                ` : ''}

                <div class="bw-content">
                    ${this.showGauge && !this.compact ? `
                    <div class="bw-gauges">
                        <div class="bw-gauge-container download">
                            <div class="bw-gauge-label">Download</div>
                            <div id="${this.containerId}-gauge-dl" class="bw-gauge">
                                <div class="bw-speedometer" id="${this.containerId}-speedometer-dl"></div>
                                <div class="bw-gauge-glow"></div>
                                <div class="bw-gauge-center">
                                    <div class="bw-gauge-value download" id="${this.containerId}-dl-value">0</div>
                                    <div class="bw-gauge-unit" id="${this.containerId}-dl-unit">Mbps</div>
                                </div>
                            </div>
                        </div>
                        <div class="bw-gauge-container upload">
                            <div class="bw-gauge-label">Upload</div>
                            <div id="${this.containerId}-gauge-ul" class="bw-gauge">
                                <div class="bw-speedometer" id="${this.containerId}-speedometer-ul"></div>
                                <div class="bw-gauge-glow"></div>
                                <div class="bw-gauge-center">
                                    <div class="bw-gauge-value upload" id="${this.containerId}-ul-value">0</div>
                                    <div class="bw-gauge-unit" id="${this.containerId}-ul-unit">Mbps</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    ` : ''}

                    ${this.compact ? `
                    <div class="bw-live-compact">
                        <div class="bw-live-item bw-download">
                            <i class="bi bi-arrow-down-circle-fill"></i>
                            <span id="${this.containerId}-dl-compact">0 Mbps</span>
                        </div>
                        <div class="bw-live-item bw-upload">
                            <i class="bi bi-arrow-up-circle-fill"></i>
                            <span id="${this.containerId}-ul-compact">0 Mbps</span>
                        </div>
                    </div>
                    ` : ''}

                    <div class="bw-chart-container">
                        <div id="${this.containerId}-chart" class="bw-chart"></div>
                    </div>

                    ${this.showSummary && !this.compact ? `
                    <div class="bw-summary">
                        <div class="bw-summary-item">
                            <div class="bw-summary-label">Today</div>
                            <div class="bw-summary-value" id="${this.containerId}-today">-- GB</div>
                        </div>
                        <div class="bw-summary-item">
                            <div class="bw-summary-label">This Week</div>
                            <div class="bw-summary-value" id="${this.containerId}-week">-- GB</div>
                        </div>
                        <div class="bw-summary-item">
                            <div class="bw-summary-label">This Month</div>
                            <div class="bw-summary-value" id="${this.containerId}-month">-- GB</div>
                        </div>
                    </div>
                    ` : ''}
                </div>

                <div class="bw-status">
                    <span class="bw-status-indicator" id="${this.containerId}-status"></span>
                    <span class="bw-status-text" id="${this.containerId}-status-text">Connecting...</span>
                </div>
            </div>
        `;

        // Bind period selector events
        container.querySelectorAll('.bw-period-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                container.querySelectorAll('.bw-period-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.currentPeriod = e.target.dataset.period;
                this.loadData();
            });
        });

        // Bind style selector event
        const styleSelect = document.getElementById(`${this.containerId}-style`);
        if (styleSelect) {
            styleSelect.addEventListener('change', (e) => {
                this.currentStyle = e.target.value;
                this.updateChartStyle();
            });
        }

        // Watch for theme changes
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.attributeName === 'data-bs-theme') {
                    this.updateChartTheme();
                }
            });
        });
        observer.observe(document.documentElement, { attributes: true });
    }

    getAccentColor() {
        // Get accent color from CSS variable or use default
        const computed = getComputedStyle(document.documentElement);
        const accent = computed.getPropertyValue('--jesync-accent')?.trim() ||
                       computed.getPropertyValue('--accent')?.trim() ||
                       computed.getPropertyValue('--brand1')?.trim() ||
                       '#10b981';
        return accent;
    }

    getChartOptions() {
        const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';
        const accentColor = this.getAccentColor();
        const style = this.chartStyles[this.currentStyle] || this.chartStyles['libreqos'];

        // Generate complementary color for upload (slightly darker/lighter shade)
        const uploadColor = this.adjustColorBrightness(accentColor, isDark ? 50 : -40);

        // Apply smoothing for flowing water effect like LibreQoS
        // Using lower alpha (0.15) for more aggressive smoothing
        const smoothedDownload = this.smoothData(this.chartData.download, 0.15);
        const smoothedUpload = this.smoothData(this.chartData.upload, 0.15);

        // Skip interpolation - direct smoothed data provides cleaner results
        // (interpolation can sometimes amplify small remaining artifacts)
        const dlInterp = { data: smoothedDownload, timestamps: this.chartData.timestamps };
        const ulInterp = { data: smoothedUpload, timestamps: this.chartData.timestamps };

        // Build fill configuration based on style
        let fillConfig;
        if (style.fillOpacity === 0) {
            // Line only - no fill
            fillConfig = {
                type: 'solid',
                opacity: 0
            };
        } else {
            // Area with gradient fill
            fillConfig = {
                type: 'gradient',
                gradient: {
                    shade: isDark ? 'dark' : 'light',
                    type: 'vertical',
                    shadeIntensity: 0.5,
                    opacityFrom: style.fillOpacity,
                    opacityTo: 0.1,
                    stops: [0, 90, 100],
                    colorStops: [
                        [
                            { offset: 0, color: accentColor, opacity: style.fillOpacity },
                            { offset: 100, color: accentColor, opacity: 0.05 }
                        ],
                        [
                            { offset: 0, color: uploadColor, opacity: style.fillOpacity * 0.8 },
                            { offset: 100, color: uploadColor, opacity: 0.05 }
                        ]
                    ]
                }
            };
        }

        return {
            series: [{
                name: 'Download',
                data: dlInterp.data.map((v, i) => ({
                    x: dlInterp.timestamps[i],
                    y: Math.max(0, v) // Ensure non-negative
                }))
            }, {
                name: 'Upload',
                data: ulInterp.data.map((v, i) => ({
                    x: ulInterp.timestamps[i],
                    y: Math.max(0, v) // Ensure non-negative
                }))
            }],
            chart: {
                type: 'area',
                height: this.compact ? 120 : 280,
                stacked: style.stacked || false,
                animations: {
                    enabled: false, // Disable animations for glitch-free real-time updates (like LibreQoS)
                    easing: 'linear',
                    speed: 0,
                    dynamicAnimation: {
                        enabled: false,
                        speed: 0
                    }
                },
                redrawOnParentResize: true,
                redrawOnWindowResize: true,
                toolbar: {
                    show: !this.compact,
                    offsetY: -5,
                    tools: {
                        download: true,
                        selection: false,
                        zoom: true,
                        zoomin: true,
                        zoomout: true,
                        pan: true,
                        reset: true
                    },
                    autoSelected: 'zoom'
                },
                background: 'transparent',
                fontFamily: 'inherit',
                zoom: {
                    enabled: !this.compact
                },
                dropShadow: {
                    enabled: style.fillOpacity > 0.3,
                    top: 3,
                    left: 0,
                    blur: 4,
                    opacity: 0.1
                }
            },
            colors: [accentColor, uploadColor],
            dataLabels: {
                enabled: false
            },
            stroke: {
                curve: 'smooth', // Always use smooth curve for glitch-free display
                width: style.strokeWidth,
                lineCap: 'round',
                dashArray: 0 // Solid line for cleaner appearance
            },
            fill: fillConfig,
            xaxis: {
                type: 'datetime',
                labels: {
                    style: {
                        colors: isDark ? '#9ca3af' : '#6b7280',
                        fontSize: '11px'
                    },
                    datetimeUTC: false,
                    datetimeFormatter: {
                        year: 'yyyy',
                        month: "MMM 'yy",
                        day: 'dd MMM',
                        hour: 'HH:mm',
                        minute: 'HH:mm:ss'
                    }
                },
                axisBorder: {
                    show: false
                },
                axisTicks: {
                    show: false
                },
                crosshairs: {
                    show: true,
                    stroke: {
                        color: isDark ? '#4b5563' : '#d1d5db',
                        width: 1,
                        dashArray: 3
                    }
                }
            },
            yaxis: {
                labels: {
                    style: {
                        colors: isDark ? '#9ca3af' : '#6b7280',
                        fontSize: '11px'
                    },
                    formatter: (value) => this.formatRate(value)
                },
                min: 0
            },
            grid: {
                borderColor: isDark ? 'rgba(75, 85, 99, 0.2)' : 'rgba(209, 213, 219, 0.4)',
                strokeDashArray: 3,
                padding: {
                    left: 10,
                    right: 10,
                    top: 0
                },
                xaxis: {
                    lines: {
                        show: false
                    }
                }
            },
            legend: {
                show: !this.compact,
                position: 'top',
                horizontalAlign: 'right',
                offsetY: 0,
                offsetX: -100,
                labels: {
                    colors: isDark ? '#d1d5db' : '#374151'
                },
                markers: {
                    width: 10,
                    height: 10,
                    radius: 3,
                    offsetX: -3
                },
                itemMargin: {
                    horizontal: 10
                }
            },
            tooltip: {
                theme: isDark ? 'dark' : 'light',
                shared: true,
                intersect: false,
                x: {
                    format: 'HH:mm:ss'
                },
                y: {
                    formatter: (value) => this.formatRate(value)
                },
                marker: {
                    show: true
                },
                style: {
                    fontSize: '12px',
                    fontFamily: 'inherit'
                },
                cssClass: 'bw-apex-tooltip',
                fillSeriesColor: false,
                onDatasetHover: {
                    highlightDataSeries: true
                },
                custom: ({ series, seriesIndex, dataPointIndex, w }) => {
                    const isDarkMode = document.documentElement.getAttribute('data-bs-theme') === 'dark';
                    const bgColor = isDarkMode ? '#1f2937' : 'rgba(107, 114, 128, 0.95)';
                    const textColor = isDarkMode ? '#f3f4f6' : '#ffffff';
                    const borderColor = isDarkMode ? 'rgba(75,85,99,0.6)' : 'rgba(75, 85, 99, 0.5)';
                    const headerBg = isDarkMode ? '#111827' : 'rgba(75, 85, 99, 0.8)';

                    const timestamp = w.globals.seriesX[0][dataPointIndex];
                    const timeStr = new Date(timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                    const downloadVal = series[0] ? this.formatRate(series[0][dataPointIndex]) : '0 bps';
                    const uploadVal = series[1] ? this.formatRate(series[1][dataPointIndex]) : '0 bps';

                    return `<div style="background:${bgColor};border:1px solid ${borderColor};border-radius:6px;box-shadow:0 4px 12px rgba(0,0,0,0.25);overflow:hidden;">
                        <div style="background:${headerBg};padding:6px 10px;border-bottom:1px solid ${borderColor};font-weight:600;color:${textColor};font-size:12px;">${timeStr}</div>
                        <div style="padding:8px 10px;">
                            <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
                                <span style="width:10px;height:10px;background:#10b981;border-radius:2px;"></span>
                                <span style="color:${textColor};font-size:12px;">Download: <strong>${downloadVal}</strong></span>
                            </div>
                            <div style="display:flex;align-items:center;gap:8px;">
                                <span style="width:10px;height:10px;background:#3b82f6;border-radius:2px;"></span>
                                <span style="color:${textColor};font-size:12px;">Upload: <strong>${uploadVal}</strong></span>
                            </div>
                        </div>
                    </div>`;
                }
            },
            markers: {
                size: 0,
                hover: {
                    size: 5,
                    sizeOffset: 3
                }
            }
        };
    }

    // Remove outliers and fill gaps - key to smooth graphs like LibreQoS
    removeOutliersAndFillGaps(data) {
        if (!data || data.length < 3) return data;

        const result = [...data];

        // Calculate median and IQR for outlier detection
        const sorted = [...data].filter(v => v > 0).sort((a, b) => a - b);
        if (sorted.length < 3) return result;

        const q1 = sorted[Math.floor(sorted.length * 0.25)];
        const q3 = sorted[Math.floor(sorted.length * 0.75)];
        const iqr = q3 - q1;
        const lowerBound = Math.max(0, q1 - 1.5 * iqr);
        const upperBound = q3 + 2.5 * iqr; // More lenient upper bound for bandwidth spikes

        // Calculate rolling average for gap filling
        const windowSize = 5;

        for (let i = 0; i < result.length; i++) {
            const val = result[i];

            // Detect outliers: sudden drops to 0 or extreme values
            const isOutlier = val === 0 || val < lowerBound || val > upperBound;

            // Also check for sudden changes (more than 90% drop from previous)
            const prevVal = i > 0 ? result[i - 1] : val;
            const isSuddenDrop = prevVal > 0 && val < prevVal * 0.1 && i > 0;

            if (isOutlier || isSuddenDrop) {
                // Fill with interpolated value from neighbors
                let sum = 0;
                let count = 0;

                // Look at surrounding non-outlier values
                for (let j = Math.max(0, i - windowSize); j < Math.min(result.length, i + windowSize); j++) {
                    if (j !== i && data[j] > lowerBound && data[j] < upperBound) {
                        sum += data[j];
                        count++;
                    }
                }

                if (count > 0) {
                    result[i] = sum / count;
                } else if (i > 0) {
                    result[i] = result[i - 1]; // Use previous value
                }
            }
        }

        return result;
    }

    // Smooth data using exponential moving average for flowing water effect
    smoothData(data, alpha = 0.3) {
        if (!data || data.length < 2) return data;

        // First, remove outliers and fill gaps (critical for glitch-free graphs)
        const cleaned = this.removeOutliersAndFillGaps(data);

        const smoothed = [cleaned[0]];

        // Apply exponential moving average for natural flow
        for (let i = 1; i < cleaned.length; i++) {
            // EMA: smoothed[i] = alpha * data[i] + (1 - alpha) * smoothed[i-1]
            smoothed.push(alpha * cleaned[i] + (1 - alpha) * smoothed[i - 1]);
        }

        // Apply a second pass for extra smoothness (like LibreQoS flowing graph)
        const doubleSmoothed = [smoothed[0]];
        for (let i = 1; i < smoothed.length; i++) {
            doubleSmoothed.push(alpha * smoothed[i] + (1 - alpha) * doubleSmoothed[i - 1]);
        }

        // Third pass with lower alpha for ultra-smooth output
        const tripleSmoothed = [doubleSmoothed[0]];
        const finalAlpha = alpha * 0.7;
        for (let i = 1; i < doubleSmoothed.length; i++) {
            tripleSmoothed.push(finalAlpha * doubleSmoothed[i] + (1 - finalAlpha) * tripleSmoothed[i - 1]);
        }

        return tripleSmoothed;
    }

    // Interpolate data points for ultra-smooth curves (spline-like)
    interpolateData(data, timestamps, factor = 2) {
        if (!data || data.length < 3 || factor <= 1) {
            return { data, timestamps };
        }

        const newData = [];
        const newTimestamps = [];

        for (let i = 0; i < data.length - 1; i++) {
            newData.push(data[i]);
            newTimestamps.push(timestamps[i]);

            // Add interpolated points between
            const timeDiff = timestamps[i + 1] - timestamps[i];
            const valueDiff = data[i + 1] - data[i];

            for (let j = 1; j < factor; j++) {
                const t = j / factor;
                // Use smooth cubic interpolation
                const smoothT = t * t * (3 - 2 * t); // Smoothstep function
                newData.push(data[i] + valueDiff * smoothT);
                newTimestamps.push(timestamps[i] + timeDiff * t);
            }
        }

        // Add last point
        newData.push(data[data.length - 1]);
        newTimestamps.push(timestamps[timestamps.length - 1]);

        return { data: newData, timestamps: newTimestamps };
    }

    // Update chart with new style
    updateChartStyle() {
        if (this.chart) {
            this.chart.updateOptions(this.getChartOptions(), true, true);
        }
    }

    initChart() {
        const chartEl = document.getElementById(`${this.containerId}-chart`);
        if (!chartEl) return;

        this.chart = new ApexCharts(chartEl, this.getChartOptions());
        this.chart.render();
    }

    initGauge() {
        // Render custom SVG speedometer gauges
        this.renderSpeedometer('download', 0);
        this.renderSpeedometer('upload', 0);
    }

    renderSpeedometer(type, percent) {
        const containerId = type === 'download' ?
            `${this.containerId}-speedometer-dl` :
            `${this.containerId}-speedometer-ul`;

        const container = document.getElementById(containerId);
        if (!container) return;

        const isDark = document.documentElement.getAttribute('data-bs-theme') === 'dark';

        // SVG parameters
        const size = 180;
        const strokeWidth = 12;
        const radius = (size - strokeWidth) / 2;
        const center = size / 2;

        // Arc parameters (270 degrees, from -225 to 45)
        const startAngle = -225;
        const endAngle = 45;
        const totalAngle = endAngle - startAngle; // 270 degrees

        // Calculate arc path
        const polarToCartesian = (cx, cy, r, angle) => {
            const rad = (angle * Math.PI) / 180;
            return {
                x: cx + r * Math.cos(rad),
                y: cy + r * Math.sin(rad)
            };
        };

        const describeArc = (cx, cy, r, start, end) => {
            const startPoint = polarToCartesian(cx, cy, r, start);
            const endPoint = polarToCartesian(cx, cy, r, end);
            const largeArc = end - start <= 180 ? 0 : 1;
            return `M ${startPoint.x} ${startPoint.y} A ${r} ${r} 0 ${largeArc} 1 ${endPoint.x} ${endPoint.y}`;
        };

        // Progress angle based on percent
        const progressAngle = startAngle + (totalAngle * Math.min(100, Math.max(0, percent)) / 100);

        // Colors based on type
        const gradientId = type === 'download' ? 'downloadGradient' : 'uploadGradient';
        const color1 = type === 'download' ? '#60a5fa' : '#34d399';
        const color2 = type === 'download' ? '#3b82f6' : '#10b981';
        const color3 = type === 'download' ? '#1d4ed8' : '#059669';

        // Track color
        const trackColor = isDark ? 'rgba(75, 85, 99, 0.3)' : 'rgba(203, 213, 225, 0.5)';

        // Generate tick marks
        let tickMarks = '';
        const numTicks = 27; // Every 10 degrees
        const tickInnerRadius = radius - strokeWidth / 2 - 8;
        const tickOuterRadius = radius - strokeWidth / 2 - 2;
        const majorTickOuterRadius = radius - strokeWidth / 2 + 2;

        for (let i = 0; i <= numTicks; i++) {
            const angle = startAngle + (totalAngle * i / numTicks);
            const isMajor = i % 5 === 0; // Major tick every 50%
            const inner = polarToCartesian(center, center, tickInnerRadius, angle);
            const outer = polarToCartesian(center, center, isMajor ? majorTickOuterRadius : tickOuterRadius, angle);
            const tickClass = isMajor ? 'tick major' : 'tick';
            tickMarks += `<line class="${tickClass}" x1="${inner.x}" y1="${inner.y}" x2="${outer.x}" y2="${outer.y}" />`;
        }

        // Create SVG
        container.innerHTML = `
            <svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}">
                <defs>
                    <linearGradient id="${gradientId}" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stop-color="${color1}" />
                        <stop offset="50%" stop-color="${color2}" />
                        <stop offset="100%" stop-color="${color3}" />
                    </linearGradient>
                    <filter id="glow-${type}" x="-50%" y="-50%" width="200%" height="200%">
                        <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                        <feMerge>
                            <feMergeNode in="coloredBlur"/>
                            <feMergeNode in="SourceGraphic"/>
                        </feMerge>
                    </filter>
                </defs>

                <!-- Tick marks -->
                <g class="ticks">${tickMarks}</g>

                <!-- Track (background) -->
                <path class="track"
                      d="${describeArc(center, center, radius, startAngle, endAngle)}"
                      stroke="${trackColor}"
                      stroke-width="${strokeWidth}"
                      fill="none"
                      stroke-linecap="round" />

                <!-- Progress arc with glow -->
                <path class="progress ${type}"
                      id="${containerId}-progress"
                      d="${describeArc(center, center, radius, startAngle, progressAngle)}"
                      stroke="url(#${gradientId})"
                      stroke-width="${strokeWidth}"
                      fill="none"
                      stroke-linecap="round"
                      filter="url(#glow-${type})" />
            </svg>
        `;
    }

    updateSpeedometer(type, percent) {
        const containerId = type === 'download' ?
            `${this.containerId}-speedometer-dl` :
            `${this.containerId}-speedometer-ul`;

        const progressPath = document.getElementById(`${containerId}-progress`);
        if (!progressPath) {
            // If progress element doesn't exist, re-render the whole gauge
            this.renderSpeedometer(type, percent);
            return;
        }

        // Re-render with new percent (simple approach for clean animation)
        this.renderSpeedometer(type, percent);
    }

    updateChartTheme() {
        if (this.chart) {
            this.chart.updateOptions(this.getChartOptions());
        }
    }

    async loadData() {
        try {
            this.setStatus('connecting', 'Loading...');

            const response = await fetch(`/bandwidth/api/history/${this.accountNo}?period=${this.currentPeriod}`);

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const result = await response.json();

            if (result.ok && result.data && result.data.length > 0) {
                // Extract raw data
                let rawDownload = result.data.map(d => d.download_rate || 0);
                let rawUpload = result.data.map(d => d.upload_rate || 0);

                // Pre-process historical data to remove obvious glitches
                // (sudden drops to 0 in the middle of traffic)
                for (let i = 1; i < rawDownload.length - 1; i++) {
                    const prev = rawDownload[i - 1];
                    const curr = rawDownload[i];
                    const next = rawDownload[i + 1];

                    // If current is near 0 but neighbors are high, it's likely a measurement gap
                    if (curr < prev * 0.1 && curr < next * 0.1 && prev > 1000000 && next > 1000000) {
                        rawDownload[i] = (prev + next) / 2; // Interpolate
                    }
                }

                for (let i = 1; i < rawUpload.length - 1; i++) {
                    const prev = rawUpload[i - 1];
                    const curr = rawUpload[i];
                    const next = rawUpload[i + 1];

                    if (curr < prev * 0.1 && curr < next * 0.1 && prev > 1000000 && next > 1000000) {
                        rawUpload[i] = (prev + next) / 2;
                    }
                }

                this.chartData.download = rawDownload;
                this.chartData.upload = rawUpload;
                this.chartData.timestamps = result.data.map(d => d.timestamp * 1000);

                this.updateChart();
                this.setStatus('connected', 'Live');
            } else {
                // No data yet - try to fetch live data
                await this.fetchLive();
                this.setStatus('connected', 'Waiting for data...');
            }

            // Load summary
            if (this.showSummary && !this.compact) {
                this.loadSummary();
            }
        } catch (error) {
            console.error('Failed to load bandwidth data:', error);
            this.setStatus('error', 'Unable to connect');
            // Show helpful message
            this.showNoDataMessage();
        }
    }

    showNoDataMessage() {
        const container = document.getElementById(this.containerId);
        if (!container) return;

        const msgDiv = container.querySelector('.bw-no-data-msg');
        if (msgDiv) return; // Already shown

        const chartContainer = container.querySelector('.bw-chart-container');
        if (chartContainer) {
            const msg = document.createElement('div');
            msg.className = 'bw-no-data-msg text-center py-3';
            msg.innerHTML = `
                <i class="bi bi-bar-chart-line text-muted" style="font-size: 2rem;"></i>
                <div class="text-muted mt-2">Collecting bandwidth data...</div>
                <div class="small text-muted">Data will appear when queue activity is detected</div>
            `;
            chartContainer.insertBefore(msg, chartContainer.firstChild);
        }
    }

    hideNoDataMessage() {
        const container = document.getElementById(this.containerId);
        if (!container) return;

        const msgDiv = container.querySelector('.bw-no-data-msg');
        if (msgDiv) msgDiv.remove();
    }

    async loadSummary() {
        try {
            const response = await fetch(`/bandwidth/api/summary/${this.accountNo}`);
            const result = await response.json();

            if (result.ok && result.summary) {
                const todayEl = document.getElementById(`${this.containerId}-today`);
                const weekEl = document.getElementById(`${this.containerId}-week`);
                const monthEl = document.getElementById(`${this.containerId}-month`);

                if (todayEl) todayEl.textContent = result.summary.today.total_formatted;
                if (weekEl) weekEl.textContent = result.summary.week.total_formatted;
                if (monthEl) monthEl.textContent = result.summary.month.total_formatted;
            }
        } catch (error) {
            console.error('Failed to load summary:', error);
        }
    }

    async fetchLive() {
        try {
            const response = await fetch(`/bandwidth/api/live/${this.accountNo}`);
            const result = await response.json();

            if (result.ok) {
                this.hideNoDataMessage();
                this.updateLiveData(result.download_rate, result.upload_rate);
                this.setStatus('connected', 'Live');
            }
        } catch (error) {
            console.error('Failed to fetch live data:', error);
        }
    }

    updateLiveData(downloadRate, uploadRate) {
        const now = Date.now();

        // Validate incoming data - ignore obvious bad values
        // (negative values or impossibly large spikes)
        const lastDl = this.chartData.download.length > 0 ?
            this.chartData.download[this.chartData.download.length - 1] : 0;
        const lastUl = this.chartData.upload.length > 0 ?
            this.chartData.upload[this.chartData.upload.length - 1] : 0;

        // Clamp extreme values - prevent sudden spikes that cause glitches
        let validatedDl = Math.max(0, downloadRate);
        let validatedUl = Math.max(0, uploadRate);

        // If the new value is a sudden drop to near-zero but previous was high,
        // use a gradual decay instead (like LibreQoS does)
        if (lastDl > 1000000 && validatedDl < lastDl * 0.05) {
            validatedDl = lastDl * 0.7; // Gradual decay
        }
        if (lastUl > 1000000 && validatedUl < lastUl * 0.05) {
            validatedUl = lastUl * 0.7; // Gradual decay
        }

        // Add new data point
        this.chartData.download.push(validatedDl);
        this.chartData.upload.push(validatedUl);
        this.chartData.timestamps.push(now);

        // Keep only maxDataPoints (ring buffer pattern like LibreQoS)
        while (this.chartData.download.length > this.maxDataPoints) {
            this.chartData.download.shift();
            this.chartData.upload.shift();
            this.chartData.timestamps.shift();
        }

        // Update chart
        this.updateChart();

        // Update gauges with actual values (not smoothed)
        this.updateGauges(downloadRate, uploadRate);

        // Update compact display
        this.updateCompactDisplay(downloadRate, uploadRate);

        this.setStatus('connected', 'Live');
    }

    updateChart() {
        if (!this.chart) return;

        // Apply smoothing for flowing water effect (matching getChartOptions settings)
        const smoothedDownload = this.smoothData(this.chartData.download, 0.15);
        const smoothedUpload = this.smoothData(this.chartData.upload, 0.15);

        // Direct update without interpolation for cleaner real-time display
        this.chart.updateSeries([{
            name: 'Download',
            data: smoothedDownload.map((v, i) => ({
                x: this.chartData.timestamps[i],
                y: Math.max(0, v)
            }))
        }, {
            name: 'Upload',
            data: smoothedUpload.map((v, i) => ({
                x: this.chartData.timestamps[i],
                y: Math.max(0, v)
            }))
        }], false); // false = don't animate the update
    }

    updateGauges(downloadRate, uploadRate) {
        // Update download speedometer
        const dlPercent = Math.min(100, (downloadRate / this.planSpeed.download) * 100);
        this.updateSpeedometer('download', dlPercent);

        const dlValueEl = document.getElementById(`${this.containerId}-dl-value`);
        const dlUnitEl = document.getElementById(`${this.containerId}-dl-unit`);
        if (dlValueEl) {
            const formatted = this.formatRateSplit(downloadRate);
            dlValueEl.textContent = formatted.value;
            if (dlUnitEl) dlUnitEl.textContent = formatted.unit;
        }

        // Update upload speedometer
        const ulPercent = Math.min(100, (uploadRate / this.planSpeed.upload) * 100);
        this.updateSpeedometer('upload', ulPercent);

        const ulValueEl = document.getElementById(`${this.containerId}-ul-value`);
        const ulUnitEl = document.getElementById(`${this.containerId}-ul-unit`);
        if (ulValueEl) {
            const formatted = this.formatRateSplit(uploadRate);
            ulValueEl.textContent = formatted.value;
            if (ulUnitEl) ulUnitEl.textContent = formatted.unit;
        }
    }

    // Format rate and return value/unit separately
    formatRateSplit(bps) {
        if (bps >= 1000000000) {
            return { value: (bps / 1000000000).toFixed(1), unit: 'Gbps' };
        } else if (bps >= 1000000) {
            return { value: (bps / 1000000).toFixed(1), unit: 'Mbps' };
        } else if (bps >= 1000) {
            return { value: (bps / 1000).toFixed(0), unit: 'Kbps' };
        }
        return { value: String(Math.round(bps)), unit: 'bps' };
    }

    updateCompactDisplay(downloadRate, uploadRate) {
        const dlCompact = document.getElementById(`${this.containerId}-dl-compact`);
        const ulCompact = document.getElementById(`${this.containerId}-ul-compact`);

        if (dlCompact) dlCompact.textContent = this.formatRate(downloadRate);
        if (ulCompact) ulCompact.textContent = this.formatRate(uploadRate);
    }

    startLiveUpdates() {
        // Only do polling if we're in a short time period view
        if (['1m', '5m', '10m', '30m'].includes(this.currentPeriod)) {
            this.updateTimer = setInterval(() => {
                if (!this.socketConnected) {
                    this.fetchLive();
                }
            }, this.updateInterval);
        }
    }

    stopLiveUpdates() {
        if (this.updateTimer) {
            clearInterval(this.updateTimer);
            this.updateTimer = null;
        }
    }

    initSocketIO() {
        // Try to connect to SocketIO for real-time updates
        if (typeof io !== 'undefined') {
            try {
                const socket = io({
                    path: '/socket.io/',
                    transports: ['websocket', 'polling']
                });

                socket.on('connect', () => {
                    this.socketConnected = true;
                    socket.emit('subscribe_bandwidth', { account_no: this.accountNo });
                    this.setStatus('connected', 'Live (WebSocket)');
                });

                socket.on('disconnect', () => {
                    this.socketConnected = false;
                    this.setStatus('disconnected', 'Reconnecting...');
                });

                socket.on('bandwidth_update', (data) => {
                    if (data.account_no === this.accountNo) {
                        this.updateLiveData(data.download_rate, data.upload_rate);
                    }
                });

                this.socket = socket;
            } catch (e) {
                console.warn('SocketIO not available, using polling');
            }
        }
    }

    setStatus(status, text) {
        const indicator = document.getElementById(`${this.containerId}-status`);
        const textEl = document.getElementById(`${this.containerId}-status-text`);

        if (indicator) {
            indicator.className = `bw-status-indicator bw-status-${status}`;
        }
        if (textEl) {
            textEl.textContent = text;
        }
    }

    formatRate(bps) {
        if (bps >= 1000000000) {
            return `${(bps / 1000000000).toFixed(2)} Gbps`;
        } else if (bps >= 1000000) {
            return `${(bps / 1000000).toFixed(1)} Mbps`;
        } else if (bps >= 1000) {
            return `${(bps / 1000).toFixed(1)} Kbps`;
        }
        return `${bps} bps`;
    }

    adjustColorBrightness(hex, percent) {
        // Adjust color brightness by percentage (-100 to 100)
        try {
            hex = hex.replace(/^#/, '');
            if (hex.length === 3) {
                hex = hex.split('').map(c => c + c).join('');
            }

            const num = parseInt(hex, 16);
            let r = (num >> 16) + percent;
            let g = ((num >> 8) & 0x00FF) + percent;
            let b = (num & 0x0000FF) + percent;

            r = Math.min(255, Math.max(0, r));
            g = Math.min(255, Math.max(0, g));
            b = Math.min(255, Math.max(0, b));

            return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
        } catch (e) {
            return hex;
        }
    }

    destroy() {
        this.stopLiveUpdates();

        if (this.socket) {
            this.socket.emit('unsubscribe_bandwidth', { account_no: this.accountNo });
            this.socket.disconnect();
        }

        if (this.chart) {
            this.chart.destroy();
        }

        // Clear speedometer containers
        const dlSpeedometer = document.getElementById(`${this.containerId}-speedometer-dl`);
        const ulSpeedometer = document.getElementById(`${this.containerId}-speedometer-ul`);
        if (dlSpeedometer) dlSpeedometer.innerHTML = '';
        if (ulSpeedometer) ulSpeedometer.innerHTML = '';
    }
}

// Export for use
window.BandwidthWidget = BandwidthWidget;
