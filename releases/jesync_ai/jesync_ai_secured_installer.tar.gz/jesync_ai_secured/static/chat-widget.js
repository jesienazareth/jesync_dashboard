/**
 * JeSync AI Chat Widget — Embeddable customer support chatbot
 * Usage: <script src="http://AI_SERVER:5050/static/chat-widget.js"
 *               data-api-url="http://AI_SERVER:5050"
 *               data-api-secret="your-secret"
 *               data-prechat="true"
 *               data-prechat-account="true"
 *               data-prechat-name="true"
 *               data-prechat-contact="true"
 *               data-prechat-guest="true"
 *               data-validate-url="/api/widget/validate_account"></script>
 */
(function() {
    'use strict';

    // Configuration from script tag attributes
    // Use fallback lookup for async-loaded scripts where currentScript may be null
    const scriptTag = document.currentScript || document.querySelector('script[data-api-url]');
    const API_URL = scriptTag?.getAttribute('data-api-url') || 'http://172.16.100.6:5050';
    const API_SECRET = scriptTag?.getAttribute('data-api-secret') || '';
    const POSITION = scriptTag?.getAttribute('data-position') || 'bottom-right';
    const TITLE = scriptTag?.getAttribute('data-title') || 'JeSync Support';
    const PRECHAT_ENABLED = scriptTag?.getAttribute('data-prechat') === 'true';
    const PRECHAT_ACCOUNT = scriptTag?.getAttribute('data-prechat-account') === 'true';
    const PRECHAT_NAME = scriptTag?.getAttribute('data-prechat-name') === 'true';
    const PRECHAT_CONTACT = scriptTag?.getAttribute('data-prechat-contact') === 'true';
    const PRECHAT_GUEST = scriptTag?.getAttribute('data-prechat-guest') === 'true';
    const VALIDATE_URL = scriptTag?.getAttribute('data-validate-url') || '/api/widget/validate_account';

    // Session management
    let sessionId = localStorage.getItem('jesync_ai_session') || generateId();
    localStorage.setItem('jesync_ai_session', sessionId);

    // Customer info from pre-chat form or URL params
    let customerInfo = JSON.parse(localStorage.getItem('jesync_ai_customer') || 'null');
    let userId = customerInfo?.account || localStorage.getItem('jesync_ai_user') || 'guest_' + generateId().slice(0, 8);

    let isOpen = false;
    let isLoading = false;
    let aiStatus = 'checking';
    let prechatCompleted = !PRECHAT_ENABLED || !!customerInfo;
    let historyLoaded = false;
    let quickResponses = []; // Auto-responses loaded from server
    let lastMessageCount = 0; // Track message count for polling
    let pollInterval = null; // Polling interval reference
    let awaitingAdmin = false; // True when admin has taken over

    function generateId() {
        return 'xxxx-xxxx-xxxx'.replace(/x/g, () => Math.floor(Math.random() * 16).toString(16));
    }

    // Inject styles - Futuristic Professional Design with Light/Dark Mode
    const style = document.createElement('style');
    style.textContent = `
        /* ===== CSS Variables for Light/Dark Mode ===== */
        :root {
            --jc-primary: #2563eb;
            --jc-primary-dark: #1d4ed8;
            --jc-primary-light: #3b82f6;
            --jc-accent: #8b5cf6;
            --jc-success: #22c55e;
            --jc-error: #ef4444;
            --jc-bg-panel: #ffffff;
            --jc-bg-messages: #f8fafc;
            --jc-bg-input: #ffffff;
            --jc-bg-msg-ai: #ffffff;
            --jc-bg-msg-system: #eff6ff;
            --jc-text-primary: #1e293b;
            --jc-text-secondary: #64748b;
            --jc-text-muted: #94a3b8;
            --jc-border: #e2e8f0;
            --jc-border-light: #f1f5f9;
            --jc-shadow: rgba(0,0,0,0.1);
            --jc-shadow-lg: rgba(0,0,0,0.15);
            --jc-glass: rgba(255,255,255,0.8);
            --jc-input-bg: #f8fafc;
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --jc-bg-panel: #0f172a;
                --jc-bg-messages: #1e293b;
                --jc-bg-input: #0f172a;
                --jc-bg-msg-ai: #1e293b;
                --jc-bg-msg-system: #1e3a5f;
                --jc-text-primary: #f1f5f9;
                --jc-text-secondary: #94a3b8;
                --jc-text-muted: #64748b;
                --jc-border: #334155;
                --jc-border-light: #1e293b;
                --jc-shadow: rgba(0,0,0,0.4);
                --jc-shadow-lg: rgba(0,0,0,0.5);
                --jc-glass: rgba(15,23,42,0.9);
                --jc-input-bg: #1e293b;
            }
        }

        /* ===== Main Widget Container ===== */
        #jesync-chat-widget {
            position: fixed !important;
            bottom: 20px !important;
            right: 20px !important;
            left: auto !important;
            top: auto !important;
            z-index: 2147483647 !important;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            -webkit-transform: translateZ(0);
            transform: translateZ(0);
            pointer-events: auto !important;
            visibility: visible !important;
            opacity: 1 !important;
        }

        /* ===== Floating Bubble Button ===== */
        #jesync-chat-bubble {
            width: 64px !important;
            height: 64px !important;
            min-width: 64px !important;
            min-height: 64px !important;
            border-radius: 50% !important;
            background: linear-gradient(135deg, var(--jc-primary) 0%, var(--jc-accent) 100%) !important;
            color: white !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            cursor: pointer !important;
            box-shadow: 0 8px 32px rgba(37,99,235,0.4), 0 0 0 0 rgba(37,99,235,0.4);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: none !important;
            outline: none !important;
            position: relative;
            overflow: hidden;
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
            -webkit-appearance: none;
            appearance: none;
        }
        #jesync-chat-bubble::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(135deg, rgba(255,255,255,0.2) 0%, transparent 50%);
            border-radius: 50%;
        }
        #jesync-chat-bubble:hover {
            transform: scale(1.1) translateY(-2px);
            box-shadow: 0 12px 40px rgba(37,99,235,0.5), 0 0 0 8px rgba(37,99,235,0.1);
        }
        #jesync-chat-bubble:active {
            transform: scale(1.05);
        }
        #jesync-chat-bubble svg {
            width: 28px;
            height: 28px;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
        }
        /* Pulse animation */
        @keyframes jesyncPulse {
            0%, 100% { box-shadow: 0 8px 32px rgba(37,99,235,0.4), 0 0 0 0 rgba(37,99,235,0.4); }
            50% { box-shadow: 0 8px 32px rgba(37,99,235,0.4), 0 0 0 12px rgba(37,99,235,0); }
        }
        #jesync-chat-bubble.pulse {
            animation: jesyncPulse 2s infinite;
        }

        /* ===== Chat Panel ===== */
        #jesync-chat-panel {
            display: none;
            width: 400px;
            height: 600px;
            background: var(--jc-bg-panel);
            border-radius: 24px;
            box-shadow: 0 25px 80px var(--jc-shadow-lg), 0 0 0 1px var(--jc-border);
            position: absolute;
            bottom: 80px;
            right: 0;
            flex-direction: column;
            overflow: hidden;
            animation: jesyncSlideUp 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            backdrop-filter: blur(20px);
        }
        #jesync-chat-panel.open {
            display: flex;
        }
        @keyframes jesyncSlideUp {
            from { opacity: 0; transform: translateY(20px) scale(0.95); }
            to { opacity: 1; transform: translateY(0) scale(1); }
        }

        /* ===== Header ===== */
        .jesync-chat-header {
            background: linear-gradient(135deg, var(--jc-primary) 0%, var(--jc-accent) 100%);
            color: white;
            padding: 20px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            overflow: hidden;
        }
        .jesync-chat-header::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 200px;
            height: 200px;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
        }
        .jesync-chat-header-info {
            display: flex;
            align-items: center;
            gap: 12px;
            position: relative;
            z-index: 1;
        }
        .jesync-chat-header-info .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: var(--jc-success);
            box-shadow: 0 0 12px var(--jc-success);
            animation: jesyncGlow 2s ease-in-out infinite;
        }
        @keyframes jesyncGlow {
            0%, 100% { box-shadow: 0 0 8px var(--jc-success); }
            50% { box-shadow: 0 0 16px var(--jc-success), 0 0 24px var(--jc-success); }
        }
        .jesync-chat-header-info .status-dot.offline {
            background: var(--jc-error);
            box-shadow: 0 0 12px var(--jc-error);
            animation: none;
        }
        .jesync-chat-header h3 {
            margin: 0;
            font-size: 17px;
            font-weight: 700;
            letter-spacing: -0.3px;
        }
        .jesync-chat-header small {
            opacity: 0.9;
            font-size: 12px;
            font-weight: 500;
        }
        .jesync-chat-close {
            background: rgba(255,255,255,0.15);
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            padding: 8px 12px;
            border-radius: 12px;
            transition: all 0.2s;
            position: relative;
            z-index: 1;
        }
        .jesync-chat-close:hover {
            background: rgba(255,255,255,0.25);
            transform: scale(1.05);
        }

        /* ===== Messages Area ===== */
        .jesync-chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            background: var(--jc-bg-messages);
            display: flex;
            flex-direction: column;
            gap: 16px;
            scroll-behavior: smooth;
        }
        .jesync-chat-messages::-webkit-scrollbar {
            width: 6px;
        }
        .jesync-chat-messages::-webkit-scrollbar-track {
            background: transparent;
        }
        .jesync-chat-messages::-webkit-scrollbar-thumb {
            background: var(--jc-border);
            border-radius: 3px;
        }

        /* ===== Message Bubbles ===== */
        .jesync-msg {
            max-width: 85%;
            padding: 14px 18px;
            border-radius: 20px;
            font-size: 14px;
            line-height: 1.6;
            word-wrap: break-word;
            animation: jesyncFadeIn 0.3s ease;
            position: relative;
        }
        @keyframes jesyncFadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .jesync-msg.user {
            align-self: flex-end;
            background: linear-gradient(135deg, var(--jc-primary) 0%, var(--jc-primary-dark) 100%);
            color: white;
            border-bottom-right-radius: 6px;
            box-shadow: 0 4px 15px rgba(37,99,235,0.3);
        }
        .jesync-msg.assistant {
            align-self: flex-start;
            background: var(--jc-bg-msg-ai);
            color: var(--jc-text-primary);
            border-bottom-left-radius: 6px;
            box-shadow: 0 2px 12px var(--jc-shadow);
            border: 1px solid var(--jc-border-light);
        }
        .jesync-msg.system {
            align-self: center;
            background: var(--jc-bg-msg-system);
            color: var(--jc-primary);
            font-size: 12px;
            border-radius: 12px;
            padding: 10px 16px;
            font-weight: 500;
        }
        .jesync-msg.error {
            align-self: center;
            background: #fef2f2;
            color: var(--jc-error);
            font-size: 12px;
            border-radius: 12px;
            padding: 10px 16px;
            font-weight: 500;
        }

        /* ===== Feedback Buttons ===== */
        .jesync-msg-feedback {
            display: flex;
            gap: 8px;
            margin-top: 10px;
        }
        .jesync-msg-feedback button {
            background: var(--jc-bg-messages);
            border: 1px solid var(--jc-border);
            border-radius: 8px;
            padding: 4px 10px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
            color: var(--jc-text-secondary);
        }
        .jesync-msg-feedback button:hover {
            background: var(--jc-border-light);
            transform: scale(1.05);
        }
        .jesync-msg-feedback button.selected {
            background: var(--jc-primary);
            border-color: var(--jc-primary);
            color: white;
        }

        /* ===== Typing Indicator ===== */
        .jesync-typing {
            display: none;
            align-self: flex-start;
            background: var(--jc-bg-msg-ai);
            padding: 16px 20px;
            border-radius: 20px;
            border-bottom-left-radius: 6px;
            box-shadow: 0 2px 12px var(--jc-shadow);
        }
        .jesync-typing.show {
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .jesync-typing span {
            display: inline-block;
            width: 10px;
            height: 10px;
            background: linear-gradient(135deg, var(--jc-primary), var(--jc-accent));
            border-radius: 50%;
            animation: jesyncBounce 1.4s infinite;
        }
        .jesync-typing span:nth-child(2) { animation-delay: 0.2s; }
        .jesync-typing span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes jesyncBounce {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-8px); }
        }

        /* ===== Quick Response Bar ===== */
        .jesync-quick-bar-wrapper {
            position: relative;
            border-top: 1px solid var(--jc-border-light);
        }
        .jesync-quick-toggle {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            width: 100%;
            padding: 10px 16px;
            background: linear-gradient(180deg, var(--jc-bg-messages) 0%, var(--jc-bg-input) 100%);
            border: none;
            color: var(--jc-primary);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        }
        .jesync-quick-toggle:hover {
            background: var(--jc-border-light);
        }
        .jesync-quick-toggle svg {
            width: 16px;
            height: 16px;
            transition: transform 0.2s;
        }
        .jesync-quick-toggle.expanded svg {
            transform: rotate(180deg);
        }
        .jesync-quick-bar {
            display: none;
            flex-wrap: wrap;
            gap: 8px;
            padding: 12px 16px;
            background: linear-gradient(180deg, var(--jc-bg-messages) 0%, var(--jc-bg-input) 100%);
            justify-content: center;
            max-height: 150px;
            overflow-y: auto;
        }
        .jesync-quick-bar.show {
            display: flex;
        }
        .jesync-quick-bar:empty {
            display: none !important;
        }
        .jesync-quick-btn {
            background: linear-gradient(135deg, var(--jc-bg-panel), var(--jc-bg-messages));
            border: 1px solid var(--jc-primary);
            color: var(--jc-primary);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            white-space: nowrap;
        }
        .jesync-quick-btn:hover {
            background: var(--jc-primary);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(37,99,235,0.3);
        }
        .jesync-quick-btn:active {
            transform: translateY(0);
        }

        /* ===== Input Area ===== */
        .jesync-chat-input-area {
            padding: 16px 20px;
            background: var(--jc-bg-input);
            border-top: 1px solid var(--jc-border-light);
            display: flex;
            gap: 12px;
            align-items: center;
        }
        .jesync-chat-input-area input {
            flex: 1;
            padding: 14px 20px;
            border: 2px solid var(--jc-border);
            border-radius: 28px;
            font-size: 14px;
            outline: none;
            transition: all 0.2s;
            background: var(--jc-input-bg);
            color: var(--jc-text-primary);
        }
        .jesync-chat-input-area input::placeholder {
            color: var(--jc-text-muted);
        }
        .jesync-chat-input-area input:focus {
            border-color: var(--jc-primary);
            box-shadow: 0 0 0 4px rgba(37,99,235,0.1);
        }
        .jesync-chat-input-area button {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--jc-primary) 0%, var(--jc-accent) 100%);
            color: white;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            box-shadow: 0 4px 15px rgba(37,99,235,0.3);
        }
        .jesync-chat-input-area button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 20px rgba(37,99,235,0.4);
        }
        .jesync-chat-input-area button:disabled {
            background: var(--jc-border);
            cursor: not-allowed;
            box-shadow: none;
            transform: none;
        }

        /* ===== Pre-chat Form ===== */
        .jesync-prechat {
            flex: 1;
            padding: 24px;
            background: var(--jc-bg-messages);
            display: flex;
            flex-direction: column;
            gap: 16px;
            overflow-y: auto;
        }
        .jesync-prechat h4 {
            margin: 0;
            font-size: 18px;
            font-weight: 700;
            color: var(--jc-text-primary);
            text-align: center;
        }
        .jesync-prechat p {
            margin: 0;
            font-size: 14px;
            color: var(--jc-text-secondary);
            text-align: center;
        }
        .jesync-prechat-field {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .jesync-prechat-field label {
            font-size: 12px;
            font-weight: 700;
            color: var(--jc-text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .jesync-prechat-field input {
            padding: 14px 16px;
            border: 2px solid var(--jc-border);
            border-radius: 12px;
            font-size: 14px;
            outline: none;
            transition: all 0.2s;
            background: var(--jc-bg-panel);
            color: var(--jc-text-primary);
        }
        .jesync-prechat-field input:focus {
            border-color: var(--jc-primary);
            box-shadow: 0 0 0 4px rgba(37,99,235,0.1);
        }
        .jesync-prechat-field input.error {
            border-color: var(--jc-error);
        }
        .jesync-prechat-field .field-error {
            font-size: 12px;
            color: var(--jc-error);
            font-weight: 500;
            display: none;
        }
        .jesync-prechat-field .field-error.show {
            display: block;
        }
        .jesync-prechat-field .field-success {
            font-size: 12px;
            color: var(--jc-success);
            font-weight: 500;
            display: none;
        }
        .jesync-prechat-field .field-success.show {
            display: block;
        }
        .jesync-prechat-btn {
            padding: 16px;
            background: linear-gradient(135deg, var(--jc-primary) 0%, var(--jc-accent) 100%);
            color: white;
            border: none;
            border-radius: 14px;
            font-size: 15px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 8px;
            box-shadow: 0 4px 15px rgba(37,99,235,0.3);
        }
        .jesync-prechat-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(37,99,235,0.4);
        }
        .jesync-prechat-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        .jesync-guest-link {
            text-align: center;
            font-size: 13px;
            color: var(--jc-text-secondary);
        }
        .jesync-guest-link a {
            color: var(--jc-primary);
            text-decoration: none;
            cursor: pointer;
            font-weight: 600;
        }
        .jesync-guest-link a:hover {
            text-decoration: underline;
        }
        .jesync-prechat-spinner {
            display: inline-block;
            width: 18px;
            height: 18px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: jesyncSpin 0.8s linear infinite;
            margin-right: 8px;
            vertical-align: middle;
        }
        @keyframes jesyncSpin {
            to { transform: rotate(360deg); }
        }

        /* ===== Welcome Message ===== */
        .jesync-welcome {
            text-align: center;
            padding: 30px 20px;
        }
        .jesync-welcome h4 {
            margin: 0 0 10px;
            color: var(--jc-text-primary);
            font-size: 18px;
            font-weight: 700;
        }
        .jesync-welcome p {
            margin: 0 0 20px;
            color: var(--jc-text-secondary);
            font-size: 14px;
        }
        .jesync-quick-responses {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            margin-top: 16px;
        }

        /* ===== Mobile Responsive ===== */
        @media screen and (max-width: 768px) {
            #jesync-chat-widget {
                bottom: 16px !important;
                right: 16px !important;
                left: auto !important;
                top: auto !important;
                /* Remove transform to allow panel fixed positioning to work */
                -webkit-transform: none !important;
                transform: none !important;
            }
            #jesync-chat-bubble {
                width: 60px !important;
                height: 60px !important;
                min-width: 60px !important;
                min-height: 60px !important;
            }
            #jesync-chat-bubble svg {
                width: 26px !important;
                height: 26px !important;
            }
            #jesync-chat-panel {
                /* Override to fixed for mobile, centered */
                position: fixed !important;
                width: calc(100vw - 32px) !important;
                max-width: 380px !important;
                height: 70vh !important;
                max-height: 500px !important;
                /* Center using left:50% and negative margin */
                left: 50% !important;
                right: auto !important;
                margin-left: calc(-50vw + 16px) !important;
                margin-right: 0 !important;
                bottom: 90px !important;
                border-radius: 20px !important;
                /* Disable animation transform conflict */
                animation: none !important;
            }
            .jesync-chat-header {
                padding: 16px 20px !important;
            }
            .jesync-chat-messages {
                padding: 16px !important;
            }
            .jesync-quick-bar {
                padding: 10px 12px !important;
            }
            .jesync-quick-btn {
                padding: 6px 12px !important;
                font-size: 12px !important;
            }
            .jesync-chat-input-area {
                padding: 12px 16px !important;
            }
            .jesync-chat-input-area input {
                padding: 12px 16px !important;
                font-size: 16px !important; /* Prevents iOS zoom on focus */
            }
            .jesync-chat-input-area button {
                width: 44px !important;
                height: 44px !important;
                min-width: 44px !important;
            }
        }

        /* ===== Small Mobile ===== */
        @media screen and (max-width: 480px) {
            #jesync-chat-widget {
                bottom: 12px !important;
                right: 12px !important;
            }
            #jesync-chat-bubble {
                width: 56px !important;
                height: 56px !important;
                min-width: 56px !important;
                min-height: 56px !important;
            }
            #jesync-chat-panel {
                width: calc(100vw - 24px) !important;
                max-width: 380px !important;
                height: 65vh !important;
                max-height: 480px !important;
                /* Center using left:50% and negative margin */
                left: 50% !important;
                right: auto !important;
                margin-left: calc(-50vw + 12px) !important;
                bottom: 80px !important;
            }
        }

        /* ===== Extra Small Mobile ===== */
        @media screen and (max-width: 360px) {
            #jesync-chat-widget {
                bottom: 10px !important;
                right: 10px !important;
            }
            #jesync-chat-panel {
                width: calc(100vw - 20px) !important;
                height: 60vh !important;
                max-height: 450px !important;
                /* Center using left:50% and negative margin */
                left: 50% !important;
                right: auto !important;
                margin-left: calc(-50vw + 10px) !important;
                bottom: 76px !important;
            }
        }

        /* ===== Landscape Mobile ===== */
        @media screen and (max-height: 500px) {
            #jesync-chat-panel {
                height: calc(100vh - 100px);
                bottom: 80px;
            }
        }
    `;
    document.head.appendChild(style);

    // Build pre-chat form HTML
    let prechatHTML = '';
    if (PRECHAT_ENABLED) {
        prechatHTML = `
            <div class="jesync-prechat" id="jesync-prechat">
                <h4>Before we start</h4>
                <p>Please provide your details so we can assist you better.</p>
                ${PRECHAT_ACCOUNT ? `
                <div class="jesync-prechat-field">
                    <label>Account Number *</label>
                    <input type="text" id="jesync-pc-account" placeholder="e.g. PREPAID00001" autocomplete="off">
                    <span class="field-error" id="jesync-pc-account-err">Account number not found</span>
                    <span class="field-success" id="jesync-pc-account-ok"></span>
                </div>` : ''}
                ${PRECHAT_NAME ? `
                <div class="jesync-prechat-field">
                    <label>Your Name ${PRECHAT_ACCOUNT ? '' : '*'}</label>
                    <input type="text" id="jesync-pc-name" placeholder="Enter your name" autocomplete="off">
                    <span class="field-error" id="jesync-pc-name-err">Please enter your name</span>
                </div>` : ''}
                ${PRECHAT_CONTACT ? `
                <div class="jesync-prechat-field">
                    <label>Contact Number</label>
                    <input type="text" id="jesync-pc-contact" placeholder="e.g. 09171234567" autocomplete="off">
                </div>` : ''}
                <button class="jesync-prechat-btn" id="jesync-pc-submit">Start Chat</button>
                ${PRECHAT_GUEST ? `<div class="jesync-guest-link">No account number? <a id="jesync-guest-link">Chat as Guest</a></div>` : ''}
            </div>`;
    }

    // Create widget HTML
    const widget = document.createElement('div');
    widget.id = 'jesync-chat-widget';
    widget.innerHTML = `
        <div id="jesync-chat-panel">
            <div class="jesync-chat-header">
                <div class="jesync-chat-header-info">
                    <div class="status-dot" id="jesync-status-dot"></div>
                    <div>
                        <h3>${TITLE}</h3>
                        <small id="jesync-status-text">Connecting...</small>
                    </div>
                </div>
                <button class="jesync-chat-close" id="jesync-close-btn">&times;</button>
            </div>
            ${prechatCompleted ? '' : prechatHTML}
            <div class="jesync-chat-messages" id="jesync-messages" style="${prechatCompleted ? '' : 'display:none'}">
                <div class="jesync-welcome">
                    <h4>Hi${customerInfo?.name ? ' ' + customerInfo.name : ''}! How can I help you?</h4>
                    <p>Ask me about your account, plans, payments, or any service questions.</p>
                    <div class="jesync-quick-responses" id="jesync-quick-btns"></div>
                </div>
            </div>
            <div class="jesync-typing" id="jesync-typing">
                <span></span><span></span><span></span>
            </div>
            <div class="jesync-quick-bar-wrapper" id="jesync-quick-wrapper" style="display:none">
                <button class="jesync-quick-toggle" id="jesync-quick-toggle">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                    <span>Quick Answers</span>
                </button>
                <div class="jesync-quick-bar" id="jesync-quick-bar"></div>
            </div>
            <div class="jesync-chat-input-area" id="jesync-input-area" style="${prechatCompleted ? '' : 'display:none'}">
                <input type="text" id="jesync-input" placeholder="Type your question..." autocomplete="off">
                <button id="jesync-send-btn" title="Send">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                </button>
            </div>
        </div>
        <button id="jesync-chat-bubble" title="Chat with us">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        </button>
    `;
    document.body.appendChild(widget);

    // Elements
    const bubble = document.getElementById('jesync-chat-bubble');
    const panel = document.getElementById('jesync-chat-panel');
    const closeBtn = document.getElementById('jesync-close-btn');
    const messagesEl = document.getElementById('jesync-messages');
    const inputEl = document.getElementById('jesync-input');
    const sendBtn = document.getElementById('jesync-send-btn');
    const typingEl = document.getElementById('jesync-typing');
    const statusDot = document.getElementById('jesync-status-dot');
    const statusText = document.getElementById('jesync-status-text');

    // Pre-chat form logic
    if (PRECHAT_ENABLED && !prechatCompleted) {
        const pcSubmit = document.getElementById('jesync-pc-submit');
        const pcAccount = document.getElementById('jesync-pc-account');
        const pcName = document.getElementById('jesync-pc-name');
        const pcContact = document.getElementById('jesync-pc-contact');

        if (pcSubmit) {
            pcSubmit.addEventListener('click', handlePrechatSubmit);
        }
        // Enter key on any field submits
        [pcAccount, pcName, pcContact].forEach(el => {
            if (el) el.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') handlePrechatSubmit();
            });
        });

        // Auto-fill account from URL params
        if (pcAccount) {
            const urlParams = new URLSearchParams(window.location.search);
            const urlAccount = urlParams.get('account') || '';
            if (urlAccount) pcAccount.value = urlAccount;
        }

        // Guest link handler
        const guestLink = document.getElementById('jesync-guest-link');
        if (guestLink) {
            guestLink.addEventListener('click', function() {
                customerInfo = { account: '', name: 'Guest', contact: '' };
                localStorage.setItem('jesync_ai_customer', JSON.stringify(customerInfo));
                userId = 'guest_' + generateId().slice(0, 8);
                localStorage.setItem('jesync_ai_user', userId);
                sessionId = generateId();
                localStorage.setItem('jesync_ai_session', sessionId);
                prechatCompleted = true;

                const prechatEl = document.getElementById('jesync-prechat');
                if (prechatEl) prechatEl.style.display = 'none';
                messagesEl.style.display = 'flex';
                document.getElementById('jesync-input-area').style.display = 'flex';

                const welcomeEl = messagesEl.querySelector('.jesync-welcome h4');
                if (welcomeEl) welcomeEl.textContent = 'Hi! How can I help you?';
                inputEl.focus();
            });
        }
    }

    async function handlePrechatSubmit() {
        const pcSubmit = document.getElementById('jesync-pc-submit');
        const pcAccount = document.getElementById('jesync-pc-account');
        const pcName = document.getElementById('jesync-pc-name');
        const pcContact = document.getElementById('jesync-pc-contact');
        const pcAccountErr = document.getElementById('jesync-pc-account-err');
        const pcAccountOk = document.getElementById('jesync-pc-account-ok');
        const pcNameErr = document.getElementById('jesync-pc-name-err');

        // Clear errors
        if (pcAccountErr) { pcAccountErr.classList.remove('show'); pcAccountErr.textContent = 'Account number not found'; }
        if (pcAccountOk) pcAccountOk.classList.remove('show');
        if (pcNameErr) pcNameErr.classList.remove('show');
        if (pcAccount) pcAccount.classList.remove('error');
        if (pcName) pcName.classList.remove('error');

        // Validate account number
        if (PRECHAT_ACCOUNT && pcAccount) {
            const acct = pcAccount.value.trim();
            if (!acct) {
                pcAccountErr.textContent = 'Please enter your account number';
                pcAccountErr.classList.add('show');
                pcAccount.classList.add('error');
                pcAccount.focus();
                return;
            }

            // Validate against server
            pcSubmit.disabled = true;
            pcSubmit.innerHTML = '<span class="jesync-prechat-spinner"></span>Verifying...';

            try {
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 10000);
                const resp = await fetch(VALIDATE_URL + '?account_no=' + encodeURIComponent(acct), {
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                const data = await resp.json();

                if (!data.valid) {
                    pcAccountErr.textContent = data.error || 'Account number not found. Please check and try again.';
                    pcAccountErr.classList.add('show');
                    pcAccount.classList.add('error');
                    pcAccount.focus();
                    pcSubmit.disabled = false;
                    pcSubmit.textContent = 'Start Chat';
                    return;
                }

                // Account valid - show success
                pcAccountOk.textContent = 'Account verified: ' + (data.name || data.account);
                pcAccountOk.classList.add('show');

                // Auto-fill name from account data if available and name field is empty
                if (pcName && !pcName.value.trim() && data.name) {
                    pcName.value = data.name;
                }
            } catch (err) {
                // If validation unavailable, allow chat anyway
                pcAccountOk.textContent = 'Could not verify account - proceeding anyway';
                pcAccountOk.classList.add('show');
            }
        }

        // Validate name (if required and account not enabled - name becomes required)
        if (PRECHAT_NAME && !PRECHAT_ACCOUNT && pcName) {
            if (!pcName.value.trim()) {
                pcNameErr.classList.add('show');
                pcName.classList.add('error');
                pcName.focus();
                pcSubmit.disabled = false;
                pcSubmit.textContent = 'Start Chat';
                return;
            }
        }

        // Save customer info
        customerInfo = {
            account: pcAccount ? pcAccount.value.trim().toUpperCase() : '',
            name: pcName ? pcName.value.trim() : '',
            contact: pcContact ? pcContact.value.trim() : ''
        };
        localStorage.setItem('jesync_ai_customer', JSON.stringify(customerInfo));

        // Set userId to account number (or name as fallback)
        userId = customerInfo.account || customerInfo.name || userId;
        localStorage.setItem('jesync_ai_user', userId);

        // Reset session for new customer identification
        sessionId = generateId();
        localStorage.setItem('jesync_ai_session', sessionId);

        prechatCompleted = true;

        // Transition to chat view
        const prechatEl = document.getElementById('jesync-prechat');
        if (prechatEl) prechatEl.style.display = 'none';
        messagesEl.style.display = 'flex';
        document.getElementById('jesync-input-area').style.display = 'flex';

        // Update welcome message with name
        const welcomeEl = messagesEl.querySelector('.jesync-welcome h4');
        if (welcomeEl && customerInfo.name) {
            welcomeEl.textContent = 'Hi ' + customerInfo.name + '! How can I help you?';
        }

        pcSubmit.disabled = false;
        pcSubmit.textContent = 'Start Chat';
        inputEl.focus();
    }

    // Toggle chat
    bubble.addEventListener('click', () => {
        isOpen = !isOpen;
        panel.classList.toggle('open', isOpen);
        if (isOpen) {
            if (prechatCompleted) {
                inputEl.focus();
                // Load conversation history on first open
                if (!historyLoaded && sessionId) {
                    loadHistory();
                }
                // Start polling for admin messages
                startPolling();
            } else {
                const firstInput = panel.querySelector('.jesync-prechat input');
                if (firstInput) firstInput.focus();
            }
            checkStatus();
        } else {
            // Stop polling when chat closed
            stopPolling();
        }
    });
    closeBtn.addEventListener('click', () => {
        isOpen = false;
        panel.classList.remove('open');
        stopPolling();
    });

    // Send message
    sendBtn.addEventListener('click', sendMessage);
    inputEl.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    async function sendMessage() {
        const text = inputEl.value.trim();
        if (!text || isLoading) return;

        // Remove welcome message if present and show quick bar
        const welcome = messagesEl.querySelector('.jesync-welcome');
        if (welcome) {
            welcome.remove();
            // Show the collapsible quick bar wrapper (hidden during welcome)
            const qbWrapper = document.getElementById('jesync-quick-wrapper');
            if (qbWrapper) qbWrapper.style.display = 'block';
        }

        inputEl.value = '';

        // Check if message matches a quick response FIRST (saves AI processing!)
        const matchedQR = findMatchingQuickResponse(text);
        if (matchedQR) {
            addMessage('user', text);
            setTimeout(() => {
                addMessage('assistant', matchedQR.response);
                statusText.textContent = 'AI Assistant Online';
            }, 300);
            return; // Don't call AI!
        }

        addMessage('user', text);

        isLoading = true;
        sendBtn.disabled = true;
        typingEl.classList.add('show');
        statusText.textContent = 'AI is thinking...';

        try {
            // Use AbortController for proper timeout (3 minutes for CPU inference)
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 180000);

            const resp = await fetch(API_URL + '/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-Secret': API_SECRET,
                },
                body: JSON.stringify({
                    message: text,
                    user_id: userId,
                    session_id: sessionId,
                    api_secret: API_SECRET,
                    customer_info: customerInfo || {},
                }),
                signal: controller.signal,
            });

            clearTimeout(timeoutId);
            const data = await resp.json();
            if (data.error) {
                addMessage('system', 'Error: ' + data.error);
            } else {
                addMessage('assistant', data.response, data.message_id);
                // Check if admin has taken over
                if (data.awaiting_admin) {
                    awaitingAdmin = true;
                    statusText.textContent = 'Waiting for Support Agent...';
                } else {
                    statusText.textContent = 'AI Assistant Online';
                }
            }
            // Update message count (user + assistant = 2 new messages)
            lastMessageCount += 2;
        } catch (err) {
            if (err.name === 'AbortError') {
                addMessage('system', 'Response took too long. Please try a shorter question.');
            } else {
                addMessage('system', 'Unable to reach support. Please try again later.');
            }
            statusText.textContent = 'Connection issue';
        } finally {
            isLoading = false;
            sendBtn.disabled = false;
            typingEl.classList.remove('show');
        }
    }

    function addMessage(role, text, messageId) {
        // Remove welcome message on first interaction
        const welcome = messagesEl.querySelector('.jesync-welcome');
        if (welcome) welcome.remove();

        const div = document.createElement('div');
        div.className = 'jesync-msg ' + role;
        div.textContent = text;

        // Add feedback buttons for assistant messages
        if (role === 'assistant' && messageId) {
            const feedback = document.createElement('div');
            feedback.className = 'jesync-msg-feedback';
            feedback.innerHTML = `
                <button onclick="jesyncFeedback('${messageId}', 1, this)" title="Helpful">&#128077;</button>
                <button onclick="jesyncFeedback('${messageId}', -1, this)" title="Not helpful">&#128078;</button>
            `;
            div.appendChild(feedback);
        }

        messagesEl.appendChild(div);
        messagesEl.scrollTop = messagesEl.scrollHeight;
    }

    // Global feedback function
    window.jesyncFeedback = async function(messageId, rating, btn) {
        const siblings = btn.parentElement.querySelectorAll('button');
        siblings.forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');

        try {
            await fetch(API_URL + '/api/feedback', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-API-Secret': API_SECRET,
                },
                body: JSON.stringify({
                    message_id: messageId,
                    user_id: userId,
                    rating: rating,
                    api_secret: API_SECRET,
                }),
            });
        } catch (e) {
            // Silently fail
        }
    };

    // Load conversation history from server
    async function loadHistory() {
        if (historyLoaded || !sessionId) return;
        try {
            const resp = await fetch(API_URL + '/api/history?session_id=' + encodeURIComponent(sessionId), {
                headers: { 'X-API-Secret': API_SECRET },
            });
            const data = await resp.json();
            if (data.messages && data.messages.length > 0) {
                // Remove welcome message and show quick bar wrapper
                const welcome = messagesEl.querySelector('.jesync-welcome');
                if (welcome) {
                    welcome.remove();
                    const qbWrapper = document.getElementById('jesync-quick-wrapper');
                    if (qbWrapper) qbWrapper.style.display = 'block';
                }
                // Add historical messages
                data.messages.forEach(msg => {
                    const div = document.createElement('div');
                    div.className = 'jesync-msg ' + msg.role;
                    div.dataset.msgId = msg.id || '';
                    div.textContent = msg.content;
                    // Add feedback buttons for assistant messages (without IDs for history)
                    if (msg.role === 'assistant' && msg.id) {
                        const feedback = document.createElement('div');
                        feedback.className = 'jesync-msg-feedback';
                        feedback.innerHTML = `
                            <button onclick="jesyncFeedback('${msg.id}', 1, this)" title="Helpful">&#128077;</button>
                            <button onclick="jesyncFeedback('${msg.id}', -1, this)" title="Not helpful">&#128078;</button>
                        `;
                        div.appendChild(feedback);
                    }
                    messagesEl.appendChild(div);
                });
                messagesEl.scrollTop = messagesEl.scrollHeight;
                // Track message count for polling
                lastMessageCount = data.messages.length;
            }
            historyLoaded = true;
            // Start polling after history loads
            if (isOpen && prechatCompleted) {
                startPolling();
            }
        } catch (e) {
            console.log('Failed to load chat history:', e);
            historyLoaded = true; // Don't retry on error
        }
    }

    // Load quick responses from server
    async function loadQuickResponses() {
        try {
            const resp = await fetch(API_URL + '/api/quick_responses', {
                headers: { 'X-API-Secret': API_SECRET },
            });
            const data = await resp.json();
            if (data.quick_responses && data.quick_responses.length > 0) {
                quickResponses = data.quick_responses;
                renderQuickButtons();
            }
        } catch (e) {
            console.log('Failed to load quick responses:', e);
        }
    }

    // Render quick response buttons in welcome area and toggle quick bar
    function renderQuickButtons() {
        // Render in welcome area (shown initially)
        const welcomeContainer = document.getElementById('jesync-quick-btns');
        if (welcomeContainer && quickResponses.length > 0) {
            welcomeContainer.innerHTML = '';
            quickResponses.forEach(qr => {
                const btn = document.createElement('button');
                btn.className = 'jesync-quick-btn';
                btn.textContent = qr.button;
                btn.onclick = () => handleQuickResponse(qr);
                welcomeContainer.appendChild(btn);
            });
        }

        // Render in collapsible quick bar (hidden by default, toggle to show)
        const quickBar = document.getElementById('jesync-quick-bar');
        if (quickBar && quickResponses.length > 0) {
            quickBar.innerHTML = '';
            quickResponses.forEach(qr => {
                const btn = document.createElement('button');
                btn.className = 'jesync-quick-btn';
                btn.textContent = qr.button;
                btn.onclick = () => handleQuickResponse(qr);
                quickBar.appendChild(btn);
            });
        }

        // Setup toggle button
        const toggleBtn = document.getElementById('jesync-quick-toggle');
        if (toggleBtn && !toggleBtn.hasAttribute('data-bound')) {
            toggleBtn.setAttribute('data-bound', 'true');
            toggleBtn.addEventListener('click', () => {
                const qb = document.getElementById('jesync-quick-bar');
                const isExpanded = qb.classList.toggle('show');
                toggleBtn.classList.toggle('expanded', isExpanded);
            });
        }
    }

    // Handle quick response button click
    function handleQuickResponse(qr) {
        // Remove welcome message and show quick bar wrapper
        const welcome = messagesEl.querySelector('.jesync-welcome');
        if (welcome) {
            welcome.remove();
            // Show the collapsible quick bar wrapper
            const qbWrapper = document.getElementById('jesync-quick-wrapper');
            if (qbWrapper) qbWrapper.style.display = 'block';
        }

        // Collapse the quick bar after selecting (user can expand again)
        const quickBar = document.getElementById('jesync-quick-bar');
        const toggleBtn = document.getElementById('jesync-quick-toggle');
        if (quickBar) quickBar.classList.remove('show');
        if (toggleBtn) toggleBtn.classList.remove('expanded');

        // Show user's question
        addMessage('user', qr.button);

        // Show instant response (no AI processing needed!)
        setTimeout(() => {
            addMessage('assistant', qr.response);
        }, 300);
    }

    // Check if user message matches a quick response (fuzzy match)
    function findMatchingQuickResponse(text) {
        const normalized = text.toLowerCase().trim().replace(/[?!.,]/g, '');
        for (const qr of quickResponses) {
            const qrNorm = qr.button.toLowerCase().trim().replace(/[?!.,]/g, '');
            // Exact match or very close match
            if (normalized === qrNorm) return qr;
            // Contains match (e.g., "how to pay" matches "how to pay?")
            if (normalized.includes(qrNorm) || qrNorm.includes(normalized)) return qr;
            // Word-based similarity
            const words = normalized.split(/\s+/);
            const qrWords = qrNorm.split(/\s+/);
            const commonWords = words.filter(w => qrWords.includes(w));
            if (commonWords.length >= Math.min(2, qrWords.length - 1)) return qr;
        }
        return null;
    }

    // Check AI server status with proper timeout
    async function checkStatus() {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 8000);
            const resp = await fetch(API_URL + '/api/status', { signal: controller.signal });
            clearTimeout(timeoutId);
            const data = await resp.json();
            if (data.status === 'online') {
                statusDot.classList.remove('offline');
                statusText.textContent = 'AI Assistant Online';
                aiStatus = 'online';
            } else {
                statusDot.classList.add('offline');
                statusText.textContent = 'Limited service';
                aiStatus = 'degraded';
            }
        } catch (e) {
            statusDot.classList.add('offline');
            statusText.textContent = 'Offline - try again later';
            aiStatus = 'offline';
        }
    }

    // Poll for new messages (admin replies)
    async function pollForMessages() {
        if (!sessionId || !isOpen || isLoading) return;

        try {
            const resp = await fetch(API_URL + '/api/history?session_id=' + encodeURIComponent(sessionId), {
                headers: { 'X-API-Secret': API_SECRET },
            });
            const data = await resp.json();

            if (data.messages && data.messages.length > lastMessageCount) {
                // New messages arrived - show them
                const newMessages = data.messages.slice(lastMessageCount);
                newMessages.forEach(msg => {
                    // Only show assistant/admin messages (user messages are already shown)
                    if (msg.role === 'assistant' || msg.role === 'admin') {
                        // Check if this message is already displayed
                        const existingMsgs = messagesEl.querySelectorAll('.jesync-msg');
                        let alreadyShown = false;
                        existingMsgs.forEach(el => {
                            if (el.dataset.msgId === msg.id) alreadyShown = true;
                        });

                        if (!alreadyShown) {
                            const div = document.createElement('div');
                            div.className = 'jesync-msg assistant';
                            div.dataset.msgId = msg.id;
                            div.textContent = msg.content;

                            // Add feedback buttons
                            if (msg.id) {
                                const feedback = document.createElement('div');
                                feedback.className = 'jesync-msg-feedback';
                                feedback.innerHTML = `
                                    <button onclick="jesyncFeedback('${msg.id}', 1, this)" title="Helpful">&#128077;</button>
                                    <button onclick="jesyncFeedback('${msg.id}', -1, this)" title="Not helpful">&#128078;</button>
                                `;
                                div.appendChild(feedback);
                            }

                            messagesEl.appendChild(div);
                            messagesEl.scrollTop = messagesEl.scrollHeight;

                            // Update status if admin replied
                            if (msg.content.includes('[Support Agent]')) {
                                statusText.textContent = 'Support Agent Active';
                                awaitingAdmin = false;
                            }
                        }
                    }
                });
                lastMessageCount = data.messages.length;
            }
        } catch (e) {
            console.log('Poll failed:', e);
        }
    }

    // Start/stop polling based on chat state
    function startPolling() {
        if (pollInterval) return;
        pollInterval = setInterval(pollForMessages, 3000); // Poll every 3 seconds
    }

    function stopPolling() {
        if (pollInterval) {
            clearInterval(pollInterval);
            pollInterval = null;
        }
    }

    // Allow resetting customer info (e.g., different customer using same device)
    window.jesyncResetChat = function() {
        stopPolling();
        localStorage.removeItem('jesync_ai_customer');
        localStorage.removeItem('jesync_ai_session');
        localStorage.removeItem('jesync_ai_user');
        historyLoaded = false;
        location.reload();
    };

    // Initial status check and quick responses load
    checkStatus();
    loadQuickResponses();
    setInterval(checkStatus, 60000); // Re-check every minute
})();
