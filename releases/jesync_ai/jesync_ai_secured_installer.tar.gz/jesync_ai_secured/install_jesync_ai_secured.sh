#!/bin/bash
#
# ============================================
# JeSync AI Assistant - SECURED Installer
# For Ubuntu 24.04 LTS Server
# PyArmor Protected Edition
# ============================================
#
# This installs the PyArmor-protected version of JeSync AI
# Source code is encrypted and cannot be read/modified
#
# Usage: sudo bash install_jesync_ai_secured.sh [OPTIONS]
#
# Options:
#   --model MODEL     LLM model to use (default: qwen2.5:7b)
#   --ip IP           Server IP address (auto-detect if not specified)
#   --dashboard-ip IP JeSync Dashboard IP (default: auto-detect network)
#   --skip-model      Skip pulling LLM model (if already installed)
#   --help            Show this help message
#

set -e

# ==================== CONFIGURATION ====================
DEFAULT_MODEL="qwen2.5:7b"
INSTALL_DIR="/opt/jesync_ai"
SERVICE_USER="jesync"
DB_NAME="jesync_ai"
DB_USER="jesync_ai"
DB_PASS="jesyncai2026"
ADMIN_PASS="jesyncadmin2026"
API_SECRET="jesync-ai-secret-2026"

# ==================== COLORS ====================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

show_help() {
    head -25 "$0" | tail -15
    exit 0
}

detect_ip() {
    ip -4 addr show scope global | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1
}

detect_dashboard_ip() {
    local my_ip=$(detect_ip)
    echo "${my_ip%.*}.4"
}

# ==================== PARSE ARGUMENTS ====================
MODEL="$DEFAULT_MODEL"
SERVER_IP=""
DASHBOARD_IP=""
SKIP_MODEL=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --model) MODEL="$2"; shift 2 ;;
        --ip) SERVER_IP="$2"; shift 2 ;;
        --dashboard-ip) DASHBOARD_IP="$2"; shift 2 ;;
        --skip-model) SKIP_MODEL=true; shift ;;
        --help) show_help ;;
        *) log_error "Unknown option: $1. Use --help for usage." ;;
    esac
done

[[ -z "$SERVER_IP" ]] && SERVER_IP=$(detect_ip)
[[ -z "$DASHBOARD_IP" ]] && DASHBOARD_IP=$(detect_dashboard_ip)
[[ -z "$SERVER_IP" ]] && log_error "Could not detect server IP. Please specify with --ip"

# ==================== MAIN INSTALLATION ====================
clear
echo -e "${CYAN}"
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║     JeSync AI Assistant - SECURED Installer                    ║"
echo "║           PyArmor Protected Edition                            ║"
echo "║                Ubuntu 24.04 LTS                                ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo -e "${NC}"
echo ""
echo "Configuration:"
echo "  Server IP:      $SERVER_IP"
echo "  Dashboard IP:   $DASHBOARD_IP"
echo "  LLM Model:      $MODEL"
echo "  Install Dir:    $INSTALL_DIR"
echo "  Protection:     PyArmor Encrypted"
echo ""

if [ "$EUID" -ne 0 ]; then
    log_error "Please run as root: sudo bash install_jesync_ai_secured.sh"
fi

if ! grep -q "Ubuntu 24" /etc/os-release 2>/dev/null; then
    log_warn "This script is designed for Ubuntu 24.04. Continuing anyway..."
fi

read -p "Continue with installation? [Y/n] " -n 1 -r
echo
[[ $REPLY =~ ^[Nn]$ ]] && exit 0

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TOTAL_STEPS=12
CURRENT_STEP=0

step() {
    ((CURRENT_STEP++))
    echo ""
    echo -e "${BLUE}[$CURRENT_STEP/$TOTAL_STEPS]${NC} $1"
    echo "────────────────────────────────────────────"
}

# ==================== STEP 1: System Update ====================
step "Updating system packages..."
apt update -qq
apt upgrade -y -qq
log_success "System updated"

# ==================== STEP 2: Install Dependencies ====================
step "Installing system dependencies..."
apt install -y -qq \
    python3 python3-pip python3-venv python3-dev \
    postgresql postgresql-contrib \
    redis-server \
    nginx \
    curl wget git \
    build-essential libpq-dev \
    lsb-release ca-certificates apt-transport-https
log_success "Dependencies installed"

# ==================== STEP 3: Install Ollama ====================
step "Installing Ollama..."
if command -v ollama &> /dev/null; then
    log_success "Ollama already installed"
else
    curl -fsSL https://ollama.com/install.sh | sh
    log_success "Ollama installed"
fi

systemctl enable ollama
systemctl start ollama
sleep 3
log_success "Ollama service running"

# ==================== STEP 4: Pull LLM Model ====================
step "Pulling LLM model: $MODEL"
if [ "$SKIP_MODEL" = true ]; then
    log_warn "Skipping model pull (--skip-model)"
else
    echo "This may take 5-15 minutes depending on your internet speed..."
    ollama pull "$MODEL"
    log_success "Model $MODEL ready"
fi

# ==================== STEP 5: Configure PostgreSQL ====================
step "Configuring PostgreSQL..."
systemctl enable postgresql
systemctl start postgresql

sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';"

sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" | grep -q 1 || \
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME OWNER $DB_USER;"

sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
log_success "PostgreSQL database '$DB_NAME' ready"

# ==================== STEP 6: Configure Redis ====================
step "Configuring Redis..."
systemctl enable redis-server
systemctl start redis-server
log_success "Redis running"

# ==================== STEP 7: Create Service User ====================
step "Creating service user..."
if id -u "$SERVICE_USER" &>/dev/null; then
    log_success "User '$SERVICE_USER' already exists"
else
    useradd -r -m -s /bin/bash -d /home/$SERVICE_USER $SERVICE_USER
    log_success "User '$SERVICE_USER' created"
fi

# ==================== STEP 8: Install SECURED Application ====================
step "Installing JeSync AI Assistant (SECURED)..."
mkdir -p $INSTALL_DIR/data/chroma_db

# Check for required files
if [ ! -d "$SCRIPT_DIR/pyarmor_runtime_009739" ]; then
    log_error "PyArmor runtime not found. Please ensure you have the complete secured package."
fi

# Copy all files including PyArmor runtime
cp -r "$SCRIPT_DIR"/* $INSTALL_DIR/
rm -f $INSTALL_DIR/install_jesync_ai_secured.sh  # Don't copy installer

# Create Python virtual environment
log_info "Creating Python virtual environment..."
python3 -m venv $INSTALL_DIR/venv
$INSTALL_DIR/venv/bin/pip install --upgrade pip -q
$INSTALL_DIR/venv/bin/pip install -r $INSTALL_DIR/requirements.txt -q
log_success "Python environment ready"

# ==================== STEP 9: Configure Application ====================
step "Configuring application..."

cat > $INSTALL_DIR/config.json << EOF
{
    "SECRET_KEY": "jesync-ai-$(openssl rand -hex 16)",
    "ADMIN_PASSWORD": "$ADMIN_PASS",
    "JESYNC_DASHBOARD_URL": "http://$DASHBOARD_IP:5000",
    "JESYNC_API_SECRET": "$API_SECRET",
    "OLLAMA_URL": "http://localhost:11434",
    "OLLAMA_MODEL": "$MODEL",
    "OLLAMA_TIMEOUT": 300,
    "CHROMA_PERSIST_DIR": "$INSTALL_DIR/data/chroma_db",
    "REDIS_URL": "redis://localhost:6379/0",
    "POSTGRES": {
        "host": "localhost",
        "port": 5432,
        "dbname": "$DB_NAME",
        "user": "$DB_USER",
        "password": "$DB_PASS"
    },
    "FB_PAGE_ACCESS_TOKEN": "",
    "FB_VERIFY_TOKEN": "",
    "FB_APP_SECRET": "",
    "MAX_CONTEXT_MESSAGES": 10,
    "MAX_RAG_RESULTS": 5,
    "LOG_LEVEL": "INFO",
    "CONVERSATION_TTL_DAYS": 90,
    "AI_NAME": "JeSync AI",
    "COMPANY_NAME": "JeSync Pro"
}
EOF

chown -R $SERVICE_USER:$SERVICE_USER $INSTALL_DIR
log_success "Configuration saved"

# ==================== STEP 10: Seed Knowledge Base ====================
step "Seeding knowledge base..."
cd $INSTALL_DIR
sudo -u $SERVICE_USER $INSTALL_DIR/venv/bin/python knowledge/seed_knowledge.py
log_success "Knowledge base seeded"

# ==================== STEP 11: Configure Nginx ====================
step "Configuring Nginx..."

cat > /etc/nginx/sites-available/jesync-ai << EOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name $SERVER_IP _;

    location / {
        proxy_pass http://127.0.0.1:5050;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 180s;
        proxy_connect_timeout 10s;
        proxy_send_timeout 60s;
    }

    location /static/ {
        alias $INSTALL_DIR/static/;
        expires 1h;
        add_header Cache-Control "public, immutable";
        add_header Access-Control-Allow-Origin "*" always;
    }

    location /health {
        proxy_pass http://127.0.0.1:5050/health;
        proxy_read_timeout 5s;
    }

    location /webhook/ {
        proxy_pass http://127.0.0.1:5050/webhook/;
        proxy_read_timeout 30s;
    }
}
EOF

ln -sf /etc/nginx/sites-available/jesync-ai /etc/nginx/sites-enabled/jesync-ai
rm -f /etc/nginx/sites-enabled/default

nginx -t && systemctl reload nginx
systemctl enable nginx
log_success "Nginx configured"

# ==================== STEP 12: Configure Systemd Service ====================
step "Setting up systemd service..."

cat > /etc/systemd/system/jesync-ai.service << EOF
[Unit]
Description=JeSync AI Assistant Server (SECURED)
After=network.target postgresql.service redis-server.service ollama.service
Wants=ollama.service

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
Environment=PATH=$INSTALL_DIR/venv/bin:/usr/local/bin:/usr/bin
ExecStart=$INSTALL_DIR/venv/bin/gunicorn --workers 4 --bind 127.0.0.1:5050 --timeout 300 "app:create_app()"
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable jesync-ai
systemctl start jesync-ai
sleep 3
log_success "Service started"

# ==================== VERIFICATION ====================
echo ""
echo -e "${CYAN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║        SECURED INSTALLATION COMPLETE!                          ║${NC}"
echo -e "${CYAN}║           PyArmor Protected Edition                            ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo "Server Information:"
echo "────────────────────────────────────────────"
echo "  AI Server:        http://$SERVER_IP"
echo "  Admin Panel:      http://$SERVER_IP/admin/"
echo "  Health Check:     http://$SERVER_IP/health"
echo "  API Endpoint:     http://$SERVER_IP/api/chat"
echo ""
echo "Credentials:"
echo "────────────────────────────────────────────"
echo "  Admin Password:   $ADMIN_PASS"
echo "  API Secret:       $API_SECRET"
echo ""
echo "LLM Model:          $MODEL"
echo "Protection:         PyArmor Encrypted (License: 009739)"
echo ""
echo "Services:"
echo "────────────────────────────────────────────"
echo "  systemctl status jesync-ai"
echo "  journalctl -u jesync-ai -f"
echo ""
echo "Chat Widget (add to JeSync Dashboard):"
echo "────────────────────────────────────────────"
echo -e "${YELLOW}<script src=\"http://$SERVER_IP/static/chat-widget.js\""
echo "        data-api-url=\"http://$SERVER_IP\""
echo "        data-api-secret=\"$API_SECRET\"></script>${NC}"
echo ""

sleep 2
HEALTH=$(curl -s http://localhost:5050/health 2>/dev/null || echo '{}')
if echo "$HEALTH" | grep -q '"status":"online"'; then
    echo -e "${GREEN}✓ AI Server is ONLINE and ready!${NC}"
else
    echo -e "${YELLOW}⚠ AI Server may still be starting up. Check: curl http://$SERVER_IP/health${NC}"
fi
echo ""
